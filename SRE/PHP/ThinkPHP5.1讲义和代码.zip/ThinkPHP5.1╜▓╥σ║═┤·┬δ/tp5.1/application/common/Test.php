<?php
namespace app\common;

class Test
{
    public function hello($name)
    {
        return 'hello, '.$name;
    }
}