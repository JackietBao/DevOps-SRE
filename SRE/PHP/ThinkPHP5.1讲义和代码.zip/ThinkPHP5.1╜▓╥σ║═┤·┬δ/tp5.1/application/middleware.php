<?php
return [
    //app\http\middleware\Check::class,
    //app\http\middleware\Auth::class,
    //[app\http\middleware\Auth::class, 'def']
    //'Auth:hig'
];