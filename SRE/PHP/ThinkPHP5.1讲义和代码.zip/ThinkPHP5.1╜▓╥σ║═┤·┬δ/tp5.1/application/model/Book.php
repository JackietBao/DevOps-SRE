<?php
namespace app\model;
use think\Model;

class Book extends Model
{

}