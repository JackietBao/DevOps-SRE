<?php
namespace app\model;

class One
{
    public $name = 'Mr.Lee';
}