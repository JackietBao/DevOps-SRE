<?php
//error message，en-us.php
return [
    'require_name'  => 'The user name cannot be empty!',
    'email_error'   => 'Incorrect email address!',
];