<?php
//错误信息，zh-cn.php
return [
    'require_name'  => '用户名不得为空！',
    'email_error'   => '邮箱地址不正确！',
    //'filesize not match'    =>      '自定义的上传：大小不符合！',
];