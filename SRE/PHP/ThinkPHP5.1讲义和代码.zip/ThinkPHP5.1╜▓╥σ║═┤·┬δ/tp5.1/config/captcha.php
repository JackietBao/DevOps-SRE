<?php
return [
    //字体大小
    'fontSize' => 50,
    //验证码位数
    'length' => 4,
    //验证码杂点
    'useNoise' => false,
    'fontttf'   =>  '1.ttf',
    'useImgBg'  =>  true,
    'useZh'     =>  true
];