<?php 
//根据 Annotation 自动生成的路由规则
Route::resource('col','Collect');
Route::get('col/:id','Collect/read')
	->ext('html')
	->pattern(['id'=>'\d+']);