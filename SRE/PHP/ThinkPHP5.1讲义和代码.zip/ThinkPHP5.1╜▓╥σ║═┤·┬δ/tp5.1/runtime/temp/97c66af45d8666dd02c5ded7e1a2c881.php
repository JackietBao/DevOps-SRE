<?php /*a:1:{s:38:"C:\wamp\www\tp5.1\application\404.html";i:1575722255;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

错误404：页面不存在！

</body>
</html>