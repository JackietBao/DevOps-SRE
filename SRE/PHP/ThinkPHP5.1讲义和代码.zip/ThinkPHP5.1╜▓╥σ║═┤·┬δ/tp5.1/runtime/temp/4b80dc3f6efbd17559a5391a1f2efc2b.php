<?php /*a:1:{s:48:"C:\wamp\www\tp5.1\application\view\see\code.html";i:1577076829;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>验证码验证</title>
</head>
<body>

<div><?php echo captcha_img(); ?></div>
<!--<div><img src="<?php echo captcha_src(); ?>" alt="captcha" /></div>-->
<!--<div><img src="../code/show" alt="captcha" /></div>-->

<form action="../code" method="post">
    <input type="text" name="code">
    <input type="submit" value="验证提交">
</form>

</body>
</html>