<?php /*a:1:{s:49:"C:\wamp\www\tp5.1\application\view\see\other.html";i:1573797150;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>


模版变量形式：{$name}







<span style="font-size:100px;color:pink;">
    ThinkPHP
</span>

.

<form action="../short/info" method="post">
    <button type="submit">提交</button>
</form>

</body>
</html>