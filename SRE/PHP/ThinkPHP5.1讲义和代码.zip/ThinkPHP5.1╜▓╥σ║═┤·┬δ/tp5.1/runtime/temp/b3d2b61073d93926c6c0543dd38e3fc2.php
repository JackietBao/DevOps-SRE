<?php /*a:1:{s:49:"C:\wamp\www\tp5.1\application\view\See\other.html";i:1573629012;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>


模版变量形式：{$name}







<span style="font-size:100px;color:pink;">
    ThinkPHP
</span>

<?php echo htmlentities($name); ?>.<?php echo htmlentities($email); ?>

</body>
</html>