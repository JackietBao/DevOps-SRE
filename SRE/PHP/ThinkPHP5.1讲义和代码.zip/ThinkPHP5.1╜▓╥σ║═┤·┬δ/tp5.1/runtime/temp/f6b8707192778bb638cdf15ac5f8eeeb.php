<?php /*a:1:{s:50:"C:\wamp\www\tp5.1\application\view\page\index.html";i:1576832704;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>分页</title>
    <style>
        .pagination,.pager {
            list-style: none;
            margin: 0;
            padding: 0;
        }
        .pagination li,.pager li {
            display: inline-block;
            padding: 20px;
        }
    </style>
</head>
<body>

<table border="1">
    <tr>
        <th>编号</th>
        <th>姓名</th>
        <th>性别</th>
        <th>邮箱</th>
        <th>价格</th>
    </tr>
    <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$obj): $mod = ($i % 2 );++$i;?>
    <tr>
        <td><?php echo htmlentities($obj['id']); ?></td>
        <td><?php echo htmlentities($obj['username']); ?></td>
        <td><?php echo htmlentities($obj['gender']); ?></td>
        <td><?php echo htmlentities($obj['email']); ?></td>
        <td><?php echo htmlentities($obj['price']); ?></td>
    </tr>
    <?php endforeach; endif; else: echo "" ;endif; ?>
</table>

<?php echo $list; ?>
<br>


</body>
</html>