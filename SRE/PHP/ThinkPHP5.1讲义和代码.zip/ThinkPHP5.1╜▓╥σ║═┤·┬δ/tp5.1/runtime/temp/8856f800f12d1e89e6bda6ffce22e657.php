<?php /*a:1:{s:48:"C:\wamp\www\tp5.1\application\view\see\vali.html";i:1576304403;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

<form action="../verify/check" method="post">
    <input type="text" name="user">
    <input type="hidden" name="__token__" value="<?php echo htmlentities(app('request')->token()); ?>">
    <input type="submit" value="提交">
</form>

</body>
</html>