<?php
/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://woosmartcod.com
 * @since      1.0.0
 *
 * @package    Wc_Smart_Cod
 * @subpackage Wc_Smart_Cod/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wc_Smart_Cod
 * @subpackage Wc_Smart_Cod/public
 * @author     woosmartcod.com <info@woosmartcod.com>
 */
class Wc_Smart_Cod_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */

	private $has_cod_available;
	private $reason;

	protected static $targets = array(
		'role_restriction'                 => 0,
		'amount_restriction'               => 0,
		'shipping_zone_restrictions'       => 0,
		'shipping_zone_method_restriction' => 0,
		'country_restrictions'             => 0,
		'state_restrictions'               => 0,
		'restrict_postals'                 => 0,
		'city_restrictions'                => 0,
		'product_restriction'              => 0,
		'category_restriction'             => 0,
		'shipping_class_restriction'       => 0,
		'cart_range_restriction'           => 1,
		'user_restriction'                 => 0,
		'user_email_restriction'           => 0,
		'user_phone_restriction'           => 0,
		'coupon_restriction'               => 0,
		'stock_restriction'                => 1,
		'weight_restriction'               => 1,
		'product_qty_restriction'          => 1,
		'sku_product_restriction'          => 0,
		'wcfm_vendors_restriction'         => 0,
		'donkan_vendors_restriction'       => 0,
	);

	protected $calculated_availability;

	protected static $extrafees_option_name = 'woocommerce_smartcod_extrafees_settings';

	protected $extrafees_settings = null;

	protected $custom_description_set = array(
		'extra_fee' => false,
		'rf_fee'    => false,
	);

	private $adjusting_order_pay = false;

	public function __construct( $plugin_name ) {

		$this->plugin_name  = $plugin_name;
		$this->version      = SMART_COD_VER;
		$this->cod_settings = array();

		$this->cart_products        =
		$this->settings_analyzed    =
		$this->nocharge_amount_mode = false;

		if ( ! is_subclass_of( $this, 'Wc_Smart_Cod_Public' ) ) {
			if ( ! is_admin() ) {
				add_filter( 'woocommerce_available_payment_gateways', array( $this, 'apply_smart_cod_settings' ) );
				add_action( 'woocommerce_update_order_review_fragments', array( $this, 'apply_custom_message' ) );
			}
			add_action( 'woocommerce_checkout_create_order_fee_item', array( $this, 'enrich_meta' ), 10, 4 );
			add_action( 'woocommerce_checkout_update_order_meta', array( $this, 'enrich_order_meta' ), 10, 1 );
			add_filter( 'woocommerce_get_order_item_totals', array( $this, 'fix_order_pay' ), 20, 2 );
			add_action( 'woocommerce_before_pay_action', array( $this, 'before_pay_action' ), 10, 1 );
		}

	}

	protected function maybe_set_custom_cod_description( $description, $mode ) {

		if ( $mode === 'extra_fee' && $this->custom_description_set['extra_fee'] ) {
			return;
		}

		if ( $mode === 'rf_fee' && $this->custom_description_set['rf_fee'] ) {
			return;
		}

		$gateways = WC()->payment_gateways->get_available_payment_gateways();

		if ( empty( $gateways ) || ! isset( $gateways['cod'] ) ) {
			return;
		}

		$original_description                  = $gateways['cod']->description;
		$gateways['cod']->description          = $original_description . '<p class="wsc-desc-mode ' . $mode . '">' . $description . '.</p>';
		$this->custom_description_set[ $mode ] = true;
	}

	public function enrich_order_meta( $order_id ) {
		$order = wc_get_order( $order_id );

		foreach ( $order->get_fees() as $fee ) {
			if ( $fee->get_meta( 'wsc_extra_fee' ) === '1' ) {
				$order->add_meta_data( 'wsc_extra_fee_id', $fee->get_id(), true );
				$order->save();
			}
		}

	}

	public function enrich_meta( $item, $fee_key, $fee, $order ) {

		$target = 'wsc_extra_fee';

		if ( $fee_key === $target ) {
			$item->add_meta_data( $target, 1, true );
		}

		if ( substr( $fee_key, 0, 14 ) === $target . '_' ) {
			$author_id = str_replace( $target . '_', '', $fee_key );
			$item->add_meta_data( $target . '_author_id', $author_id, true );
		}

		return $item;
	}

	public function before_pay_action( $order ) {
		$cod_recalculation = $order->get_meta( 'wsc_recalculation' );
		if ( $cod_recalculation === '1' ) {
			$cod_recalculation_mode = $order->get_meta( 'wsc_recalculation_mode' );
			if ( $cod_recalculation_mode === 'add' ) {
				$fee               = $order->get_meta( 'wsc_recalculation_fee' );
				$country_code      = $order->get_shipping_country();
				$state             = $order->get_shipping_state();
				$postcode          = $order->get_shipping_postcode();
				$city              = $order->get_shipping_city();
				$calculate_tax_for = array(
					'country'  => $country_code,
					'state'    => $state,
					'postcode' => $postcode,
					'city'     => $city,
				);
				$item_fee          = new WC_Order_Item_Fee();
				$item_fee->set_name( apply_filters( 'wc_smart_cod_fee_title', __( 'Cash on delivery', 'woocommerce' ) ) );
				$item_fee->set_amount( $fee );
				$item_fee->set_tax_status( $this->fee_has_tax() ? 'taxable' : 'none' );
				$item_fee->set_total( $fee );
				if ( $this->fee_has_tax() ) {
					$item_fee->calculate_taxes( $calculate_tax_for );
				}
				$item_fee->add_meta_data( 'wsc_extra_fee', 1, true );
				$order->add_item( $item_fee );

				$order->calculate_totals();
				$order->save();
				$order->add_meta_data( 'wsc_extra_fee_id', $item_fee->get_id(), true );
				$order->save();

			} elseif ( $cod_recalculation_mode === 'subtract' ) {
				$extra_fee_id = $order->get_meta( 'wsc_extra_fee_id' );
				$order->remove_item( $extra_fee_id );
				$order->calculate_totals();
				$order->save();
			}
		}
	}

	public function fix_order_pay( $total_rows, $order ) {
		/**
		 * Refactor
		 */
		if ( ! $this->adjusting_order_pay && ! is_wc_endpoint_url( 'order-pay' ) ) {
			return $total_rows;
		}

		if ( $order->get_payment_method() === 'cod' ) {
			if ( ( ! isset( $_POST['payment_method'] ) || $_POST['payment_method'] !== 'cod' ) ) {
				$extra_fee_id = $order->get_meta( 'wsc_extra_fee_id' );

				if ( isset( $total_rows[ 'fee_' . $extra_fee_id ] ) ) {
					unset( $total_rows[ 'fee_' . $extra_fee_id ] );
				}

				$cod_tax = 0;

				$fees = $order->get_fees();
				$fee  = 0;
				foreach ( $fees as $_fee ) {
					if ( $_fee->get_meta( 'wsc_extra_fee' ) === '1' ) {
						$fee = $_fee->get_total();
					}
				}
				if ( $this->fee_has_tax() ) {
					// TODO: get tax from fee
					$cod_tax = $this->calculate_fee_tax( $fee );
				}

				$new_total                          = $order->get_total() - $fee - $cod_tax;
				$total_rows['order_total']['value'] = wc_price( $new_total );
				$total_rows                         = $this->add_value_to_assoc_array(
					$total_rows,
					'payment_method',
					array(
						'wsc_fee_tax' => array(
							'label' => apply_filters( 'wc_smart_cod_fee_title', __( 'Cash on delivery', 'woocommerce' ) ) . ' - ' . __( 'removed tax', 'wc-smart-cod' ) . ':',
							'value' => wc_price( -$cod_tax ),
						),
					),
					false
				);

				$order->update_meta_data( 'wsc_recalculation', 1, true );
				$order->update_meta_data( 'wsc_recalculation_mode', 'subtract', true );
				$order->save();

			} else {
				$order->delete_meta_data( 'wsc_recalculation' );
				$order->delete_meta_data( 'wsc_recalculation_mode' );
			}
			return $total_rows;
		}

		if ( ( ! isset( $_POST['payment_method'] ) || $_POST['payment_method'] !== 'cod' ) ) {
			$cod_recalculation = $order->get_meta( 'wsc_recalculation' );
			if ( $cod_recalculation === '1' ) {
				$order->delete_meta_data( 'wsc_recalculation' );
				$order->delete_meta_data( 'wsc_recalculation_fee' );
				$order->delete_meta_data( 'wsc_recalculation_mode' );
				$order->save();
			}
			return $total_rows;
		}

		$fee = $this->calculate_smartcod_fees( $order->get_total() );

		if ( $fee ) {

			$total_rows = $this->add_value_to_assoc_array(
				$total_rows,
				'shipping',
				array(
					'wsc_fee' => array(
						'label' => apply_filters( 'wc_smart_cod_fee_title', __( 'Cash on delivery', 'woocommerce' ) ) . ':',
						'value' => wc_price( $fee ),
					),
				)
			);

			$cod_tax = 0;

			if ( $this->fee_has_tax() ) {
				// TODO: get accurate calculation
				$cod_tax    = $this->calculate_fee_tax( $fee );
				$total_rows = $this->add_value_to_assoc_array(
					$total_rows,
					'wsc_fee',
					array(
						'wsc_fee_tax' => array(
							'label' => apply_filters( 'wc_smart_cod_fee_title', __( 'Cash on delivery', 'woocommerce' ) ) . ' - ' . apply_filters( 'wc_smart_cod_fee_tax_title', __( 'tax', 'wc-smart-cod' ) ) . ':',
							'value' => wc_price( $cod_tax ),
						),
					)
				);
			}

			$new_total                          = $fee + $cod_tax + $order->get_total();
			$total_rows['order_total']['value'] = wc_price( $new_total );

			$order->update_meta_data( 'wsc_recalculation', 1, true );
			$order->update_meta_data( 'wsc_recalculation_mode', 'add', true );
			$order->update_meta_data( 'wsc_recalculation_fee', $fee, true );
			$order->save();

		}

		return $total_rows;
	}

	protected function calculate_fee_tax( $fee ) {
		if ( ! $this->fee_has_tax() ) {
			return 0;
		}
		$rates = WC_Tax::get_rates();
		return array_sum( WC_Tax::calc_tax( $fee, $rates ) );
	}

	public function add_value_to_assoc_array( $array, $key, $value, $after = true ) {
		$offset = array_search( $key, array_keys( $array ) );

		$result = array_merge(
			array_slice( $array, 0, $after ? $offset + 1 : $offset ),
			$value,
			array_slice( $array, $offset, null )
		);

		return $result;
	}

	public function wsc_order_pay() {

		if ( ! $this->are_extrafees_enabled() ) {
			return;
		}

		$this->adjusting_order_pay = true;

		$available_gateways = WC()->payment_gateways->get_available_payment_gateways();

		$order          = new WC_Order( $_POST['order_id'] );
		$payment_method = $_POST['payment_method'];

		if ( count( $available_gateways ) ) {
			if ( isset( $available_gateways[ $payment_method ] ) ) {
				$available_gateways[ $payment_method ]->set_current();
			} else {
				current( $available_gateways )->set_current();
			}
		}

		ob_start();
		wc_get_template(
			'checkout/form-pay.php',
			array(
				'order'              => $order,
				'available_gateways' => $available_gateways,
				'order_button_text'  => apply_filters( 'woocommerce_pay_order_button_text', __( 'Pay for order', 'woocommerce' ) ),
			)
		);
		$contents = ob_get_contents();
		ob_end_clean();
		wp_die( json_encode( $contents, true ) );

	}

	protected function check_user_applies_rule( $settings = null, $targets = null ) {
		$rules = $this->get_rf_rules( $settings );
		if ( empty( $rules ) ) {
			return null;
		}
		$active_rule = null;
		foreach ( $rules as $rule ) {
			if ( ! $rule['active'] ) {
				continue;
			}
			if ( ! $rule['restrictions'] || empty( $rule['restrictions'] ) ) {
				$active_rule = $rule;
				break;
			} else {
				$_check = $this->check_user_applies_restrictions( $rule['restrictions'], $targets );
				if ( $_check ) {
					$active_rule = $rule;
					break;
				}
			}
		}
		return $active_rule;
	}

	protected function get_user_rules_map( $settings = null, $targets = null, $key = 'wcfm_vendors_restriction', $should_have_vendors = true ) {
		$rules = $this->get_rf_rules( $settings );
		$map   = array();
		if ( empty( $rules ) ) {
			return $map;
		}

		foreach ( $rules as $rule ) {
			if ( ! $rule['active'] ) {
				continue;
			}

			if ( ! $rule['restrictions'] || empty( $rule['restrictions'] ) ) {
				continue;
			}

			if ( $should_have_vendors && ( ! isset( $rule['restrictions'][ $key ] ) || ! $rule['restrictions'][ $key ]
			|| empty( $rule['restrictions'][ $key ] ) ) ) {
				continue;
			}

			if ( $this->check_user_applies_restrictions( $rule['restrictions'], $targets ) ) {
				$map[] = $rule;
			}
		}
		return $map;
	}

	protected function check_user_applies_restrictions( $restrictions, $targets = null ) {

		if ( ! isset( $restrictions['restriction_settings'] ) ) {
			$mode_map = array();
			foreach ( $restrictions as $key => $restriction ) {
				// enabled by default
				if ( array_key_exists( $key, self::$targets ) ) {
					$mode_map[ $key ] = 1;
				}
			}
		} else {
			$mode_map = json_decode( $restrictions['restriction_settings'], true );
		}
		$restrictions['restriction_settings'] = json_encode( $mode_map );
		$_restrictions                        = $this->analyze_settings( $restrictions, true, $targets );
		return $this->determine_cod_availability( $_restrictions, false );
	}

	protected function get_rf_rules( $settings = null ) {
		if ( is_null( $settings ) ) {
			$settings = $this->mode === 'risk-free' ? $this->get_rf_settings() : $this->get_extrafees_settings();
		}

		if ( ! $settings || ! isset( $settings['rules'] ) || empty( $settings['rules'] ) ) {
			return array();
		}

		return $settings['rules'];

	}

	public function calculate_smartcod_fees( $total = null ) {
		$fee     = null;
		$targets = Wc_Smart_Cod_Risk_Free_Admin::$default_restriction_settings;
		$rule    = $this->check_user_applies_rule( $this->get_extrafees_settings(), $targets );

		if ( $rule ) {
			$fee = $this->get_user_advance_amount( $rule['fee'], $rule['fee_type'], 'percentage_calculation', $total );
		}
		return $fee;
	}

	protected function get_user_advance_amount( $fee, $fee_type, $mode, $total = null ) {
		switch ( $fee_type ) {
			case 'fixed': {
				return $fee;
			}
			case 'percentage': {
				return $this->calculate_percentage( $fee, $mode, $total );
			}
		}
		return null;
	}

	protected function are_extrafees_enabled() {

		$settings = $this->get_extrafees_settings();
		return isset( $settings['enabled'] ) && $settings['enabled'] === 'yes' && isset( $settings['rules'] ) && ! empty( $settings['rules'] );

	}

	public function is_cod_selected() {
		$payment_gateway = empty( $_POST['payment_method'] ) ? '' : wc_clean( wp_unslash( $_POST['payment_method'] ) );

		if ( ! $payment_gateway ) {

			$payment_gateway = WC()->session->get( 'chosen_payment_method' );

			// WooCommerce issue
			// when it's only
			// one gateway

			if ( ! $payment_gateway ) {
				$available_gateways = WC()->payment_gateways->get_available_payment_gateways();
				if ( ! empty( $available_gateways ) && current( array_keys( $available_gateways ) ) === 'cod' ) {
					$payment_gateway = 'cod';
				}
			}
		}
		return $payment_gateway === 'cod';
	}

	protected function analyze_settings( $cod_settings = null, $return = false, $targets = null ) {

		if ( is_null( $targets ) ) {
			$targets = self::$targets;
		}

		if ( ! $cod_settings ) {
			$cod_settings = $this->cod_settings;
		}

		$restriction_settings = array_key_exists( 'restriction_settings', $cod_settings ) ? json_decode( $cod_settings['restriction_settings'], true ) : array();
		$fee_settings         = array_key_exists( 'fee_settings', $cod_settings ) ? json_decode( $cod_settings['fee_settings'], true ) : array();

		$restriction_modes = wp_parse_args(
			$restriction_settings,
			$targets
		);

		$restriction_settings = array(
			'includes' => array(),
			'excludes' => array(),
		);

		if( isset( $cod_settings[ 'invoice_restriction' ] ) 
		&& $cod_settings[ 'invoice_restriction' ] === 'yes' ) {
			$restriction_settings[ 'excludes' ][ 'invoice_restriction' ] = $cod_settings[ 'invoice_restriction' ];
		}

		foreach ( $restriction_modes as $k => $v ) {

			if ( ! array_key_exists( $k, $cod_settings ) ) {
				unset( $restriction_modes[ $k ] );
				continue;
			}

			if ( $cod_settings[ $k ] === '' || ( is_array( $cod_settings[ $k ] ) && empty( $cod_settings[ $k ] ) ) ) {
				unset( $restriction_modes[ $k ] );
				continue;
			}

			if ( in_array( $k, Wc_Smart_Cod::$bulk_data_keys ) && is_array( $cod_settings[ $k ] ) ) {
				if ( $cod_settings[ $k ]['textarea'] === '' && ( ! isset( $cod_settings[ $k ]['file'] ) || empty( $cod_settings[ $k ]['file'] ) ) ) {
					unset( $restriction_modes[ $k ] );
					continue;
				}
			}

			$key = $v === 0 ? 'excludes' : 'includes';
			if ( $k === 'nocharge_amount' ) {
				$this->nocharge_amount_mode = $key;
			} elseif ( $k === 'product_restriction' || $k === 'category_restriction' || $k === 'shipping_class_restriction' || $k === 'weight_restriction'
			|| $k === 'sku_product_restriction' || $k === 'dokan_vendors_restriction' ) {
				$restriction_settings[ $key ][ $k ] = array(
					'value' => $cod_settings[ $k ],
					'mode'  => isset( $cod_settings[ $k . '_mode' ] ) ? $cod_settings[ $k . '_mode' ] : '',
				);
			} else {
				$restriction_settings[ $key ][ $k ] = $cod_settings[ $k ];
			}
		}

		if ( $this->has_native_zone_method() ) {
			// native wc setting
			// enabled ignore ours
			unset( $restriction_settings['shipping_zone_method_restriction'] );
		}

		if ( $return ) {
			return $restriction_settings;
		}

		$this->restriction_settings = $restriction_settings;
		$this->fee_settings         = $this->analyze_fee_settings( $fee_settings );

	}

	protected function analyze_fee_settings( $fee_settings ) {

		$fee_table = array(
			'check_overthelimit'  => array(),
			'check_country'       => array(),
			'check_zoneandmethod' => array(),
			'check_zone'          => array(),
			'check_method'        => array(),
			'check_normal_fee'    => array(),
		);

		foreach ( $this->cod_settings as $k => $v ) {

			if ( ( $k === 'extra_fee' || $k === 'nocharge_amount' || strpos( $k, 'different_charge' ) !== false ) && is_numeric( $v ) ) {

				$value = array(
					'fee'  => $v,
					'type' => array_key_exists( $k, $fee_settings ) && in_array( $fee_settings[ $k ], array( 'fixed', 'percentage' ) ) ? $fee_settings[ $k ] : 'fixed',
					'key'  => $k,
				);

				if ( $k === 'extra_fee' ) {
					array_push( $fee_table['check_normal_fee'], $value );
				} elseif ( $k === 'nocharge_amount' ) {
					array_push( $fee_table['check_overthelimit'], $value );
				} else {
					$key = explode( 'different_charge', $k );
					$key = $key[0];

					switch ( $key ) {

						case '': {
							array_push( $fee_table['check_zone'], $value );
							break;
						}

						case 'zonemethod_': {
							array_push( $fee_table['check_zoneandmethod'], $value );
							break;
						}

						case 'include_country_': {
							array_push( $fee_table['check_country'], $value );
							break;
						}

						case 'method_': {
							array_push( $fee_table['check_method'], $value );
							break;
						}

					}
				}
			}
		}

		return array_filter( array_map( 'array_filter', $fee_table ) );

	}

	protected function has_native_zone_method() {
		return Wc_Smart_Cod::wc_version_check()
		&& isset( $this->cod_settings['enable_for_methods'] )
		&& ! empty( $this->cod_settings['enable_for_methods'] );
	}

	public function get_cod_message( $reason, $settings ) {

		if ( ! isset( $settings['cod_unavailable_message'] ) ) {
			return false;
		}

		$messages = $settings['cod_unavailable_message'];

		if ( ! is_array( $messages ) ) {
			// backwards compatibility
			// before 1.4.4
			if ( trim( $messages ) !== '' ) {
				return $messages;
			} else {
				return false;
			}
		}

		if ( ! $reason ) {
			if ( array_key_exists( 'generic', $messages ) && trim( $messages['generic'] ) !== '' ) {
				return $messages['generic'];
			}
		}

		if ( $reason === 'restrict_postals' ) {
			$reason = 'postal';
		} else {
			// extract _restriction
			$reason = substr( rtrim( $reason, 's' ), 0, -12 );
		}

		if ( ! array_key_exists( $reason, $messages ) || trim( $messages[ $reason ] ) === '' ) {
			if ( array_key_exists( 'generic', $messages ) && trim( $messages['generic'] ) !== '' ) {
				return $messages['generic'];
			}
		} else {
			return $messages[ $reason ];
		}

		return false;

	}

	public function init_wsc_settings() {

		if ( ! $this->settings_analyzed ) {
			$this->get_cod_settings();
			$this->analyze_settings();
			$this->settings_analyzed = true;
		}

	}

	public static function has_checkout_wc() {
		// check if CheckoutWC plugin is installed
		return defined( 'CFW_NAME' ) && CFW_NAME === 'Checkout for WooCommerce';
	}

	public function apply_custom_message( $data ) {

		$this->init_wsc_settings();
		if ( $this->has_cod_available() === false ) {

			$settings = $this->get_cod_settings();
			$message  = $this->get_cod_message( $this->reason, $settings );

			if ( $message ) {

				$doc = new DOMDocument();

				$target_key = self::has_checkout_wc() ? '#cfw-billing-methods' : '.woocommerce-checkout-payment';

				$doc->loadHTML( mb_convert_encoding( $data[ $target_key ], 'HTML-ENTITIES', 'UTF-8' ) );
				$doc->preserveWhiteSpace = false;
				$payment_div             = $doc->getElementById( 'payment' );
				if ( $payment_div ) {
					$fragment = $doc->createDocumentFragment();
					$fragment->appendXML( '<div class="woocommerce-info cod-unavailable">' . $message . '</div>' );
					if ( $payment_div->hasChildNodes() ) {
						$first_element = $payment_div->childNodes->item( 0 );
						$first_element->parentNode->insertBefore( $fragment, $first_element );
					} else {
						$payment_div->appendChild( $fragment );
					}

					$doc->removeChild( $doc->doctype );
					$doc->replaceChild( $doc->firstChild->firstChild->firstChild, $doc->firstChild );

					$data[ $target_key ] = $doc->saveHTML();
				}
			}
		}

		return $data;

	}

	protected function get_cod_settings() {

		if ( ! empty( $this->cod_settings ) ) {
			return $this->cod_settings;
		}

		return $this->cod_settings = get_option( 'woocommerce_cod_settings' );

	}

	private function is_new_wc() {
		return class_exists( 'WC_Shipping_Zones' );
	}

	private function get_customer_shipping_zone( $cart ) {

		$package = $cart->get_shipping_packages();

		if ( ! is_array( $package ) || ! isset( $package[0] ) ) {
			return false;
		}

		$package                = $package[0];
		$customer_shipping_zone = WC_Shipping_Zones::get_zone_matching_package( $package );

		return $customer_shipping_zone->get_id();

	}

	private function get_customer_shipping_method( $inside_zone = false, $full = false ) {

		global $woocommerce;

		$packages    = WC()->shipping->get_packages();
		$chosen_rate = isset( $_POST['shipping_method'] ) ? $_POST['shipping_method'] : false;

		if ( ! $chosen_rate ) {
			$chosen_rate = WC()->session->get( 'chosen_shipping_methods' );
		}

		if ( ! $chosen_rate ) {
			return false;
		}

		$chosen_rate = current( $chosen_rate );
		$id          = $this->get_method_id( $chosen_rate, $inside_zone, $packages );

		if ( $id === false ) {
			// check again for a possible
			// rate change with cached rate
			$chosen_rate = WC()->session->get( 'chosen_shipping_methods' );
			$chosen_rate = current( $chosen_rate );
			$id          = $this->get_method_id( $chosen_rate, $inside_zone, $packages );
		}

		return $full ? $chosen_rate : $id;

	}

	protected function get_method_id( $chosen_rate, $inside_zone, $packages ) {

		foreach ( $packages as $i => $package ) {
			if ( isset( $package['rates'][ $chosen_rate ] ) ) {

				if ( class_exists( 'WCFM_Vendor_Support' ) ) {
					return substr( $package['rates'][ $chosen_rate ]->id, 0, strpos( $package['rates'][ $chosen_rate ]->id, ':' ) );
				}

				if ( ! $inside_zone ) {
					return $package['rates'][ $chosen_rate ]->method_id;
				} else {
					return $package['rates'][ $chosen_rate ]->instance_id;
				}
			}
		}

		return false;
	}

	/**
	 * @deprecated
	 * Deprecated in favor of extra fee addon
	 * @param WC_Cart $cart
	 * @param boolean $apply_fee
	 * @param boolean $addon_call
	 * @return void
	 */
	public function apply_smart_cod_fees( WC_Cart $cart, $apply_fee = true, $addon_call = false ) {
		if ( $apply_fee && ( ! defined( 'DOING_AJAX' ) || ! DOING_AJAX || ! $addon_call ) ) {
			return;
		}

		$this->init_wsc_settings();

		$payment_gateway = isset( $_POST['payment_method'] ) && $_POST['payment_method'] === 'cod' ? 'cod' : '';

		if ( ! $payment_gateway ) {

			$payment_gateway = WC()->session->get( 'chosen_payment_method' );

			// WooCommerce issue
			// when it's only
			// one gateway

			if ( ! $payment_gateway ) {

				$available_gateways = WC()->payment_gateways->get_available_payment_gateways();
				if ( ! empty( $available_gateways ) && current( array_keys( $available_gateways ) ) === 'cod' ) {
					$payment_gateway = 'cod';
				}
			}
		}

		if ( ! $addon_call && ( $payment_gateway !== 'cod' || $this->has_cod_available() === false ) && $apply_fee ) {
			return;
		}

		$settings  = $this->get_cod_settings();
		$is_new_wc = $this->is_new_wc();
		$extra_fee = 0;

		// check for restrictions and policies

		foreach ( $this->fee_settings as $condition => $group ) {

			foreach ( $group as $fee ) {

				if ( ! $is_new_wc && ( $condition === 'check_zoneandmethod' || $condition === 'check_zone' ) ) {
					continue;
				}

				if ( is_numeric( $extra_fee = $this->{$condition}( $fee, $cart ) ) ) {
					if ( $fee['type'] === 'percentage' ) {
						$extra_fee = $this->calculate_percentage( $extra_fee );
					}
					break 2;
				}
			}
		}

		$extra_fee = apply_filters( 'wc_smart_cod_fee', is_numeric( $extra_fee ) ? $extra_fee : 0, $this->fee_settings );
		if ( $apply_fee ) {
			$this->add_actual_fee( $cart, $extra_fee );
		} else {
			return $extra_fee;
		}

	}

	public static function maybe_get_multicurrency_value( $fee ) {
		if ( class_exists( 'WOOCS' ) && $fee ) {
			global $WOOCS;
			if ( $WOOCS->is_multiple_allowed ) {
				$current = $WOOCS->current_currency;
				if ( $current !== $WOOCS->default_currency ) {
						$currencies = $WOOCS->get_currencies();
						$rate       = $currencies[ $current ]['rate'];
						$fee        = $fee * $rate;
				}
			}
		}
		return $fee;
	}

	protected function fee_has_tax() {
		$settings = $this->get_extrafees_settings();
		return ( wc_tax_enabled() && isset( $settings['extra_fee_tax'] ) && $settings['extra_fee_tax'] === 'enable' );
	}

	protected function add_actual_fee( $cart, $fee ) {
		$extra_fee = $fee['amount'];
		$name      = $fee['name'];
		$id        = $fee['id'];
		if ( $extra_fee > 0 ) {
			$has_tax = $this->fee_has_tax();
			$cart->fees_api()->add_fee(
				array(
					'id'        => $id,
					'name'      => $name,
					'amount'    => (float) $extra_fee,
					'taxable'   => $has_tax,
					'tax_class' => '',
				)
			);
		}
	}

	public function get_extrafees_settings() {
		if ( ! $this->extrafees_settings ) {
			$this->extrafees_settings = get_option( self::$extrafees_option_name );
		}
		return $this->extrafees_settings;
	}

	protected function get_rounding( $mode ) {
		$settings = $mode === 'rf_percentage_calculation' ? $this->get_rf_settings() : $this->get_extrafees_settings();
		if ( ! isset( $settings['percentage_rounding'] ) || ! is_string( $settings['percentage_rounding'] ) || ! in_array( $settings['percentage_rounding'], array( 'round_up', 'round_down', 'no_round' ) ) ) {
			return 'round_up';
		}
		return $settings['percentage_rounding'];
	}

	protected function wsc_get_total( $mode = 'full', $settings = array() ) {

		$cart  = WC()->cart;
		$total = $cart->cart_contents_total;

		$total_override = WC()->session->get( 'cart_override' );
		if( $total_override ) {
			return floatval( $total_override );
		}

		if ( ! $total ) {
			return 0;
		}

		$settings = array();

		switch ( $mode ) {
			case 'percentage_calculation': {
				$_settings = $this->get_extrafees_settings();
				if ( array_key_exists( 'percentage_settings', $_settings ) ) {
					$settings = $_settings['percentage_settings'];
				}
				break;
			}
			case 'cart_amount_calculation': {
				$_settings = $this->get_cod_settings();
				if ( array_key_exists( 'cart_amount_mode', $_settings ) ) {
					$settings = $_settings['cart_amount_mode'];
				}
				break;
			}
			case 'rf_percentage_calculation': {
				$_settings = $this->get_rf_settings();
				if ( array_key_exists( 'percentage_settings', $_settings ) ) {
					$settings = $_settings['percentage_settings'];
				}
				break;
			}
			case 'full': {
				$settings = array( 'tax', 'shipping', 'fees' );
				break;
			}
		}

		$current_action = current_action();

		if ( $current_action === 'woocommerce_after_calculate_totals' && count( $settings ) === 3 && $mode !== 'cart_amount_calculation' ) {
			return floatval( $cart->get_totals()['total'] );
		}

		$include_tax = wc_tax_enabled() && in_array( 'tax', $settings );

		if ( $include_tax ) {
			$taxes = $cart->get_taxes();
			foreach ( $taxes as $tax ) {
				$total = $total + $tax;
			}
			if ( $current_action !== 'woocommerce_after_calculate_totals' ) {
				$total += $this->get_fee_taxes();
			}
		}

		if ( in_array( 'shipping', $settings ) ) {
			$total = $total + floatval( $cart->shipping_total );
		}

		if ( in_array( 'fees', $settings ) && $mode !== 'cart_amount_calculation' ) {
			$fees = $cart->get_fees();
			if ( ! empty( $fees ) ) {
				$fees_total = array_sum( wp_list_pluck( $fees, 'amount' ) );
				$total     += $fees_total;
			}
		}

		return floatval( $total );

	}

	protected function get_fee_taxes() {
		$cart       = WC()->cart;
		$fees       = $cart->get_fees();
		$tax_amount = 0;

		foreach ( $fees as $fee ) {
			if ( $fee->taxable ) {
				$rates       = WC_Tax::get_rates( $fee->tax_class );
				$tax_amount += array_sum( WC_Tax::calc_tax( $fee->amount, $rates ) );
			}
		}

		return $tax_amount;
	}

	protected function calculate_percentage( $percentage, $mode = 'percentage_calculation', $total = null ) {

		$_total    = is_null( $total ) ? $this->wsc_get_total( $mode ) : $total;
		$extra_fee = ( $percentage * $_total ) / 100;
		$rounding  = $this->get_rounding( $mode );

		if ( ! $rounding || $rounding === 'no_round' ) {
			return $extra_fee;
		}

		$fee = $rounding === 'round_up' ? ceil( $extra_fee ) : floor( $extra_fee );

		return $fee < 1 ? 1 : $fee;

	}

	protected function get_cart_products( $cart, $full_product = false ) {
		$items    = $cart->get_cart();
		$products = array();
		foreach ( $items as $key => $item ) {
			$id = isset( $item['variation_id'] ) && $item['variation_id'] !== 0 ? $item['variation_id'] : $item['product_id'];
			array_push( $products, $full_product ? $item : $id );
		}
		return $this->cart_products = $products;
	}

	protected static function check_for_bulks_db( $collection_data, $enable ) {
		if ( ! isset( $collection_data['collection_id'] ) || ! $collection_data['collection_id'] ) {
			return true;
		}
		$tables        = Wc_Smart_Cod::$tables;
		$collection_id = $collection_data['collection_id'];
		global $wpdb;
		$collection = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . $tables['collections'] . ' WHERE id = %d', $collection_id ) );

		if ( ! $collection ) {
			return true;
		}

		$value = self::get_userdata_by_restriction( $collection->field_key );
		$id    = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . $tables['records'] . ' WHERE collection_id = %d AND value = %s', $collection_id, $value ) );
		if ( ! is_null( $id ) ) {
			return $enable;
		}
		return ! $enable;
	}

	protected static function get_userdata_by_restriction( $key ) {
		switch ( $key ) {
			case 'user_phone_restriction': {
				return self::get_user_refreshed_data( 'billing_phone' );
			}
			case 'user_email_restriction': {
				return self::get_user_refreshed_data( 'billing_email' );
			}
			case 'restrict_postals': {
				return self::get_user_refreshed_data( 'shipping_postcode' );
			}
		}
		return '';
	}

	protected static function check_for_bulks( $key, $value, $enable, $has_cod_available ) {

		$should_continue = false;

		if ( in_array( $key, Wc_Smart_Cod::$bulk_data_keys ) ) {

			if ( is_array( $value ) ) {

				if ( isset( $value['file'] ) && is_array( $value['file'] ) ) {
					$has_cod_available = self::check_for_bulks_db( $value['file'], $enable );
					if ( $has_cod_available && $enable ) {
						$should_continue = true;
					}
				}

				$value = isset( $value['textarea'] ) ? $value['textarea'] : '';
			}
		}

		return array(
			'value'             => $value,
			'has_cod_available' => $has_cod_available,
			'should_continue'   => $should_continue,
		);
	}

	protected function determine_cod_availability( $restriction_settings = null, $setup_reason = true ) {

		$has_cod_available = true;

		if ( ! $restriction_settings ) {
			$restriction_settings = $this->restriction_settings;
		}

		if ( empty( $restriction_settings ) ) {
			$restriction_settings = array(
				'includes' => array(),
				'excludes' => array(),
			);
		}

		foreach ( $restriction_settings['includes'] as $key => $value ) {
			if ( ! method_exists( $this, "check_$key" ) ) {
				continue;
			}

			$bulk_data         = self::check_for_bulks( $key, $value, true, $has_cod_available );
			$has_cod_available = $bulk_data['has_cod_available'];
			$value             = $bulk_data['value'];

			if ( $bulk_data['should_continue'] ) {
				continue;
			}

			$has_cod_available = $this->{ 'check_' . $key }( $value, true, $has_cod_available );
			if ( ! $has_cod_available ) {
				if ( $setup_reason ) {
					$this->reason = $key;
				}
				break;
			}
		}

		if ( $has_cod_available ) {

			foreach ( $restriction_settings['excludes'] as $key => $value ) {
				if ( ! method_exists( $this, "check_$key" ) ) {
					continue;
				}

				$bulk_data         = self::check_for_bulks( $key, $value, false, $has_cod_available );
				$has_cod_available = $bulk_data['has_cod_available'];
				$value             = $bulk_data['value'];
				if ( ! $has_cod_available ) {
					if ( $setup_reason ) {
						$this->reason = $key;
					}
					break;
				}

				$has_cod_available = $this->{ 'check_' . $key }( $value, false, $has_cod_available );
				if ( ! $has_cod_available ) {
					if ( $setup_reason ) {
						$this->reason = $key;
					}
					break;
				}
			}
		}

		return $has_cod_available;

	}

	public function has_cod_available() {

		if ( $this->has_cod_available ) {
			return $this->has_cod_available;
		}

		$this->calculated_availability = $this->determine_cod_availability();

		return $this->has_cod_available = apply_filters( 'wc_smart_cod_available', $this->calculated_availability, $this->restriction_settings );

	}

	/**
	 * Check cod availability
	 * begin
	 */

	protected function check_shipping_method_restriction( $restrictions, $enable, $has_cod_available ) {
		$shipping_method = $this->get_customer_shipping_method();

		if ( ! $shipping_method ) {
			return $has_cod_available;
		}

		return $enable ? in_array( $shipping_method, $restrictions ) : ! in_array( $shipping_method, $restrictions );

	}

	protected function check_shipping_zone_restrictions( $restriction, $enable, $has_cod_available ) {

		global $woocommerce;
		$cart    = $woocommerce->cart;
		$package = $cart->get_shipping_packages();

		if ( ! is_array( $package ) || ! isset( $package[0] ) ) {
			return $has_cod_available;
		}

		$package                = $package[0];
		$customer_shipping_zone = WC_Shipping_Zones::get_zone_matching_package( $package );

		if ( ! $customer_shipping_zone ) {
			return $has_cod_available;
		}

		if ( $enable ) {
			return in_array( $customer_shipping_zone->get_id(), $restriction );
		} else {
			if ( in_array( $customer_shipping_zone->get_id(), $restriction ) ) {
				return false;
			}
		}

		return $has_cod_available;

	}

	protected function check_shipping_zone_method_restriction( $restriction, $enable, $has_cod_available ) {

		global $woocommerce;
		$cart                          = $woocommerce->cart;
		$customer_shipping_zone        = $this->get_customer_shipping_zone( $cart );
		$customer_shipping_zone_method = $this->get_customer_shipping_method( true );

		if ( $customer_shipping_zone_method === false || $customer_shipping_zone === false ) {
			return $has_cod_available;
		}

		$needle = $customer_shipping_zone . '_' . $customer_shipping_zone_method;

		if ( $enable ) {
			return in_array( $needle, $restriction );
		} else {
			if ( in_array( $needle, $restriction ) ) {
				return false;
			}
		}

		return $has_cod_available;
	}

	protected function check_restrict_postals( $restriction, $enable, $has_cod_available ) {

		$postals            = explode( ',', trim( $restriction ) );
		$postals            = array_map( 'trim', $postals );
		$customer_post_code = self::get_user_refreshed_data( 'shipping_postcode' );

		if ( ! $customer_post_code ) {
			return $has_cod_available;
		}

		foreach ( $postals as $p ) {
			if ( ! $p ) {
				continue;
			}
			$prepare = explode( '...', $p );
			$count   = count( $prepare );
			if ( $count === 1 ) {
				// single
				if ( $prepare[0] === $customer_post_code ) {
					return $enable;
				}
			} elseif ( $count === 2 ) {
				// range
				if ( ! is_numeric( $prepare[0] ) || ! is_numeric( $prepare[1] ) || ! is_numeric( $customer_post_code ) ) {
					continue;
				}

				if ( $customer_post_code >= $prepare[0] && $customer_post_code <= $prepare[1] ) {
					return $enable;
				}
			} else {
				continue;
			}
		}

		if ( $enable ) {
			return false;
		}

		return $has_cod_available;

	}

	protected function check_city_restrictions( $restriction, $enable, $has_cod_available ) {

		$customer_city = self::get_user_refreshed_data( 'shipping_city' );

		if ( ! $customer_city ) {
			return $has_cod_available;
		}

		$customer_city = trim( $customer_city );

		$restriction = explode( ',', trim( $restriction ) );
		$restriction = array_map( 'trim', $restriction );
		$restriction = array_map( 'strtolower', $restriction );

		if ( $enable ) {
			return in_array( strtolower( $customer_city ), $restriction );
		} else {
			if ( in_array( strtolower( $customer_city ), $restriction ) ) {
				return false;
			}
		}

		return $has_cod_available;

	}

	protected function check_country_restrictions( $restriction, $enable, $has_cod_available ) {

		$customer_country = self::get_user_refreshed_data( 'shipping_country' );

		if ( ! $customer_country ) {
			return $has_cod_available;
		}

		if ( $enable ) {
			return in_array( $customer_country, $restriction );
		} else {
			if ( in_array( $customer_country, $restriction ) ) {
				return false;
			}
		}

		return $has_cod_available;

	}

	protected function check_state_restrictions( $restriction, $enable, $has_cod_available ) {

		$customer_country = self::get_user_refreshed_data( 'shipping_country' );
		$customer_state   = self::get_user_refreshed_data( 'shipping_state' );
		$needle           = $customer_country . '_' . $customer_state;

		if ( ! $customer_country || ! $customer_state ) {
			return $has_cod_available;
		}

		if ( $enable ) {
			return in_array( $needle, $restriction );
		} else {
			if ( in_array( $needle, $restriction ) ) {
				return false;
			}
		}

		return $has_cod_available;

	}

	protected function check_cart_amount_restriction( $restriction, $enable, $has_cod_available ) {

		$total = $this->wsc_get_total( 'cart_amount_calculation' );

		if ( ! $total ) {
			return $has_cod_available;
		}

		if ( $enable ) {
			if ( $total < $restriction ) {
				return false;
			}
		} else {
			if ( $total >= $restriction ) {
				return false;
			}
		}

		return $has_cod_available;

	}

	protected function check_cart_range_restriction( $restriction, $enable, $has_cod_available ) {

		$total = $this->wsc_get_total( 'cart_amount_calculation' );
		$from  = $restriction['from'] ? $restriction['from'] : null;
		$to    = $restriction['to'] ? $restriction['to'] : null;

		if ( ! $total ) {
			return $has_cod_available;
		}

		$valid = true;

		if ( $from && $total < $from ) {
			$valid = false;
		}

		if ( $to && $total > $to ) {
			$valid = false;
		}

		return $enable ? $valid : ! $valid;

	}

	protected function check_user_restriction( $restriction, $enable, $has_cod_available ) {
		if ( $enable && ! is_user_logged_in() ) {
			return false;
		}
		$current_user = wp_get_current_user();
		return $enable ? in_array( $current_user->ID, $restriction ) : ! in_array( $current_user->ID, $restriction );
	}

	protected function check_user_email_restriction( $restriction, $enable, $has_cod_available ) {

		$customer_email = self::get_user_refreshed_data( 'billing_email' );
		if ( $customer_email === '' ) {
			return $has_cod_available;
		}
		$user_emails = explode( ',', trim( $restriction ) );
		$user_emails = array_map( 'trim', $user_emails );

		return $enable ? in_array( $customer_email, $user_emails ) : ! in_array( $customer_email, $user_emails );

	}

	protected function check_user_phone_restriction( $restriction, $enable, $has_cod_available ) {

		$customer_phone = self::get_user_refreshed_data( 'billing_phone' );
		if ( $customer_phone === '' ) {
			return $has_cod_available;
		}
		$phones = preg_split( '/\r\n|\r|\n/', trim( $restriction ) );
		$phones = array_map( 'trim', $phones );

		return $enable ? in_array( $customer_phone, $phones ) : ! in_array( $customer_phone, $phones );

	}

	protected function check_coupon_restriction( $restriction, $enable, $has_cod_available ) {

		if( ! is_array( $restriction ) ) {
			return $has_cod_available;
		}

		$restriction = array_filter( $restriction, function( $data ) {
			return $data !== '';
		});

		if( empty( $restriction ) ) {
			return $has_cod_available;
		}
		
		$applied_coupons = WC()->cart->get_applied_coupons();
		if ( $enable && empty( $applied_coupons ) ) {
			return $has_cod_available;
		}
		return $enable ? count( array_intersect( $restriction, $applied_coupons ) ) === count( $applied_coupons ) : count( array_intersect( $restriction, $applied_coupons ) ) === 0;
	}

	protected function check_stock_restriction( $restriction, $enable, $has_cod_available ) {
		$cart_products = $this->get_cart_products( WC()->cart );
		$from          = $restriction['from'] ? $restriction['from'] : null;
		$to            = $restriction['to'] ? $restriction['to'] : null;

		if ( is_null( $from ) && is_null( $to ) ) {
			return $has_cod_available;
		}

		$in_range = true;
		foreach ( $cart_products as $product ) {
			$_product = wc_get_product( $product );
			$stock    = $_product->get_stock_quantity();
			if ( $from && $stock < $from ) {
				$in_range = false;
				break;
			}

			if ( $to && $stock > $to ) {
				$in_range = false;
				break;
			}
		}

		return $enable ? $in_range : ! $in_range;

	}

	protected function check_sku_product_restriction( $restriction, $enable, $has_cod_available ) {

		$cart_products = WC()->cart->get_cart();

		if ( empty( $cart_products ) ) {
			return false;
		}

		if ( ! isset( $restriction['mode'] ) || ! $restriction['mode'] ) {
			$restriction['mode'] = 'one_product';
		}

		if ( ! isset( $restriction['value'] ) || ! is_string( $restriction['value'] ) ) {
			$restriction['value'] = '';
		}

		if ( ! $restriction['value'] ) {
			return $has_cod_available;
		}

		$product_count  = count( $cart_products );
		$restrict_count = 0;

		$skus = preg_split( '/\r\n|\r|\n/', trim( $restriction['value'] ) );
		$skus = array_map( 'trim', $skus );

		foreach ( $cart_products as $product ) {
			$product_id = isset( $product['variation_id'] ) && $product['variation_id'] !== 0 ? $product['variation_id'] : $product['product_id'];
			$_product   = wc_get_product( $product_id );
			$sku        = $_product->get_sku();
			$parent_id  = null;

			if ( $_product->is_type( 'variation' ) ) {
				/**
				 * check if parent is restricted as well
				 */
				$parent_id  = $_product->get_parent_id();
				$parent     = wc_get_product( $parent_id );
				$parent_sku = $parent->get_sku();
			}

			if ( in_array( $sku, $skus ) ||
			! is_null( $parent_id ) &&
			in_array( $parent_sku, $skus )
			) {
				if ( $restriction['mode'] === 'one_product' ) {
					return $enable;
				} else {
					$restrict_count++;
				}
			} else {
				if ( $restriction['mode'] === 'all_products' ) {
					return ! $enable;
				}
			}
		}

		if ( $restriction['mode'] === 'all_products' ) {
			if ( $restrict_count === count( $skus ) ) {
				return $enable;
			} else {
				return ! $enable;
			}
		} else {
			if ( $enable ) {
				return false;
			}
		}

		return $has_cod_available;

	}

	protected function check_dokan_vendors_restriction( $restriction, $enable, $has_cod_available ) {

		$multivendor = Wc_Smart_Cod_MultiVendors_Helper::get_instance();

		if ( ! $multivendor::has_dokan() ) {
			return $has_cod_available;
		}

		if ( empty( $restriction ) ) {
			return $has_cod_available;
		}

		$value = isset( $restriction['value'] ) ? $restriction['value'] : null;
		$mode  = isset( $restriction['mode'] ) && $restriction['mode'] ? $restriction['mode'] : 'one_vendor';

		if ( is_null( $value ) ) {
			return $has_cod_available;
		}

		$cart_products = WC()->cart->get_cart();

		if ( empty( $cart_products ) ) {
			return $has_cod_available;
		}

		$authors = array();

		foreach ( $cart_products as $product ) {
			$author_id = get_post_field( 'post_author', $product['product_id'] );
			if ( ! in_array( $author_id, $authors ) ) {
				$authors[] = $author_id;
			}
		}

		$intersect = array_intersect( $authors, $value );

		switch ( $mode ) {
			case 'one_vendor': {
				if ( count( $intersect ) > 0 ) {
					return $enable;
				}
				return ! $enable;
			}
			case 'all_vendors': {
				if ( count( $intersect ) >= count( $cart_products ) ) {
					return $enable;
				}
				return ! $enable;
			}
		}

		return $has_cod_available;

	}

	protected function check_wcfm_vendors_restriction( $restriction, $enable, $has_cod_available ) {

		if ( ! class_exists( 'WCFM_Vendor_Support' ) ) {
			return $has_cod_available;
		}

		if ( empty( $restriction ) ) {
			return $has_cod_available;
		}

		global $WCFM;

		$cart_products = WC()->cart->get_cart();

		if ( empty( $cart_products ) ) {
			return $has_cod_available;
		}

		foreach ( $cart_products as $product ) {

			$vendor_id = $WCFM->wcfm_vendor_support->wcfm_get_vendor_id_from_product( $product['product_id'] );

			if ( $enable ) {
				if ( in_array( $vendor_id, $restriction ) ) {
					return true;
				}
				$has_cod_available = false;
			} else {
				if ( ! in_array( $vendor_id, $restriction ) ) {
					return true;
				}
				$has_cod_available = false;
			}
		}

		return $has_cod_available;

	}

	protected function check_weight_restriction( $restriction, $enable, $has_cod_available ) {

		$cart_products = WC()->cart->get_cart();
		$value         = isset( $restriction['value'] ) ? $restriction['value'] : null;

		if ( is_null( $value ) ) {
			return $has_cod_available;
		}

		$from = $value['from'] ? $value['from'] : null;
		$to   = $value['to'] ? $value['to'] : null;
		$mode = isset( $restriction['mode'] ) && $restriction['mode'] ? $restriction['mode'] : 'individual';

		if ( is_null( $from ) && is_null( $to ) ) {
			return $has_cod_available;
		}

		$in_range     = true;
		$total_weight = 0;

		foreach ( $cart_products as $product ) {

			$product_id = isset( $product['variation_id'] ) && $product['variation_id'] !== 0 ? $product['variation_id'] : $product['product_id'];
			$_product   = wc_get_product( $product_id );

			$weight       = $_product->get_weight();
			$total_weight = $total_weight + ( $product['quantity'] * floatval( $weight ) );

			if ( $mode === 'individual' ) {

				if ( $from && $weight < $from ) {
					$in_range = false;
					break;
				}

				if ( $to && $weight > $to ) {
					$in_range = false;
					break;
				}
			}
		}

		if ( $mode === 'total' ) {
			if ( $from && $total_weight < $from ) {
				$in_range = false;
			}

			if ( $to && $total_weight > $to ) {
				$in_range = false;
			}
		}

		return $enable ? $in_range : ! $in_range;

	}

	protected function check_product_qty_restriction( $restriction, $enable, $has_cod_available ) {

		$cart_products_qty = WC()->cart->cart_contents_count;
		$from              = $restriction['from'] ? $restriction['from'] : null;
		$to                = $restriction['to'] ? $restriction['to'] : null;

		if ( is_null( $from ) && is_null( $to ) ) {
			return $has_cod_available;
		}

		$in_range = true;

		if ( $from && $cart_products_qty < $from ) {
			$in_range = false;
		}

		if ( $to && $cart_products_qty > $to ) {
			$in_range = false;
		}

		return $enable ? $in_range : ! $in_range;

	}

	protected function check_invoice_restriction( $restriction, $enable, $has_cod_available ) {

		if ( $restriction !== 'yes' ) {
			return $has_cod_available;
		}
		
		if( ! isset( $_POST['post_data'] ) ) {
			return $has_cod_available;
		}

		parse_str( $_POST['post_data'], $data );

		if( isset( $data[ 'billing_invoice' ] ) &&  $data[ 'billing_invoice' ] === 'y' ) {
			return false;
		}

		return $has_cod_available;

	}

	protected function check_backorders_restriction( $restriction, $enable, $has_cod_available ) {

		if ( $restriction !== 'yes' ) {
			return $has_cod_available;
		}

		$items = WC()->cart->get_cart();

		foreach ( $items as $product ) {
			$_product = wc_get_product( $product['product_id'] );
			if ( $_product->is_on_backorder() ) {
				return false;
			}
		}

	}

	protected function check_product_restriction( $restriction, $enable, $has_cod_available ) {

		global $woocommerce;
		$cart = $woocommerce->cart;

		$cart_products = $this->get_cart_products( $cart );

		if ( ! isset( $restriction['mode'] ) || ! $restriction['mode'] ) {
			$restriction['mode'] = 'one_product';
		}

		if ( ! isset( $restriction['value'] ) || ! is_array( $restriction['value'] ) ) {
			$restriction['value'] = array();
		}

		if ( empty( $cart_products ) ) {
			return false;
		}

		$cart_products = array_map( 'strval', $cart_products );

		$product_count  = count( $cart_products );
		$restrict_count = 0;

		foreach ( $cart_products as $product_id ) {

			$_product  = wc_get_product( $product_id );
			$parent_id = null;

			if ( $_product->is_type( 'variation' ) ) {
				/**
				 * check if parent is restricted as well
				 */
				$parent_id = $_product->get_parent_id();
			}

			if ( in_array( $product_id, $restriction['value'] ) ||
			! is_null( $parent_id ) &&
			in_array( $parent_id, $restriction['value'] )
			) {
				if ( $restriction['mode'] === 'one_product' ) {
					return $enable;
				} else {
					$restrict_count++;
				}
			} else {
				if ( $restriction['mode'] === 'all_products' ) {
					return ! $enable;
				}
			}
		}

		if ( $restriction['mode'] === 'all_products' ) {
			if ( $restrict_count === $product_count ) {
				return $enable;
			} else {
				return ! $enable;
			}
		} else {
			if ( $enable ) {
				return false;
			}
		}

		return $has_cod_available;

	}

	protected function check_category_restriction( $restriction, $enable, $has_cod_available ) {

		global $woocommerce;
		$cart = $woocommerce->cart;

		$cart_products = $this->get_cart_products( $cart );

		if ( empty( $cart_products ) ) {
			return false;
		}

		$product_count  = count( $cart_products );
		$restrict_count = 0;

		foreach ( $cart_products as $product_id ) {

			$_product = wc_get_product( $product_id );
			$type     = $_product->get_type();
			if ( $type === 'variation' ) {
				$_product = wc_get_product( $_product->get_parent_id() );
			}
			$category_ids = $_product->get_category_ids();

			if ( array_intersect( $category_ids, $restriction['value'] ) ) {
				if ( $restriction['mode'] === 'one_product' ) {
					return $enable;
				} else {
					$restrict_count++;
				}
			} else {
				if ( $restriction['mode'] === 'all_products' ) {
					return ! $enable;
				}
			}
		}

		if ( $restriction['mode'] === 'all_products' ) {
			if ( $restrict_count === $product_count ) {
				return $enable;
			} else {
				return ! $enable;
			}
		} else {
			if ( $enable ) {
				return false;
			}
		}

		return $has_cod_available;

	}

	protected function check_shipping_class_restriction( $restriction, $enable, $has_cod_available ) {

		global $woocommerce;
		$cart = $woocommerce->cart;

		$cart_products = $this->get_cart_products( $cart );

		if ( empty( $cart_products ) ) {
			return false;
		}

		$product_count  = count( $cart_products );
		$restrict_count = 0;

		foreach ( $cart_products as $product_id ) {
			$product           = wc_get_product( $product_id );
			$shipping_class_id = $product->get_shipping_class_id();
			if ( in_array( $shipping_class_id, $restriction['value'] ) ) {
				if ( $restriction['mode'] === 'one_product' ) {
					return $enable;
				} else {
					$restrict_count++;
				}
			} else {
				if ( $restriction['mode'] === 'all_products' ) {
					return ! $enable;
				}
			}
		}

		if ( $restriction['mode'] === 'all_products' ) {
			if ( $restrict_count === $product_count ) {
				return $enable;
			} else {
				return ! $enable;
			}
		} else {
			if ( $enable ) {
				return false;
			}
		}

		return $has_cod_available;

	}

	protected function check_user_role_restriction( $restriction, $enable, $has_cod_available ) {

		if ( is_user_logged_in() ) {
			$user = wp_get_current_user();
		} else {
			$user        = new stdClass();
			$user->roles = array( 'guest' );
		}

		if ( $enable ) {
			return array_intersect( $restriction, $user->roles );
		} else {
			if ( array_intersect( $restriction, $user->roles ) ) {
				return false;
			}
		}

		return $has_cod_available;
	}

	protected function check_method_restriction() {

		$settings = $this->get_cod_settings();

		if ( isset( $settings['enable_for_methods'] ) ) {
			if ( ! empty( $settings['enable_for_methods'] ) ) {

				if ( Wc_Smart_Cod::wc_version_check() ) {
					// over 3.4, now woocommerce
					// supports natively shipping
					// zone method restriction
					$method = $this->get_customer_shipping_method( true, true );

					if ( ! $method ) {
						return true;
					}
					if ( ! in_array( $method, $settings['enable_for_methods'] ) ) {
						return false;
					}
				} else {
					$method = $this->get_customer_shipping_method();
					if ( ! $method ) {
						return true;
					}
					if ( ! in_array( $method, $settings['enable_for_methods'] ) ) {
						return false;
					}
				}
			}
		}

		return true;

	}

	/**
	 * Check cod availability
	 * end
	 */

	protected static function get_user_refreshed_data( $key ) {
		if ( ! method_exists( WC()->customer, "get_$key" ) ) {
			return '';
		}
		$target_key = str_replace( 'shipping_', 's_', $key );
		if ( isset( $_POST[ $target_key ] ) ) {
			return $_POST[ $target_key ];
		}
		if ( isset( $_POST['post_data'] ) ) {
			parse_str( $_POST['post_data'], $data );
			if ( isset( $data[ $target_key ] ) ) {
				return $data[ $key ];
			}
		}
		return WC()->customer->{ 'get_' . $key }();
	}

	public function apply_smart_cod_settings( $available_gateways ) {
		$cod_settings = $this->get_cod_settings();
		if ( ! isset( $cod_settings['restrictions_enabled'] ) || $cod_settings['restrictions_enabled'] !== 'yes' ) {
			return $available_gateways;
		}

		if ( ! function_exists( 'is_checkout' ) || ! is_checkout() && ! is_wc_endpoint_url( 'order-pay' ) ) {
			return $available_gateways;
		}

		$this->init_wsc_settings();

		if ( $this->has_cod_available() === false ) {
			unset( $available_gateways['cod'] );
		}

		return $available_gateways;

	}

	/**
	 * Check extra fee
	 * start
	 */

	private function check_country( $settings, $cart ) {

		// check if we have a specific
		// country amount set. ( include mode )

		$extra_fee = false;
		$key       = $settings['key'];
		global $woocommerce;
		$customer_country = $woocommerce->customer->get_shipping_country();

		if ( $key === 'include_country_different_charge_' . $customer_country ) {
			$extra_fee = $settings['fee'];
		}

		return $extra_fee;

	}

	private function check_overthelimit( $settings, $cart ) {

		// check if customer is over the limit ( if any )
		// and charge him nothing

		$extra_fee = false;
		$key       = $settings['key'];

		if ( ! $this->nocharge_amount_mode ) {
			$this->nocharge_amount_mode = 'excludes';
		}

		if ( $key === 'nocharge_amount' ) {

			$total = $this->wsc_get_total( 'cart_amount_calculation' );
			if ( $this->nocharge_amount_mode === 'excludes' ) {
				if ( $total >= $settings['fee'] ) {
					$extra_fee = 0;
				}
			} elseif ( $this->nocharge_amount_mode === 'includes' ) {
				if ( $total < $settings['fee'] ) {
					$extra_fee = 0;
				}
			}
		}

		return $extra_fee;

	}

	private function check_zoneandmethod( $settings, $cart ) {

		// check for specific shipping zones
		// & methods different charges

		$extra_fee       = false;
		$key             = $settings['key'];
		$zone_id         = $this->get_customer_shipping_zone( $cart );
		$shipping_method = $this->get_customer_shipping_method( true );

		if ( $shipping_method === false || $zone_id === false ) {
			return $extra_fee;
		}

		if ( $key === 'zonemethod_different_charge_' . $zone_id . '_method_' . $shipping_method ) {
			$extra_fee = $settings['fee'];
		}

		return $extra_fee;
	}

	private function check_zone( $settings, $cart ) {

		// check for specific shipping zones
		// different charges

		$extra_fee = false;
		$key       = $settings['key'];
		$zone_id   = $this->get_customer_shipping_zone( $cart );

		if ( $zone_id === false ) {
			return $extra_fee;
		}

		if ( $key === 'different_charge_' . $zone_id ) {
			$extra_fee = $settings['fee'];
		}

		return $extra_fee;

	}

	private function check_method( $settings, $cart ) {

		// check for specific shipping methods
		// different charges

		$extra_fee       = false;
		$key             = $settings['key'];
		$shipping_method = $this->get_customer_shipping_method();

		if ( ! $shipping_method ) {
			return $extra_fee;
		}

		if ( $key === 'method_different_charge_' . $shipping_method ) {
			$extra_fee = $settings['fee'];
		}

		return $extra_fee;

	}

	private function check_normal_fee( $settings, $cart ) {

		$extra_fee = 0;
		$key       = $settings['key'];

		if ( $key === 'extra_fee' ) {
			$extra_fee = $settings['fee'];
		}

		return $extra_fee;

	}

	protected function order_pay_get_order() {
		global $wp;
		$order_id = $wp->query_vars['order-pay'];
		if ( ! $order_id || ! is_numeric( $order_id ) ) {
			return false;
		}
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return false;
		}
		return $order;
	}

	protected static function should_attach_scripts() {
		return function_exists( 'is_checkout' ) && is_checkout() || function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url( 'order-pay' );
	}

	/**
	 * Check extra fee
	 * end
	 */

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wc_Smart_Cod_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wc_Smart_Cod_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		if ( self::should_attach_scripts() ) {
			wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wc-smart-cod-public.min.js', array( 'jquery' ), $this->version, false );

			$data = array(
				'ajaxurl'            => admin_url( 'admin-ajax.php' ),
				'is_order_pay'       => is_wc_endpoint_url( 'order-pay' ),
				'extra_fees_enabled' => $this->are_extrafees_enabled(),
			);

			if ( is_wc_endpoint_url( 'order-pay' ) ) {
				$order                  = $this->order_pay_get_order();
				$data['payment_method'] = $order->get_payment_method();
				$data['order_id']       = $order->get_id();
			}

			wp_localize_script(
				$this->plugin_name,
				'smart_cod_variables',
				$data
			);
			wp_enqueue_script( $this->plugin_name );
		}

	}

}
