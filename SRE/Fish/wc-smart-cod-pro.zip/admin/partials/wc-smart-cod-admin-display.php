<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://woosmartcod.com
 * @since      1.0.0
 *
 * @package    Wc_Smart_Cod
 * @subpackage Wc_Smart_Cod/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<?php echo $template_data->heading; ?>
<?php if( ! empty($template_data->tabs )) : ?>
	<nav class="nav-tab-wrapper woo-nav-tab-wrapper wsc-addons-tab-wrapper">
		<?php foreach( $template_data->tabs as $tab ) {
			echo '<a href="' . admin_url( $tab->slug ? $this->base_url . '&addon=' . urlencode( $tab->slug ) : $this->base_url ) . '"class="nav-tab';
			if ( $tab->active ) {
				echo ' nav-tab-active';
			}
			echo '">' . esc_html( $tab->name ) . '</a>';
		} ?>
	</nav>
<?php endif; ?>
<div class="wc-smart-cod-tab<?php echo $template_data->active_tab->slug ? ' wc-smart-cod-tab-' . $template_data->active_tab->slug : '' ?><?php echo $template_data->active_tab->slug && ! $template_data->a ? ' unauthorized-tab' : '' ?>">
	<?php if ( $template_data->active_tab->slug && ! $template_data->a ) : ?>
		<?php echo $template_data->al; ?>
	<?php endif; ?>
	<?php echo $template_data->active_tab->settings; ?>
</div>
<?php 
do_action( 'after_wsc_settings' );
if( $template_data->active_tab->slug ) :
	do_action( 'after_wsc_settings_' . $template_data->active_tab->slug );
endif;
?>
