<?php

class Wc_Smart_Cod_Importer {

	protected static $allowed_mimes = array( 'application/csv', 'text/csv', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );

	protected static $allowed_delimiters = array(
		';',
		',',
		"\t",
		'|',
	);

	public static function upgrade_db() {
		self::install_db();
		// update db when neccessary
	}

	protected static function install_db() {

		global $wpdb;
		$table_c         = Wc_Smart_Cod::$tables['collections'];
		$table_r         = Wc_Smart_Cod::$tables['records'];
		$charset_collate = $wpdb->get_charset_collate();

		$sql_r = "CREATE TABLE $table_r (
			id int(11) NOT NULL AUTO_INCREMENT,
			collection_id smallint(6) NOT NULL,
			value varchar(200) NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY collection_id_value (collection_id, value)
		) $charset_collate;";

		$sql_c = "CREATE TABLE $table_c (
			id smallint(6) NOT NULL AUTO_INCREMENT,
			type_id tinyint(4) NOT NULL,
			field_key varchar(50) NOT NULL,
			rule_id smallint(6),
			PRIMARY KEY (id)
		) $charset_collate;";
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $sql_r . $sql_c );

		// $foreign_keys = "ALTER TABLE `wp_wsc_collections`
		// ADD CONSTRAINT `id_collection_id` FOREIGN KEY (`id`) REFERENCES `$table_r` (`collection_id`) ON DELETE CASCADE ON UPDATE NO ACTION;";
		// $wpdb->query( $foreign_keys );

	}

	protected static function get_dbkey_by_type_id( $type_id ) {
		switch ( $type_id ) {
			case 1: {
				return 'woocommerce_cod_settings';
			}
			case 2: {
				return 'woocommerce_smartcod_extrafees_settings';
			}
			case 3: {
				return 'woocommerce_smartcod_riskfree_settings';
			}
		}
		return null;
	}

	public static function wsc_delete_collection( $collection_id ) {

		try {
			global $wpdb;

			$collection = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Wc_Smart_Cod::$tables['collections'] . ' WHERE id = %d', $collection_id ) );
			if ( ! $collection ) {
				throw new Exception( 'Collection not found.' );
			}

			$type_id = (int) $collection->type_id;
			$db_key  = self::get_dbkey_by_type_id( $type_id );
			if ( is_null( $db_key ) ) {
				throw new Exception( 'Collection type not found.' );
			}

			$deleted_records = $wpdb->delete( Wc_Smart_Cod::$tables['records'], array( 'collection_id' => $collection_id ) );
			$wpdb->delete( Wc_Smart_Cod::$tables['collections'], array( 'id' => $collection_id ) );

			self::update_uploaded_restrictions( $collection_id, null, $collection->field_key, $type_id, (int) $collection->rule_id );

			$message = $deleted_records === 1 ? 'entry was' : 'entries were';

			ob_start();
			WC_Admin_Settings::add_message( sprintf( '%s %s successfully deleted!', $deleted_records, $message ) );
			WC_Admin_Settings::show_messages();

			return array(
				'data'    => ob_get_clean(),
				'success' => true,
			);

		} catch ( Exception $e ) {
			$message = $e->getMessage();
			ob_start();
			WC_Admin_Settings::add_error( "Failed to delete collection ($collection_id): $message" );
			WC_Admin_Settings::show_messages();
			return array(
				'data'    => ob_get_clean(),
				'success' => false,
			);
		}
	}

	public static function wsc_process_file( $file_id, $key, $has_header, $header_column, $preview = false, $type_id, $rule_id ) {

		try {

			$action = $preview ? 'fetched' : 'imported';

			if ( $has_header && ! $header_column ) {
				throw new Exception( 'Header column which contains data is not provided.' );
			}

			$header_column = $has_header ? $header_column : false;
			$ret           = self::try_parse_file( $key, $file_id, $header_column, $preview );

			/**
			 * Handle warnings
			 */

			if ( ! empty( $ret['warnings'] ) ) {
				$message = implode( ', ', $ret['warnings'] );
				WC_Admin_Settings::add_error( "Uploaded file warning ($file_id): Rows $message of your CSV had errors and were not $action." );
			}

			/**
			 * Empty data exception
			 */

			if ( empty( $ret['data'] ) ) {
				throw new Exception( "Empty rows or no rows could be $action." );
			}

			if ( $preview ) {
				return array(
					'data'    => self::generate_preview( $ret ),
					'success' => true,
				);
			}

			return self::import_csv_data( $key, $ret, $type_id, $rule_id );

		} catch ( Exception $e ) {
			$message = $e->getMessage();
			ob_start();
			WC_Admin_Settings::add_error( "Uploaded file error ($file_id): $message" );
			WC_Admin_Settings::show_messages();
			return array(
				'data'    => ob_get_clean(),
				'success' => false,
			);
		}

	}

	protected static function update_db_option( $options, $key, $collection_id, $entries_count, $db_key, $parent_options = array(), $rule_index = false ) {

		if ( ! isset( $options[ $key ] ) || ! is_array( $options[ $key ] ) ) {

			$textarea_data = ! empty( $options[ $key ] ) ? $options[ $key ] : '';

			$options[ $key ] = array(
				'textarea' => $textarea_data,
				'file'     => array(
					'collection_id' => $collection_id,
					'entries'       => $entries_count,
				),
			);

		} else {
			$options[ $key ]['file'] = array(
				'collection_id' => $collection_id,
				'entries'       => $entries_count,
			);
		}

		if ( is_null( $entries_count ) ) {
			unset( $options[ $key ]['file'] );
		}

		if ( ! empty( $parent_options ) ) {
			$parent_options['rules'][ $rule_index ]['restrictions'] = $options;
			update_option( $db_key, $parent_options );
			return;
		}

		update_option( $db_key, $options );
	}

	protected static function update_uploaded_restrictions( $collection_id, $entries_count, $key, $type_id, $rule_id ) {

		switch ( $type_id ) {
			case 1: {
				$options = get_option( 'woocommerce_cod_settings' );
				if ( ! $options || empty( $options ) || ! is_array( $options ) ) {
					throw new Exception( 'No COD settings available.' );
				}

				self::update_db_option( $options, $key, $collection_id, $entries_count, 'woocommerce_cod_settings' );
				break;
			}
			case 2:
			case 3: {
				$db_key  = $type_id === 2 ? 'woocommerce_smartcod_extrafees_settings' : 'woocommerce_smartcod_riskfree_settings';
				$options = get_option( $db_key );

				if ( ! $options || empty( $options ) || ! is_array( $options ) ) {
					throw new Exception( 'No COD settings available.' );
				}
				if ( ! isset( $options['rules'] ) || empty( $options['rules'] ) ) {
					throw new Exception( 'No extra fee rules found.' );
				}

				$rules      = $options['rules'];
				$rule_index = false;
				foreach ( $rules as $index => $rule ) {
					if ( $rule['id'] === $rule_id ) {
						$rule_index = $index;
					}
				}

				if ( $rule_index === false ) {
					throw new Exception( 'Rule not found.' );
				}

				$rule = $rules[ $rule_index ]['restrictions'];
				self::update_db_option( $rule, $key, $collection_id, $entries_count, $db_key, $options, $rule_index );

			}
		}
	}

	protected static function insert_collection( $key, $type_id, $rule_id ) {
		global $wpdb;
		$fields = 'type_id, field_key, rule_id';

		if ( $type_id === '1' && ! $rule_id ) {
			$rule_id = 0;
		}

		$values = $wpdb->prepare( '(%d, %s, %d)', $type_id, $key, $rule_id );

		$query  = sprintf( 'INSERT IGNORE INTO %s(%s) VALUES %s', Wc_Smart_Cod::$tables['collections'], $fields, $values );
		$result = $wpdb->query( $query );
		if ( ! $result ) {
			$warnings = $wpdb->get_results( 'SHOW WARNINGS;' );
			if ( empty( $warnings ) ) {
				throw new Exception( 'Error while inserting collection in the db.' );
			}
			$query       = $wpdb->prepare( 'SELECT id FROM ' . Wc_Smart_Cod::$tables['collections'] . ' WHERE type_id=%d AND field_key=%s AND rule_id=%d', $type_id, $key, $rule_id );
			$existing_id = $wpdb->get_var( $query );
			if ( ! $existing_id ) {
				throw new Exception( 'Error while inserting collection in the db.' );
			}
			return $existing_id;
		}
		return $wpdb->insert_id;
	}

	protected static function import_csv_data( $key, $ret, $type_id, $rule_id ) {
		global $wpdb;
		$wpdb->show_errors = false;

		/**
		 * Insert Collection
		 */

		$collection_id = self::insert_collection( $key, $type_id, $rule_id );

		/**
		 * Insert Collection Entries
		 */

		$queries = self::prepare_collection_entries( $key, $ret['data'], $collection_id );
		$entries = 0;
		foreach ( $queries as $query ) {
			$entries += self::insert_collection_entries_fragment( $query );
		}

		$ret_data_count = count( $ret['data'] );

		$warnings = $ret_data_count - $entries;

		$message      = $entries === 1 ? 'entry was' : 'entries were';
		$message_warn = $warnings === 1 ? 'entry was' : 'entries were';

		$total_count = $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . Wc_Smart_Cod::$tables['records'] . ' WHERE collection_id = %d', $collection_id ) );

		// if ( $entries > 0 ) {
			self::update_uploaded_restrictions( $collection_id, $total_count, $key, (int) $type_id, (int) $rule_id );
		// }

		ob_start();
		if ( $warnings > 0 ) {
			WC_Admin_Settings::add_message( sprintf( '%s %s successfully imported!', $entries, $message ) );
			WC_Admin_Settings::add_message( sprintf( '%s %s already existing!', $warnings, $message_warn ) );
		} else {
			WC_Admin_Settings::add_message( "$entries $message succesfully imported!" );
		}

		WC_Admin_Settings::show_messages();

		$response = array(
			'data'           => ob_get_clean(),
			'success'        => true,
			'values_section' => self::get_values_section( (int) $type_id, $key, $collection_id, $total_count ),
		);

		if ( $total_count > 0 ) {
			$response['delete_section'] = self::get_delete_section( $collection_id, $total_count );
		}

		return $response;
	}

	protected static function get_values_section( $type_id, $key, $collection_id, $entries ) {
		$db_key = self::get_dbkey_by_type_id( $type_id );
		// remove _settings part
		$field_key = substr( $db_key, 0, -8 ) . $key;
		ob_start(); ?>
		<div class="wsc-values-section">
			<input type="hidden" name="<?php echo esc_attr( $field_key ); ?>[file][collection_id]" value="<?php echo $collection_id; ?>" />
			<input type="hidden" name="<?php echo esc_attr( $field_key ); ?>[file][entries]" value="<?php echo $entries; ?>" />
		</div>
		<?php
		return ob_get_clean();
	}

	protected static function get_delete_section( $collection_id, $entries ) {
		ob_start();
		?>
		<div class="wsc-delete-section">
			<button type="button" class="delete-entries button-secondary" data-collection-id="<?php echo $collection_id; ?>">Delete existing records (<?php echo $entries; ?>)</button>
			<span class="spinner"></span>
			<div class="wsc-delete-output"></div>
		</div>
		<?php
		return ob_get_clean();
	}

	protected static function insert_collection_entries_fragment( $query ) {
		global $wpdb;
		$count_entries = $wpdb->query( $query );
		if ( $wpdb->last_error ) {
			throw new Exception( $wpdb->last_error );
		}

		return $count_entries;
	}

	protected static function prepare_collection_entries( $key, $query_data, $collection_id ) {
		global $wpdb;
		$queries = array();
		$chunks  = array_chunk( $query_data, 8000 );

		foreach ( $chunks as $chunk ) {
			$query = sprintf( 'INSERT IGNORE INTO `%s`(collection_id, value) VALUES ', Wc_Smart_Cod::$tables['records'] );
			foreach ( $chunk as $d ) {
				$_d     = sanitize_text_field( $d );
				$query .= $wpdb->prepare( '(%d, %s),', $collection_id, $_d );
			}

			$query     = rtrim( $query, ',' );
			$queries[] = $query;
		}

		return $queries;
	}

	protected static function generate_preview( $ret ) {
		ob_start();
		?>
		<h5>CSV Preview (3 first rows)</h5>
		<table class="wp-list-table fixed widefat striped wsc-preview">
		<?php
		foreach ( $ret['data'] as $index => $row ) :
			?>
			<tr>
				<th><?php echo $index + 1; ?>.</th>
				<td><?php echo $row; ?></td>
		</tr>
			<?php
		endforeach;
		?>
		</table>
		<div id="message" class="updated inline">
			<p>If you are happy with the result, <strong>please click "Import CSV"!</strong></p>
		</div>
		<?php
		return ob_get_clean();
	}

	protected static function try_parse_file( $settings_key, $file_id, $header_column, $preview ) {
		$file_path = get_attached_file( $file_id );
		if ( $file_path === false ) {
			throw new Exception( 'File does not exists.' );
		}

		$file_mime = get_post_mime_type( $file_id );

		if ( ! in_array( $file_mime, self::$allowed_mimes ) ) {
			$mimes = implode( ', ', self::$allowed_mimes );
			throw new Exception( "File type is not supported. Please use one of those types: $mimes" );
		}

		$ret = array();

		switch ( $file_mime ) {
			case 'text/csv':
			case 'application/csv': {
				// process csv
				$ret = self::process_csv( $file_path, $header_column, $preview );
				break;
			}
			case 'application/vnd.ms-excel': {
				// process xls
			}
			case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': {
				// process xlsx
			}
		}
		return $ret;
	}

	protected static function process_csv( $file_path, $header_column, $preview ) {
		$csv = fopen( $file_path, 'r' );

		$header = fgetcsv( $csv );

		if ( $header_column !== false && ! in_array( $header_column, $header ) ) {
			$header_rows = implode( ', ', $header );
			throw new Exception( "Header column '$header_column' not found in your header row ($header_rows)" );
		}

		$header_column_index = array_search( $header_column, $header );
		$error_lines         = array();
		$output              = array();
		$index               = 0;

		while ( ( $row = fgetcsv( $csv ) ) !== false ) {
			$index++;
			if ( $preview && $index > 3 ) {
				break;
			}
			if ( $header_column === false ) {
				if ( empty( $row[0] ) ) {
					$error_lines[] = $index;
					continue;
				}
				$output[] = sanitize_text_field( $row[0] );
				continue;
			}

			if ( ! isset( $row[ $header_column_index ] ) || empty( $row[ $header_column_index ] ) ) {
				$error_lines[] = $index;
				continue;
			}
			$output[] = sanitize_text_field( $row[ $header_column_index ] );

		}

		fclose( $csv );

		return array(
			'data'     => $output,
			'warnings' => $error_lines,
		);

	}

}
