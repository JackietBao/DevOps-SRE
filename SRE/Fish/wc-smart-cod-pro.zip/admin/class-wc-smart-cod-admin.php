<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://woosmartcod.com
 * @since      1.0.0
 *
 * @package    Wc_Smart_Cod
 * @subpackage Wc_Smart_Cod/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wc_Smart_Cod
 * @subpackage Wc_Smart_Cod/admin
 * @author     woosmartcod.com <info@woosmartcod.com>
 */
class Wc_Smart_Cod_Admin extends WC_Gateway_COD {


	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private static $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */

	private $addons;

	private static $native_addons = array( 'restrictions' );

	private $base_url;

	private $a = false;

	public static $plugin_url;

	public $current_rule_id;

	private $additional_fields = array();

	public function __construct() {

		parent::__construct();

		if ( ! is_admin() ) {
			return;
		}

		$this->plugin_name = WC_Smart_Cod::$plugin_name;
		$this::$version    = WC_Smart_Cod::$version;
		$this->base_url    = WC_Smart_Cod::$base_url;
		self::$plugin_url  = WC_Smart_Cod::$pro_url . '/wp-json/wc/v3/wsca';
		$this->new_wc      = false;

		$this->addons = Wc_Smart_Cod_Admin::get_enabled_addons();

		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		add_action( 'woocommerce_settings_api_form_fields_cod', array( $this, 'extend_cod' ) );
		add_action( 'woocommerce_settings_api_sanitized_fields_cod', array( $this, 'clean_up_settings' ) );
		add_action( 'woocommerce_delete_shipping_zone', array( $this, 'clean_up_gateway' ) );

		if ( $this->is_wsc_page( true ) ) {
			$this->additional_fields = substr( current_action(), 0, 7 ) === 'wp_ajax' ? array() : $this->get_prepared_fields();
			add_filter( 'upload_mimes', array( $this, 'restrict_mime_types' ) );
			add_action( 'post-upload-ui', array( $this, 'restrict_mime_types_hint' ) );
			self::add_third_party_compatibility();
		}

	}

	public static function is_wsc_ajax() {
		return isset( $_POST['action'] )
		&& ( $_POST['action'] === 'wsc_extrafee_restrictions'
		|| $_POST['action'] === 'wsc_riskfree_restrictions' );
	}

	public static function add_third_party_compatibility() {

		/**
		 * WPML support with bad enqueued
		 * select 2 version
		 */

		add_action(
			'admin_footer',
			function() {
				if ( wp_script_is( 'wpml-select-2' ) ) {
						wp_deregister_script( 'wpml-select-2' );
				}
			},
			9999
		);
	}

	public function is_available() {
		// fix order-pay
		if ( isset( $_POST['action'] )
			 && $_POST['action'] === 'wsc_order_pay'
			) {
				return true;
		}

		return parent::is_available();
	}

	public function restrict_mime_types() {
		$mime_types = array(
			'csv'      => 'application/csv, text/csv',
			'xls|xlsx' => 'application/vnd.ms-excel, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
		);

		return $mime_types;
	}

	public function restrict_mime_types_hint() {
		echo '<br />';
		_e( 'Accepted MIME types: CSV, XLS/XLSX' );
	}

	public static function get_enabled_addons() {
		return apply_filters( 'wsc_addons', array() );
	}

	public function is_wsc_page( $exclude_base = false ) {
		if ( ! function_exists( 'get_current_screen' ) ) {
			$section = isset( $_GET['section'] ) ? $_GET['section'] : '';
			$page    = isset( $_GET['page'] ) ? $_GET['page'] : '';
			$tab     = isset( $_GET['tab'] ) ? $_GET['tab'] : '';
			$is_cod  = $section === 'cod' && $page === 'wc-settings' && $tab === 'checkout';
			return $exclude_base ? $is_cod && self::get_current_addon() !== '' : $is_cod;
		}
		$screen          = get_current_screen();
		$current_section = isset( $_GET['section'] ) ? $_GET['section'] : '';
		if ( ( isset( $screen->base ) && $screen->base === 'woocommerce_page_wc-settings' || $screen === NULL ) && $current_section === 'cod' ) {
			$addon_slug = self::get_current_addon();
			return $exclude_base ? $addon_slug !== '' : true;
		}
		return false;
	}

	public static function ajax_search_categories() {

		check_ajax_referer( 'search-categories', 'security' );

		$term = wc_clean( empty( $term ) ? stripslashes( $_GET['term'] ) : $term );

		if ( empty( $term ) ) {
			wp_die();
		}

		$categories = get_terms(
			'product_cat',
			array(
				'hide_empty' => false,
				'search'     => $term,
			)
		);

		$response = array();
		if ( is_array( $categories ) && ! empty( $categories ) ) {
			foreach ( $categories as $category ) {
				$response[ $category->term_id ] = $category->name;
			}
		}

		wp_send_json( $response );

		die();

	}

	protected function has_native_zone_method() {
		return Wc_Smart_Cod::wc_version_check()
		&& isset( $this->settings['enable_for_methods'] )
		&& ! empty( $this->settings['enable_for_methods'] );
	}

	private function ga_su() {
		return get_site_url();
	}

	protected function get_selected_products( $settings ) {

		global $wpdb;

		$products     = $settings['product_restriction'];
		$placeholders = array_fill( 0, count( $products ), '%s' );
		$format       = implode( ', ', $placeholders );
		$query        = "SELECT ID, post_title FROM {$wpdb->prefix}posts WHERE {$wpdb->prefix}posts.ID IN ( $format )";

		$_products = $wpdb->get_results(
			$wpdb->prepare( $query, $products )
		);

		$response = array();
		foreach ( $_products as $product ) {
			if ( ( $key = array_search( $product->ID, $products ) ) !== false ) {
				unset( $products[ $key ] );
			}
			$response[ $product->ID ] = $product->post_title . ' (#' . $product->ID . ')';
		}
		/**
		 * check for deleted products
		 */

		if ( ! empty( $products ) ) {
			foreach ( $products as $product ) {
				if ( ( $key = array_search( $product, $settings['product_restriction'] ) ) !== false ) {
					unset( $settings['product_restriction'][ $key ] );
				}
			}

			$settings['product_restriction'] = array_values( $settings['product_restriction'] );
			update_option( 'woocommerce_cod_settings', $settings );
			$this->settings = $settings;

		}

		return $response;

	}

	protected function get_selected_categories( $settings ) {

		global $wpdb;

		$categories = $settings['category_restriction'];

		$_categories = get_terms(
			'product_cat',
			array(
				'hide_empty' => false,
				'include'    => $settings['category_restriction'],
			)
		);

		$response = array();
		foreach ( $_categories as $category ) {
			if ( ( $key = array_search( $category->term_id, $categories ) ) !== false ) {
				unset( $categories[ $key ] );
			}
			$response[ $category->term_id ] = $category->name;
		}

		/**
		 * check for deleted categories
		 */

		if ( ! empty( $categories ) ) {
			foreach ( $categories as $category ) {
				if ( ( $key = array_search( $category, $settings['category_restriction'] ) ) !== false ) {
					unset( $settings['category_restriction'][ $key ] );
				}
			}

			$settings['category_restriction'] = array_values( $settings['category_restriction'] );
			update_option( 'woocommerce_cod_settings', $settings );
			$this->settings = $settings;

		}

		return $response;

	}

	protected function get_selected_users( $users ) {

		$response = array();
		if ( ! is_array( $users ) || empty( $users ) ) {
			return $response;
		}

		$_users = get_users( array( 'include' => $users ) );
		foreach ( $_users as $user ) {
			$user_data             = get_userdata( $user->ID );
			$response[ $user->ID ] = $user_data->first_name . ' ' . $user_data->last_name . ' ' . '(#' . $user->ID . ' - ' . $user->user_email . ')';
		}

		return $response;

	}

	protected function get_shipping_methods() {

		$options = array();
		foreach ( WC()->shipping()->load_shipping_methods() as $method ) {
			$options[ $method->id ] = sprintf( __( 'Any &quot;%1$s&quot; method', 'woocommerce' ), $method->get_method_title() );
		}

		return $options;
	}

	protected function get_product_categories() {

		$product_categories = get_terms(
			'product_cat',
			array(
				'hide_empty' => false,
			)
		);

		if ( ! $product_categories || ! is_array( $product_categories ) || empty( $product_categories ) ) {
			return false;
		}

		$response = array();

		foreach ( $product_categories as $cat ) {
			$response[ $cat->term_id ] = $cat->name;
		}

		return $response;

	}

	public function migrate_shipping_zone_methods( $unset_array ) {

		foreach ( $unset_array as $key ) {
			unset( $this->settings[ $key ] );
		}

	}

	private function update_wc_smart_cod( $settings, $restriction_settings ) {

		$mode            = $settings['restriction_mode'];
		$old_conditional = array( 'shipping_zone_restrictions', 'country_restrictions', 'restrict_postals' );

		foreach ( $old_conditional as $key ) {

			if ( $mode === 'include' ) {
				if ( array_key_exists( $key, $settings ) ) {
					unset( $settings[ $key ] );
				}
				if ( array_key_exists( 'include_' . $key, $settings ) ) {
					$settings[ $key ] = $settings[ 'include_' . $key ];
					unset( $settings[ 'include_' . $key ] );
				}
				$restriction_settings[ $key ] = 1;
			} else {
				if ( array_key_exists( 'include_' . $key, $settings ) ) {
					unset( $settings[ 'include_' . $key ] );
				}
				$restriction_settings[ $key ] = 0;
			}
		}

		unset( $settings['restriction_mode'] );
		update_option( 'woocommerce_cod_settings', $settings );
		$this->settings = $settings;

		return array(
			'restriction_settings' => $restriction_settings,
			'settings'             => $settings,
		);

	}

	public function process_admin_options() {

		$addon_slug     = self::get_current_addon();
		$enabled_addons = self::get_enabled_addons();

		if ( ! $addon_slug ) {
			return parent::process_admin_options();
		}

		if ( in_array( $addon_slug, self::$native_addons ) ) {
			$this->form_fields = $this->additional_fields;
			return parent::process_admin_options();
		}

		$addon_settings = $this->get_addon_settings( $addon_slug, $enabled_addons );

		if ( empty( $enabled_addons ) || ! $addon_settings ) {
			return;
		}

		if ( ! property_exists( $addon_settings, 'save_callback' ) || ! is_callable( $addon_settings->save_callback ) ) {
			return;
		}

		try {
			call_user_func( $addon_settings->save_callback );
		} catch ( Exception $e ) {

		}

	}

	public function get_addon_settings( $addon_slug, $addons ) {
		if ( ! $addons ) {
			$addons = $this->addons;
		}

		return current(
			array_filter(
				$addons,
				function( $_addon ) use ( $addon_slug ) {
					return $_addon->slug === $addon_slug;
				}
			)
		);

	}

	protected function analyze_fields( $form_fields, $settings, $restriction_settings, $old_wc_smart_cod, $set_class = true ) {

		$fields     = array();
		$update_fee = $update_restriction = $needs_update = false;

		if ( is_null( $restriction_settings ) ) {
			$restriction_settings = array();
		}

		foreach ( $form_fields as $key => $field ) {

			if ( ! array_key_exists( 'class', $field ) ) {
				$fields[ $key ] = $field;
				continue;
			}

			$class_arr = explode( ' ', $field['class'] );

			if ( in_array( 'wc-smart-cod-restriction', $class_arr ) ) {
				// determine include or exclude
				$mode = isset( $field['default_mode'] ) && in_array( $field['default_mode'], array( 'enable', 'disable' ) ) ? $field['default_mode'] : 'disable';

				if ( array_key_exists( $key, $restriction_settings ) ) {
					if ( $restriction_settings[ $key ] === 1 ) {
						$form_fields[ $key ]['title'] = str_replace( 'Disable', 'Enable', $form_fields[ $key ]['title'] );
						$mode                         = 'enable';
					} else {
						$form_fields[ $key ]['title'] = str_replace( 'Enable', 'Disable', $form_fields[ $key ]['title'] );
						$mode                         = 'disable';
					}
				} else {
					// first run after update
					// to wc-smart-cod 1.4
					$restriction_settings[ $key ] = $mode === 'enable' ? 1 : 0;
				}

				if ( ! array_key_exists( 'custom_attributes', $form_fields[ $key ] ) ) {
					$form_fields[ $key ]['custom_attributes'] = array();
				}

				$form_fields[ $key ]['custom_attributes']['data-mode'] = $mode;

			}
		}

		if ( $set_class ) {
			$this->restriction_settings = $restriction_settings;
		}

		return $form_fields;

	}

	protected function __a() {
		$current_addon = self::get_current_addon();
		if ( $current_addon === '' ) {
			return true;
		}
		if ( empty( $this->settings ) ) {
			$this->settings = get_option( 'woocommerce_cod_settings' );
		}
		$a = Wc_Smart_Cod_A::get_instance( $this->ga_u(), $this->ga_k(), $this->ga_su(), self::$plugin_url );
		return $a->__a();
	}

	public static function get_current_addon() {
		return empty( $_REQUEST['addon'] ) ? '' : sanitize_title( wp_unslash( $_REQUEST['addon'] ) );
	}

	public function admin_options() {
		$current_tab = self::get_current_addon();
		$tab_data    = empty( $this->addons ) ? null : $this->prepare_addons_tabs( $current_tab );

		if ( $tab_data && is_callable( $tab_data->active_tab->settings ) ) {
			$tab_data->active_tab->settings = call_user_func( $tab_data->active_tab->settings );
		}

		$template_data = (object) array(
			'heading'    => $this->prepare_section_heading(),
			'tabs'       => $tab_data ? $tab_data->tabs : array(),
			'active_tab' => $tab_data ? $tab_data->active_tab : (object) array( 'settings' => self::wrap_settings( $this->generate_settings_html( $this->get_form_fields(), false ) ) ),
		);
		require_once plugin_dir_path( __FILE__ ) . '/partials/wc-smart-cod-admin-display.php';
	}

	private function prepare_section_heading() {
		ob_start();
		echo '<h2>' . esc_html( $this->get_method_title() );
		wc_back_link( __( 'Return to payments', 'woocommerce' ), admin_url( 'admin.php?page=wc-settings&tab=checkout' ) );
		echo '</h2>';
		echo wp_kses_post( wpautop( $this->get_method_description() ) );
		echo '<div class="' . Wc_Smart_Cod::$plugin_name . '-info"><h4>' . WC_Smart_Cod::$plugin_public_name . '</h4>';
		echo '<p>Version: <strong>' . WC_Smart_Cod::$version . '</strong></p></div>';
		return ob_get_clean();
	}

	public static function wrap_settings( $settings ) {
		return '<table class="form-table">' . $settings . '</table>';
	}

	private function prepare_addons_tabs( $current_tab ) {
		$active_tab = '';

		$tabs = array_merge(
			array(
				(object) array(
					'slug'     => '',
					'name'     => __( 'General settings', $this->plugin_name ),
					'settings' => self::wrap_settings( $this->generate_settings_html( $this->get_form_fields(), false ) ),
				),
				(object) array(
					'slug'     => 'restrictions',
					'name'     => __( 'Restrictions', $this->plugin_name ),
					'settings' => self::wrap_settings( $this->generate_settings_html( $this->prepared_fields, false ) ),
				),
			),
			$this->addons
		);

		foreach ( $tabs as $tab ) {
			if ( $current_tab === $tab->slug ) {
				$active_tab = $tab;
			}
			$tab->active = $current_tab === $tab->slug;
		}

		return (object) array(
			'tabs'       => $tabs,
			'active_tab' => $active_tab,
		);
	}

	public function extend_cod( $form_fields ) {

		$api_username = array();

		$api_key = array();

		$addon_slug = self::get_current_addon();

		$this->prepared_fields = apply_filters( 'wc_smart_cod_admin_settings', $this->additional_fields );
		$final_fields          = array();

		switch ( $addon_slug ) {
			case 'restrictions' :{
				$final_fields = $this->additional_fields;
				break;
			}
			case '': {
				$final_fields = array_merge(
					$api_username,
					$api_key,
					$form_fields
				);
				break;
			}
			default: {
				$final_fields = $form_fields;
				break;
			}
		}

		return $final_fields;

	}

	protected function prepare_states( $countries, $states ) {
		$prepared = array();
		$states   = array_filter( array_map( 'array_filter', $states ) );

		foreach ( $states as $country_key => $country ) {

			foreach ( $country as $key => $state ) {
				if ( ! array_key_exists( $country_key, $countries ) ) {
					continue;
				}

				$prepared[ $country_key . '_' . $key ] = $countries[ $country_key ] . ' &mdash; ' . $state;
			}
		}
		return $prepared;
	}

	protected function prepare_user_roles() {

		global $wp_roles;
		$prepared = array();
		if ( ! isset( $wp_roles ) ) {
			$wp_roles = new WP_Roles();
		}

		foreach ( $wp_roles->roles as $key => $role ) {
			$prepared[ $key ] = $role['name'];
		}

		$prepared['guest'] = 'Guest (Customer without account)';

		return $prepared;
	}

	protected function prepare_shipping_classes() {
		global $woocommerce;
		$prepared         = array();
		$shipping_classes = $woocommerce->shipping->get_shipping_classes();

		foreach ( $shipping_classes as $key => $class ) {
			$prepared[ $class->term_id ] = $class->name;
		}

		return $prepared;
	}

	public function get_prepared_fields( $settings = null ) {

		$this->new_wc               = class_exists( 'WC_Shipping_Zones' );
		$existing_settings          = ! is_null( $settings ) ? $settings : $this->settings;
		$existing_zone_restrictions = array();
		$countries                  = new WC_Countries;
		$states                     = $countries->get_allowed_country_states();
		$countries                  = $countries->get_allowed_countries();
		$states                     = $this->prepare_states( $countries, $states );
		$user_roles                 = $this->prepare_user_roles();
		$shipping_classes           = $this->prepare_shipping_classes();

		$multivendor = Wc_Smart_Cod_MultiVendors_Helper::get_instance();

		$restriction_settings = array_key_exists( 'restriction_settings', $existing_settings ) ? $existing_settings['restriction_settings'] : false;
		$restriction_settings = $restriction_settings !== false ? json_decode( $restriction_settings, true ) : array();

		$_coupons = get_posts(
			array(
				'posts_per_page' => -1,
				'orderby'        => 'title',
				'order'          => 'asc',
				'post_type'      => 'shop_coupon',
				'post_status'    => 'any',
			)
		);
		$a        = $this->__a();
		$coupons  = array();
		foreach ( $_coupons as $coupon ) {
			$_coupon                         = new WC_Coupon( $coupon->ID );
			$coupons[ $_coupon->get_code() ] = $coupon->post_title;
		}

		$old_wc_smart_cod = array_key_exists( 'restriction_mode', $existing_settings );

		if ( $old_wc_smart_cod ) {
			$updated_data         = $this->update_wc_smart_cod( $existing_settings, $restriction_settings );
			$restriction_settings = $updated_data['restriction_settings'];
			$existing_settings    = $updated_data['settings'];
		}

		$shipping_methods =
		$zone_methods     = array();

		foreach ( WC()->shipping()->load_shipping_methods() as $method ) {
			$shipping_methods[ $method->id ] = $method->get_method_title();
		}

		$shipping_zones    =
		$wc_shipping_zones = array();

		$products     =
		$users        =
		$product_cats = array();

		if ( array_key_exists( 'product_restriction', $existing_settings )
			&& is_array( $existing_settings['product_restriction'] )
			&& ! empty( $existing_settings['product_restriction'] ) ) {

			$products = $this->get_selected_products( $existing_settings );
		}

		if ( array_key_exists( 'category_restriction', $existing_settings )
			&& is_array( $existing_settings['category_restriction'] )
			&& ! empty( $existing_settings['category_restriction'] ) ) {

			$product_cats = $this->get_selected_categories( $existing_settings );
		}

		if ( array_key_exists( 'user_restriction', $existing_settings )
			&& is_array( $existing_settings['user_restriction'] )
			&& ! empty( $existing_settings['user_restriction'] ) ) {
			$users = $this->get_selected_users( $existing_settings['user_restriction'] );
		}

		if ( $this->new_wc ) {

			$wc_shipping_zones = WC_Shipping_Zones::get_zones();

			foreach ( $wc_shipping_zones as $zone ) {
				$zone_key                             = array_key_exists( 'id', $zone ) ? 'id' : 'zone_id';
				$shipping_zones[ $zone[ $zone_key ] ] = $zone['zone_name'];

				$_zone   = new WC_Shipping_Zone( $zone[ $zone_key ] );
				$methods = $_zone->get_shipping_methods( true );
				foreach ( $methods as $key => $method ) {
					$zone_methods[ $zone[ $zone_key ] . '_' . $key ] = $zone['zone_name'] . ' &mdash; ' . $method->title;
				}
			}
		}

		$form_fields['restrictions_enabled'] = array(
			'title'    => __( 'Enable/Disable', 'wc-smart-cod' ),
			'label'    => __( 'Enable restrictions', 'wc-smart-cod' ),
			'type'     => 'checkbox',
			'class'    => 'wc-smart-cod-group',
			'desc_tip' => false,
			'disabled' => false,
		);

		if ( ! empty( $shipping_zones ) ) {
			$shipping_zones[0] = __( 'Rest of the World', 'woocommerce' );
		}

		if ( $this->new_wc ) {

			$form_fields['shipping_zone_restrictions'] = array(
				'title'             => __( 'Disable on specific shipping zones', 'wc-smart-cod' ),
				'type'              => 'multiselect',
				'class'             => 'wc-enhanced-select wc-smart-cod-group wc-smart-cod-restriction',
				'description'       => __( 'Select the shipping zones you want to restrict the COD method', 'wc-smart-cod' ),
				'options'           => $shipping_zones,
				'desc_tip'          => true,
				'disabled'          => false,
				'custom_attributes' => array(
					'data-placeholder' => __( 'Select shipping zones', 'wc-smart-cod' ),
					'data-name'        => 'shipping_zone_restrictions',
				),
			);

		}

		$form_fields['country_restrictions'] = array(
			'title'             => __( 'Disable on specific countries', 'wc-smart-cod' ),
			'type'              => 'multiselect',
			'class'             => 'wc-enhanced-select wc-smart-cod-group wc-smart-cod-restriction',
			'description'       => __( 'Select the countries you want to restrict the COD method', 'wc-smart-cod' ),
			'options'           => $countries,
			'desc_tip'          => true,
			'disabled'          => false,
			'custom_attributes' => array(
				'data-placeholder' => __( 'Select Countries', 'wc-smart-cod' ),
				'data-name'        => 'country_restrictions',
			),
		);

		$form_fields['state_restrictions'] = array(
			'title'             => __( 'Disable on specific states', 'wc-smart-cod' ),
			'type'              => 'multiselect',
			'class'             => 'wc-enhanced-select wc-smart-cod-group wc-smart-cod-restriction',
			'description'       => __( 'Select the states you want to restrict the COD method', 'wc-smart-cod' ),
			'options'           => $states,
			'desc_tip'          => true,
			'disabled'          => false,
			'custom_attributes' => array(
				'data-placeholder' => __( 'Select States', 'wc-smart-cod' ),
				'data-name'        => 'state_restrictions',
			),
		);

		$form_fields['restrict_postals'] = array(
			'title'             => __( 'Disable on specific zip codes', 'wc-smart-cod' ),
			'type'              => 'file_textarea',
			'class'             => 'wc-smart-cod-group wc-smart-cod-restriction',
			'description'       => array(
				'textarea' => __( 'Add the zip codes you want to restrict the COD method. Seperate with a comma. You can use fully numeric ranges as well (e.g<code>55133,55134,55400...55600</code>). For ranges use <code>...</code> for delimiter.', 'wc-smart-cod' ),
				'upload'   => __( 'File types: <strong>.csv</strong>', 'wc-smart-cod' ),
			),
			'friendly_name'     => 'zip codes',
			'disabled'          => false,
			'custom_attributes' => array(
				'data-name' => 'restrict_postals',
			),
		);

		$form_fields['city_restrictions'] = array(
			'title'             => __( 'Disable on specific cities', 'wc-smart-cod' ),
			'type'              => 'textarea',
			'class'             => 'wc-smart-cod-group wc-smart-cod-restriction',
			'description'       => __( 'Add the cities you want to restrict the COD method. Seperate with a comma. This cannot guarantee the cod restriction at all times, because the city field on checkout is a free text field and the user can make typos or use different characters / spelling for his city.', 'wc-smart-cod' ),
			'disabled'          => false,
			'custom_attributes' => array(
				'data-name' => 'city_restrictions',
			),
		);

		$form_fields['cart_amount_restriction'] = array(
			'title'             => __( 'Disable if cart amount is greater or equal than', 'wc-smart-cod' ),
			'type'              => 'price',
			'class'             => 'wc-smart-cod-group wc-smart-cod-restriction',
			'description'       => __( 'Add a price limit to restrict the COD method, if the customer\'s cart amount is greater or lower than this limit.', 'wc-smart-cod' ),
			'placeholder'       => __( 'Enter Amount', 'wc-smart-cod' ),
			'disabled'          => false,
			'custom_attributes' => array(
				'data-name' => 'cart_amount_restriction',
			),
		);

		$form_fields['cart_range_restriction'] = array(
			'title'             => __( 'Enable for this cart range', 'wc-smart-cod' ),
			'type'              => 'range',
			'class'             => 'wc-smart-cod-group wc-smart-cod-restriction',
			'description'       => __( 'Add a price range to restrict the COD method, if the customer\'s cart amount is between this range.', 'wc-smart-cod' ),
			'default_mode'      => 'enable',
			'placeholder'       => __( 'Enter Amount', 'wc-smart-cod' ),
			'disabled'          => false,
			'custom_attributes' => array(
				'data-name' => 'cart_range_restriction',
			),
		);

		$form_fields['user_restriction'] = array(
			'title'             => __( 'Disable on specific users', 'wc-smart-cod' ),
			'type'              => 'multiselect',
			'class'             => 'wc-smartcod-users wc-smart-cod-group wc-smart-cod-restriction',
			'description'       => __( 'Select the users you want to restrict the COD method', 'wc-smart-cod' ),
			'options'           => $users,
			'desc_tip'          => true,
			'disabled'          => false,
			'custom_attributes' => array(
				'data-placeholder'          => __( 'Select users', 'wc-smart-cod' ),
				'data-minimum_input_length' => '1',
				'data-name'                 => 'user_restriction',
				'data-action'               => 'woocommerce_json_search_customers',
			),
		);

		$form_fields['user_email_restriction'] = array(
			'title'             => __( 'Disable on specific user emails', 'wc-smart-cod' ),
			'type'              => 'file_textarea',
			'class'             => 'wc-smart-cod-group wc-smart-cod-restriction',
			'description'       => array(
				'textarea' => __( 'Add the user emails you want to restrict the COD method. Seperate with a comma', 'wc-smart-cod' ),
				'upload'   => __( 'File types: <strong>.csv</strong>', 'wc-smart-cod' ),
			),
			'friendly_name'     => 'user emails',
			'disabled'          => false,
			'custom_attributes' => array(
				'data-name' => 'user_email_restriction',
			),
		);

		$form_fields['user_phone_restriction'] = array(
			'title'             => __( 'Disable on specific user phone numbers', 'wc-smart-cod' ),
			'type'              => 'file_textarea',
			'class'             => 'wc-smart-cod-group wc-smart-cod-restriction',
			'description'       => array(
				'textarea' => __( 'Add the user phone numbers you want to restrict the COD method. Seperate with a line break (enter)', 'wc-smart-cod' ),
				'upload'   => __( 'File types: <strong>.csv</strong>', 'wc-smart-cod' ),
			),
			'disabled'          => false,
			'friendly_name'     => 'phone numbers',
			'custom_attributes' => array(
				'data-name' => 'user_phone_restriction',
			),
		);

		$form_fields['user_role_restriction'] = array(
			'title'             => __( 'Disable on specific user roles', 'wc-smart-cod' ),
			'type'              => 'multiselect',
			'class'             => 'wc-enhanced-select wc-smart-cod-group wc-smart-cod-restriction',
			'description'       => __( 'Select the user roles you want to restrict the COD method', 'wc-smart-cod' ),
			'options'           => $user_roles,
			'desc_tip'          => true,
			'disabled'          => false,
			'custom_attributes' => array(
				'data-placeholder' => __( 'Select Roles', 'wc-smart-cod' ),
				'data-name'        => 'user_role_restriction',
			),
		);

		$form_fields['coupon_restriction'] = array(
			'title'             => __( 'Disable on specific coupons', 'wc-smart-cod' ),
			'type'              => 'multiselect',
			'class'             => 'wc-enhanced-select wc-smart-cod-group wc-smart-cod-restriction',
			'description'       => __( 'Select the coupons you want to restrict the COD method', 'wc-smart-cod' ),
			'options'           => $coupons,
			'desc_tip'          => true,
			'disabled'          => false,
			'custom_attributes' => array(
				'data-placeholder' => __( 'Select Coupons', 'wc-smart-cod' ),
				'data-name'        => 'coupon_restriction',
			),
		);

		$form_fields['category_restriction_mode'] = array(
			'title'        => __( 'Product Category Restriction Mode', 'wc-smart-cod' ),
			'type'         => 'radio',
			'parent_class' => 'wc-smart-cod-field inline',
			'class'        => 'wc-smart-cod-group',
			'disabled'     => false,
			'options'      => array(
				'one_product'  => __( 'At least one product', 'wc-smart-cod' ),
				'all_products' => __( 'All products', 'wc-smart-cod' ),
			),
			'default'      => 'one_product',
			'description'  => __( 'Select "at least one", if you want the COD to be restricted when at least one product of the cart belongs to a restricted category. Select "all", if you want the COD to be restricted if all the cart product\'s belongs to restricted categories. Then add the restricted categories in the select field below.', 'wc-smart-cod' ),
		);

		$form_fields['category_restriction'] = array(
			'title'             => __( 'Disable on specific product categories', 'wc-smart-cod' ),
			'type'              => 'multiselect',
			'class'             => 'wc-smartcod-categories wc-smart-cod-group wc-smart-cod-restriction',
			'description'       => __( 'Select the product categories you want to restrict the COD method', 'wc-smart-cod' ),
			'options'           => $product_cats,
			'desc_tip'          => true,
			'disabled'          => false,
			'custom_attributes' => array(
				'data-placeholder'          => __( 'Select categories', 'wc-smart-cod' ),
				'data-minimum_input_length' => '1',
				'data-name'                 => 'category_restriction',
				'data-action'               => 'wcsmartcod_json_search_categories',
			),
		);

		$form_fields['product_restriction_mode'] = array(
			'title'        => __( 'Product Restriction Mode', 'wc-smart-cod' ),
			'type'         => 'radio',
			'parent_class' => 'wc-smart-cod-field inline',
			'class'        => 'wc-smart-cod-group',
			'options'      => array(
				'one_product'  => __( 'At least one product', 'wc-smart-cod' ),
				'all_products' => __( 'All products', 'wc-smart-cod' ),
			),
			'default'      => 'one_product',
			'disabled'     => false,
			'description'  => __( 'Select "at least one", if you want the COD to be restricted when at least one product of the cart is restricted. Select "all", if you want the COD to be restricted if all of the cart\'s product\'s are restricted. Then add the restricted products in the select field below.', 'wc-smart-cod' ),
		);

		$form_fields['product_restriction'] = array(
			'title'             => __( 'Disable on specific products', 'wc-smart-cod' ),
			'type'              => 'multiselect',
			'class'             => 'wc-smartcod-products wc-smart-cod-group wc-smart-cod-restriction',
			'description'       => __( 'Select the products you want to restrict the COD method', 'wc-smart-cod' ),
			'options'           => $products,
			'desc_tip'          => true,
			'disabled'          => false,
			'custom_attributes' => array(
				'data-placeholder'          => __( 'Select products', 'wc-smart-cod' ),
				'data-action'               => 'woocommerce_json_search_products_and_variations',
				'data-minimum_input_length' => '1',
				'data-name'                 => 'product_restriction',
			),
		);

		$form_fields['sku_product_restriction_mode'] = array(
			'title'        => __( 'SKU Restriction Mode', 'wc-smart-cod' ),
			'type'         => 'radio',
			'parent_class' => 'wc-smart-cod-field inline',
			'class'        => 'wc-smart-cod-group',
			'options'      => array(
				'one_product'  => __( 'At least one SKU', 'wc-smart-cod' ),
				'all_products' => __( 'All SKU\'s', 'wc-smart-cod' ),
			),
			'default'      => 'one_product',
			'disabled'     => false,
			'description'  => __( 'Select "at least one", if you want the COD to be restricted when at least one SKU of the cart is restricted. Select "all", if you want the COD to be restricted if all of the cart\'s SKU are restricted. Then add the restricted SKU in the textarea field below.', 'wc-smart-cod' ),
		);

		$form_fields['sku_product_restriction'] = array(
			'title'             => __( 'Disable on specific product SKU\'s', 'wc-smart-cod' ),
			'type'              => 'textarea',
			'class'             => 'wc-smart-cod-group wc-smart-cod-restriction',
			'description'       => __( 'Add the product SKU\'s you want to restrict the COD method. Seperate with a line break (enter)', 'wc-smart-cod' ),
			'disabled'          => false,
			'custom_attributes' => array(
				'data-name' => 'sku_product_restriction',
			),
		);

		$form_fields['shipping_class_restriction_mode'] = array(
			'title'        => __( 'Shipping Class Restriction Mode', 'wc-smart-cod' ),
			'type'         => 'radio',
			'parent_class' => 'wc-smart-cod-field inline',
			'class'        => 'wc-smart-cod-group',
			'options'      => array(
				'one_product'  => __( 'At least one product', 'wc-smart-cod' ),
				'all_products' => __( 'All products', 'wc-smart-cod' ),
			),
			'default'      => 'one_product',
			'disabled'     => false,
			'description'  => __( 'Select "at least one", if you want the COD to be restricted when at least one product of the cart belongs to a restricted shipping class. Select "all", if you want the COD to be restricted if all of the cart\'s product\'s belongs to restricted shipping classes. Then add the restricted shipping classes in the select field below.', 'wc-smart-cod' ),
		);

		$form_fields['shipping_class_restriction'] = array(
			'title'             => __( 'Disable on specific shipping classes', 'wc-smart-cod' ),
			'type'              => 'multiselect',
			'class'             => 'wc-enhanced-select wc-smart-cod-group wc-smart-cod-restriction',
			'description'       => __( 'Select the shipping classes you want to restrict the COD method', 'wc-smart-cod' ),
			'options'           => $shipping_classes,
			'desc_tip'          => true,
			'disabled'          => false,
			'custom_attributes' => array(
				'data-placeholder' => __( 'Select Shipping Classes', 'wc-smart-cod' ),
				'data-name'        => 'shipping_class_restriction',
			),
		);

		$form_fields['shipping_zone_method_restriction'] = array(
			'title'             => __( 'Disable on specific shipping methods of zones', 'wc-smart-cod' ),
			'type'              => 'multiselect',
			'class'             => 'wc-enhanced-select wc-smart-cod-group wc-smart-cod-restriction',
			'description'       => __( 'Select the shipping methods of specific zones, you want to restrict the COD method. <strong>Please note that for WooCommerce versions >= 3.4, this is a built in feature, so if you use the WooCommerce setting, this setting will be disabled. Otherwise leave the WooCommerce setting blank and use our setting.</strong>', 'wc-smart-cod' ),
			'options'           => $zone_methods,
			'disabled'          => false || ! ! $this->has_native_zone_method(),
			'custom_attributes' => array(
				'data-placeholder' => __( 'Select Shipping Methods', 'wc-smart-cod' ),
				'data-name'        => 'shipping_zone_method_restriction',
			),
		);

		$form_fields['stock_restriction'] = array(
			'title'             => __( 'Enable for this product stock range', 'wc-smart-cod' ),
			'type'              => 'range',
			'class'             => 'wc-smart-cod-group wc-smart-cod-restriction',
			'description'       => __( 'Add a range to restrict the COD method, based on the cart products stock', 'wc-smart-cod' ),
			'default_mode'      => 'enable',
			'placeholder'       => __( 'Enter Amount', 'wc-smart-cod' ),
			'disabled'          => false,
			'custom_attributes' => array(
				'data-name' => 'stock_restriction',
			),
		);

		$form_fields['product_qty_restriction'] = array(
			'title'             => __( 'Enable for this product quantity range', 'wc-smart-cod' ),
			'type'              => 'range',
			'class'             => 'wc-smart-cod-group wc-smart-cod-restriction',
			'description'       => __( 'Add a range to restrict the COD method, based on the cart products quantity', 'wc-smart-cod' ),
			'default_mode'      => 'enable',
			'placeholder'       => __( 'Enter quantity', 'wc-smart-cod' ),
			'disabled'          => false,
			'custom_attributes' => array(
				'data-name' => 'product_qty_restriction',
			),
		);

		$form_fields['backorders_restriction'] = array(
			'title'             => __( 'Disable on backorders', 'wc-smart-cod' ),
			'type'              => 'checkbox',
			'class'             => 'wc-smart-cod-group wc-smart-cod-restriction',
			'desc_tip'          => false,
			'disabled'          => false,
			'custom_attributes' => array(
				'data-disable-switch' => '1',
			),
		);

		$form_fields['weight_restriction_mode'] = array(
			'title'        => __( 'Product Weight Restriction Mode', 'wc-smart-cod' ),
			'type'         => 'radio',
			'parent_class' => 'wc-smart-cod-field inline',
			'class'        => 'wc-smart-cod-group',
			'disabled'     => false,
			'options'      => array(
				'individual' => __( 'Individual product weight', 'wc-smart-cod' ),
				'total'      => __( 'Total products weight', 'wc-smart-cod' ),
			),
			'default'      => 'individual',
			'description'  => __( 'Select individual product weight if you want the restriction to apply on every product seperately. Select Total products weight if you want to restrict on the sum of the products weight in the cart.', 'wc-smart-cod' ),
		);

		$form_fields['weight_restriction'] = array(
			'title'             => __( 'Enable for this product weight range', 'wc-smart-cod' ),
			'type'              => 'range',
			'class'             => 'wc-smart-cod-group wc-smart-cod-restriction',
			'description'       => __( 'Add a range to restrict the COD method, based on the cart products weight', 'wc-smart-cod' ),
			'default_mode'      => 'enable',
			'placeholder'       => __( 'Enter Amount', 'wc-smart-cod' ),
			'disabled'          => false,
			'custom_attributes' => array(
				'data-name' => 'weight_restriction',
			),
		);

		if ( $multivendor::has_wcfm() ) {
			global $WCFM;
			$vendors = $WCFM->wcfm_vendor_support->wcfm_get_vendor_list( true );
			if ( ! empty( $vendors ) && isset( $vendors[0] ) ) {
				unset( $vendors[0] );
			}

			$form_fields['wcfm_vendors_restriction'] = array(
				'title'             => __( 'Disable on specific WCFM vendors', 'wc-smart-cod' ),
				'type'              => 'multiselect',
				'class'             => 'wc-enhanced-select wc-smart-cod-group wc-smart-cod-restriction',
				'description'       => __( 'Select the WCFM vendors you want to restrict the COD method', 'wc-smart-cod' ),
				'options'           => $vendors,
				'desc_tip'          => true,
				'disabled'          => false,
				'custom_attributes' => array(
					'data-placeholder' => __( 'Select Vendors', 'wc-smart-cod' ),
					'data-name'        => 'wcfm_vendors_restriction',
				),
			);
		}

		if ( $multivendor::has_dokan() ) {

			$form_fields['dokan_vendors_restriction_mode'] = array(
				'title'        => __( 'Dokan Vendors Restriction Mode', 'wc-smart-cod' ),
				'type'         => 'radio',
				'parent_class' => 'wc-smart-cod-field inline',
				'class'        => 'wc-smart-cod-group',
				'disabled'     => false,
				'options'      => array(
					'one_vendor'  => __( 'At least one vendor', 'wc-smart-cod' ),
					'all_vendors' => __( 'All vendors', 'wc-smart-cod' ),
				),
				'default'      => 'one_vendor',
				'description'  => __( 'Select "at least one", if you want the COD to be restricted when at least one product of the cart belongs to a selected donkan vendor. Select "all", if you want the COD to be restricted if all the cart product\'s belongs to selected donkan vendors.', 'wc-smart-cod' ),
			);

			$vendors                                  = $multivendor::get_dokan_vendors();
			$form_fields['dokan_vendors_restriction'] = array(
				'title'             => __( 'Disable on specific Dokan vendors', 'wc-smart-cod' ),
				'type'              => 'multiselect',
				'class'             => 'wc-enhanced-select wc-smart-cod-group wc-smart-cod-restriction',
				'description'       => __( 'Select the Dokan vendors you want to restrict the COD method', 'wc-smart-cod' ),
				'options'           => $vendors,
				'desc_tip'          => true,
				'disabled'          => false,
				'custom_attributes' => array(
					'data-placeholder' => __( 'Select Vendors', 'wc-smart-cod' ),
					'data-name'        => 'dokan_vendors_restriction',
				),
			);
		}

		$form_fields['cod_unavailable_message'] = array(
			'title'       => __( 'COD Unavailable Message', 'wc-smart-cod' ),
			'type'        => 'cod_messages',
			'class'       => 'wc-smart-cod-group',
			'disabled'    => false,
			'description' => __( 'An informational text to display before the payment methods, when the COD method is not available for a customer. Leave it empty if you don\'t want to use this feature. You can define different messages per reason.', 'wc-smart-cod' ),
		);

		$form_fields['restriction_settings'] = array(
			'type'        => 'hidden',
			'title'       => '',
			'description' => '',
			'class'       => 'restriction-settings-hidden-input',
			'disabled'    => false,
		);

		$form_fields['cart_amount_mode'] = array(
			'title'       => __( 'Select what should be included to the cart amount total', 'wc-smart-cod' ),
			'type'        => 'checkboxes',
			'class'       => 'wc-smart-cod-group',
			'disabled'    => false,
			'options'     => array(
				'tax'      => __( 'Taxes', 'wc-smart-cod' ),
				'shipping' => __( 'Shipping Costs', 'wc-smart-cod' ),
			),
			'default'     => array( 'tax', 'shipping' ),
			'description' => __( 'This setting affect those settings: <strong>"Enable/Disable for this cart range"</strong> and <strong>"Disable/Enable if cart amount is greater than"</strong>. It defines what is finally calculated as the cart amount.', 'wc-smart-cod' ),
			'desc_tip'    => false,
		);

		if ( class_exists( 'Webexpert_Timologio_For_Woocommerce_Public' ) ) {
			$form_fields['invoice_restriction'] = array(
				'title'             => __( 'Disable on invoice orders', 'wc-smart-cod' ),
				'label'             => __( 'Disable on "timologio" invoice orders', 'wc-smart-cod' ),
				'type'              => 'checkbox',
				'class'             => 'wc-smart-cod-group wc-smart-cod-restriction',
				'desc_tip'          => false,
				'disabled'          => false,
				'custom_attributes' => array(
					'data-disable-switch' => '1',
				),
			);
		}

		if ( ! empty( $unset_zone_methods_fees ) ) {
			/**
			 * migrate to 1.4.7
			 */
			$this->migrate_shipping_zone_methods( $unset_zone_methods_fees );
		}

		$form_fields = $this->analyze_fields( $form_fields, $existing_settings, $restriction_settings, $old_wc_smart_cod );

		return $form_fields;

	}

	private function ga_u() {
		return isset( $this->settings['wsc_api_username'] ) && trim( $this->settings['wsc_api_username'] ) !== '' ? $this->settings['wsc_api_username'] : null;
	}

	public static function get_td( $html ) {
		$doc = new DOMDocument();
		$doc->loadHTML( mb_convert_encoding( $html, 'HTML-ENTITIES', 'UTF-8' ) );
		$doc->preserveWhiteSpace = false;
		$td                      = $doc->getElementsByTagName( 'td' );
		return self::dom_to_inner_html( $td[0] );
	}

	public static function dom_to_inner_html( DOMNode $element ) {
		$innerHTML = '';
		$children  = $element->childNodes;

		foreach ( $children as $child ) {
			$innerHTML .= $element->ownerDocument->saveHTML( $child );
		}

		return $innerHTML;
	}

	private function ga_k() {
		return isset( $this->settings['wsc_api_key'] ) && trim( $this->settings['wsc_api_key'] ) !== '' ? $this->settings['wsc_api_key'] : null;
	}

	protected function get_type_id() {
		$addon = self::get_current_addon();
		switch ( $addon ) {
			case 'restrictions': {
				return 1;
			}
			case null: {
				if ( ! $this->mode ) {
					return null;
				}
				return $this->mode === 'extra-fees' ? 2 : 3;
			}
		}
		return null;
	}

	public function generate_upload_html( $key, $data ) {
		$field_key = $this->get_field_key( $key . '[file]' );
		$defaults  = array(
			'title'             => '',
			'disabled'          => false,
			'class'             => '',
			'css'               => '',
			'placeholder'       => '',
			'type'              => 'text',
			'desc_tip'          => false,
			'description'       => '',
			'custom_attributes' => array(),
			'friendly_name'     => '',
		);

		$data   = wp_parse_args( $data, $defaults );
		$_value = $this->get_option( $key );
		$value  = isset( $_value['file'] ) && ! empty( $_value['file'] ) ? $_value['file'] : false;

		$tip1            = __( 'Please enter a header column first', 'wc-smart-cod' );
		$tip2            = __( 'Please preview your file first', 'wc-smart-cod' );
		$type_id         = $this->get_type_id();
		$current_rule_id = $this->current_rule_id;
		ob_start();
		?>
		<tr valign="top">
			<th scope="row" class="titledesc">
				<label for="<?php echo esc_attr( $field_key ); ?>"><?php echo wp_kses_post( $data['title'] ); ?> <?php echo $this->get_tooltip_html( $data ); // WPCS: XSS ok. ?></label>
			</th>
			<td class="forminp">
				<fieldset>
					<input type="hidden" value="<?php echo esc_attr( self::get_type_id() ); ?>" class="wsc-type-id" />
					<input type="hidden" value="<?php echo esc_attr( $current_rule_id ); ?>" class="wsc-rule-id" />
					<input id="<?php echo esc_attr( $key ); ?>_url" class="wsc-file-url" type="text" name="wsc-file-url" readonly />
					<input id="<?php echo esc_attr( $key ); ?>_id" type="hidden" class="wsc-file-id" name="wsc-file-id" />
					<input type="button" class="upload_csv_button button-primary" value="Select file" data-key="<?php echo esc_attr( $key ); ?>" />
					<?php echo $this->get_description_html( $data ); ?>
					<div class="upload-details" data-friendly-name="<?php echo $data['friendly_name']; ?>">
						<div class="has-header">
							<label>Does your file has a header row?</label>
							<input type="checkbox" id="<?php echo esc_attr( $key ); ?>_has_header" class="has-header-checkbox" name="wsc-has-header" checked />
						</div>
						<div class="header-column">
							<label>Please enter the header column name, which contains the <?php echo $data['friendly_name']; ?></label>
							<p>
								<input class="header-column-input" placeholder="e.g: <?php echo str_replace( ' ', '_', $data['friendly_name'] ); ?>" id="<?php echo esc_attr( $key ); ?>_header_column" type="text" name="wsc-header-column" />
								<button type="button" class="preview-csv button-secondary tips disabled" data-preserve-tip="<?php echo $tip1; ?>" data-tip="<?php echo $tip1; ?>">Preview 3 first rows</button>
								<span class="spinner"></span>
								<button type="button" class="import-csv button-primary tips disabled" data-preserve-tip="<?php echo $tip2; ?>" data-tip="<?php echo $tip2; ?>">Import CSV</button>
							</p>
						</div>
						<div class="output"></div>
						<p class="description">You can upload as many CSV files as you want.<br/>Every time you upload a new CSV, the previous uploaded data persists!<br /> If a new import run finds duplicates, they will be ignored keeping the data clean.</p>
					</div>
					<?php if ( $value ) : ?>
						<div class="wsc-values-section">
							<input type="hidden" name="<?php echo esc_attr( $field_key ); ?>[collection_id]" value="<?php echo $value['collection_id']; ?>" />
							<input type="hidden" name="<?php echo esc_attr( $field_key ); ?>[entries]" value="<?php echo $value['entries']; ?>" />
						</div>
						<div class="wsc-delete-section">
							<button type="button" class="delete-entries button-secondary" data-collection-id="<?php echo $value['collection_id']; ?>">Delete existing records (<?php echo $value['entries']; ?>)</button>
							<span class="spinner"></span>
							<div class="wsc-delete-output"></div>
						</div>
					<?php endif; ?>
				</fieldset>
			</td>
		</tr>
		<?php

		return ob_get_clean();
	}

	public function validate_file_textarea_field( $key, $value ) {
		if ( ! is_array( $value ) || empty( $value ) ) {
			return '';
		}

		if ( isset( $value['textarea'] ) && $value['textarea'] ) {
			$value['textarea'] = $this->validate_textarea_field( $key, $value['textarea'] );
		}

		return $value;
	}

	public function generate_file_textarea_html( $key, $data ) {
		$field_key = $this->get_field_key( $key );
		$defaults  = array(
			'title'             => '',
			'disabled'          => false,
			'class'             => '',
			'css'               => '',
			'placeholder'       => '',
			'type'              => 'text',
			'desc_tip'          => false,
			'description'       => '',
			'custom_attributes' => array(),
			'options'           => array(),
			'parent_class'      => '',
			'default'           => '',
			'friendly_name'     => '',
		);

		$data = wp_parse_args( $data, $defaults );

		ob_start();
		?>
		<tr valign="top">
			<th scope="row" class="titledesc">
				<?php echo $this->get_tooltip_html( $data ); ?>
				<label for="<?php echo esc_attr( $field_key ); ?>"><?php echo wp_kses_post( $data['title'] ); ?></label>
			</th>
			<td class="forminp forminp-<?php echo sanitize_title( $data['type'] ); ?><?php echo $data['parent_class'] ? ' ' . esc_attr( $data['parent_class'] ) : ''; ?>">
				<fieldset>
					<header>
						<ul class="wsc-select-mode">
							<li class="selected">
								<a href="#" data-mode="textarea">Raw</a>
							</li>
							<li>
								<a href="#" data-mode="file">Bulk upload (csv)</a>
							</li>
						</ul>
						<input type="hidden" class="<?php echo esc_attr( $data['class'] ); ?>" <?php echo $this->get_custom_attribute_html( $data ); // WPCS: XSS ok. ?> />
					</header>
					<main>
						<ul class="wsc-mode-content">
							<li class="wsc-mode-file">
								<?php
									echo self::get_td(
										$this->generate_upload_html(
											$key,
											array(
												'disabled' => $data['disabled'],
												'class'    => $data['class'],
												'description' => $data['description']['upload'],
												'friendly_name' => $data['friendly_name'],
											)
										)
									);
								?>
							</li>
							<li class="wsc-mode-textarea selected">
								<?php
									echo self::get_td(
										$this->generate_wsctextarea_html(
											$key,
											array(
												'disabled' => $data['disabled'],
												'class'    => $data['class'],
												'description' => $data['description']['textarea'],
											)
										)
									);
								?>
							</li>
						</ul>
					</main>
				</fieldset>
			</td>
		</tr>
		<?php
		return ob_get_clean();

	}

	public function generate_wsctextarea_html( $key, $data ) {
		$field_key = $this->get_field_key( $key . '[textarea]' );
		$defaults  = array(
			'title'             => '',
			'disabled'          => false,
			'class'             => '',
			'css'               => '',
			'placeholder'       => '',
			'type'              => 'text',
			'desc_tip'          => false,
			'description'       => '',
			'custom_attributes' => array(),
		);

		$data   = wp_parse_args( $data, $defaults );
		$_value = $this->get_option( $key );
		if ( $_value && is_string( $_value ) ) {
			// migrate from old settings
			$_value = array( 'textarea' => $_value );
		}

		$value = isset( $_value['textarea'] ) && ! empty( $_value['textarea'] ) ? $_value['textarea'] : '';

		ob_start();
		?>
		<tr valign="top">
			<th scope="row" class="titledesc">
				<label for="<?php echo esc_attr( $field_key ); ?>"><?php echo wp_kses_post( $data['title'] ); ?> <?php echo $this->get_tooltip_html( $data ); // WPCS: XSS ok. ?></label>
			</th>
			<td class="forminp">
				<fieldset>
					<legend class="screen-reader-text"><span><?php echo wp_kses_post( $data['title'] ); ?></span></legend>
					<textarea rows="3" cols="20" class="input-text wide-input <?php echo esc_attr( $data['class'] ); ?>" type="<?php echo esc_attr( $data['type'] ); ?>" name="<?php echo esc_attr( $field_key ); ?>" id="<?php echo esc_attr( $field_key ); ?>" style="<?php echo esc_attr( $data['css'] ); ?>" placeholder="<?php echo esc_attr( $data['placeholder'] ); ?>" <?php disabled( $data['disabled'], true ); ?> <?php echo $this->get_custom_attribute_html( $data ); // WPCS: XSS ok. ?>><?php echo esc_textarea( $value ); ?></textarea>
					<?php echo $this->get_description_html( $data ); // WPCS: XSS ok. ?>
				</fieldset>
			</td>
		</tr>
		<?php

		return ob_get_clean();
	}

	public function generate_cod_messages_html( $key, $data ) {

		$field_key = $this->get_field_key( $key );
		$defaults  = array(
			'title'             => '',
			'disabled'          => false,
			'class'             => '',
			'css'               => '',
			'placeholder'       => '',
			'type'              => 'text',
			'desc_tip'          => false,
			'description'       => '',
			'custom_attributes' => array(),
		);

		$restrictions = array(
			'generic'              => 'Generic Message',
			'shipping_method'      => 'Unavailable by restricted shipping method',
			'shipping_zone'        => 'Unavailable by restricted shipping zone',
			'country'              => 'Unavailable by restricted country',
			'state'                => 'Unavailable by restricted state',
			'postal'               => 'Unavailable by restricted postal code',
			'city'                 => 'Unavailable by restricted city',
			'cart_amount'          => 'Unavailable by restricted cart amount',
			'user_role'            => 'Unavailable by restricted user role',
			'category'             => 'Unavailable by restricted product category',
			'product'              => 'Unavailable by restricted product',
			'shipping_class'       => 'Unavailable by restricted shipping class',
			'shipping_zone_method' => 'Unavailable by restricted shipping method of a specific zone',
			'cart_range'           => 'Unavailable by restricted cart amount range',
			'user'                 => 'Unavailable by restricted user',
			'user_email'           => 'Unavailable by restricted user email',
			'coupon'               => 'Unavailable by restricted coupon',
			'stock'                => 'Unavailable by restricted stock',
			'backorders'           => 'Unavailable by restricted backorders',
			'weight'               => 'Unavailable by restricted weight',
			'product_qty'          => 'Unavailable by restricted product quantity',
		);

		$data   = wp_parse_args( $data, $defaults );
		$tvalue = $this->get_option( $key );
		if ( ! is_array( $tvalue ) ) {
			// old wsc ( before 1.4.4 )
			// migrate value
			$_value = array();

			if ( $tvalue !== '' ) {
				$_value['generic'] = $tvalue;
			}
			$tvalue = $_value;
		}

		ob_start();
		?>
		<tr valign="top">
			<th scope="row" class="titledesc">
				<?php echo $this->get_tooltip_html( $data ); ?>
				<label for="<?php echo esc_attr( $field_key ); ?>"><?php echo wp_kses_post( $data['title'] ); ?></label>
			</th>
			<td class="forminp">
				<select class="select wsc-message-switcher" name="wsc-message-switcher" <?php disabled( $data['disabled'], true ); ?>>
					<?php
					foreach ( $restrictions as $value => $label ) {
								echo sprintf( '<option value="%s">%s</option>', $value, $label );
					}
					?>
				</select>
				<?php
				$index = 0;
				foreach ( $restrictions as $value => $label ) :
					$textarea_value = array_key_exists( $value, $tvalue ) ? esc_textarea( $tvalue[ $value ] ) : '';
					?>
																<fieldset class="wsc-message<?php echo $index > 0 ? ' hidden' : ''; ?>" data-restriction="<?php echo $value; ?>">
																	<legend class="screen-reader-text"><span><?php echo wp_kses_post( $data['title'] ); ?></span></legend>
																	<textarea rows="5" cols="20" class="input-text wide-input <?php echo esc_attr( $data['class'] ); ?>" type="<?php echo esc_attr( $data['type'] ); ?>" name="<?php echo esc_attr( $field_key ) . '[' . esc_attr( $value ) . ']'; ?>" id="<?php echo esc_attr( $field_key ) . '[' . esc_attr( $value ) . ']'; ?>" style="<?php echo esc_attr( $data['css'] ); ?>" placeholder="<?php echo esc_attr( $data['placeholder'] ); ?>" <?php disabled( $data['disabled'], true ); ?> <?php echo $this->get_custom_attribute_html( $data ); ?>><?php echo $textarea_value; ?></textarea>
																</fieldset>
															<?php
															$index++;
		endforeach;
				echo $this->get_description_html( $data );
				?>
			</td>
		</tr>
		<?php

		return ob_get_clean();

	}

	public function get_kk() {
		return 'disabled';
	}

	public function validate_cod_messages_field( $key, $value ) {
		if ( ! empty( $value ) ) {
			foreach ( $value as $k => $v ) {
				$value[ $k ] = $this->validate_textarea_field( $k, $v );
			}
		}
		return $value;
	}

	public function generate_checkboxes_html( $key, $data ) {

		$field_key = $this->get_field_key( $key );

		$defaults = array(
			'title'             => '',
			'disabled'          => false,
			'class'             => '',
			'css'               => '',
			'placeholder'       => '',
			'type'              => 'text',
			'desc_tip'          => false,
			'description'       => '',
			'custom_attributes' => array(),
			'options'           => array(),
			'parent_class'      => '',
			'default'           => '',
		);

		$data  = wp_parse_args( $data, $defaults );
		$value = $this->get_option( $key );

		if ( $value === '' ) {
			if ( $data['default'] ) {
				$value = $data['default'];
			}
		}

		ob_start();
		?>
		<tr valign="top">
			<th scope="row" class="titledesc">
				<?php echo $this->get_tooltip_html( $data ); ?>
				<label for="<?php echo esc_attr( $field_key ); ?>"><?php echo wp_kses_post( $data['title'] ); ?></label>
			</th>
			<td class="forminp forminp-<?php echo sanitize_title( $data['type'] ); ?><?php echo $data['parent_class'] ? ' ' . esc_attr( $data['parent_class'] ) : ''; ?>">
				<fieldset>
					<ul>
					<?php
					foreach ( (array) $data['options'] as $option_key => $option_value ) {
						?>
							<li>
								<label><input
									name="<?php echo esc_attr( $field_key ); ?>[]"
									value="<?php echo $option_key; ?>"
									type="checkbox"
									style="<?php echo esc_attr( $data['css'] ); ?>"
									class="<?php echo esc_attr( $data['class'] ); ?>"
									<?php echo $this->get_custom_attribute_html( $data ); ?>
									<?php checked( $option_key, in_array( $option_key, $value ) ? $option_key : false ); ?>
									<?php disabled( $data['disabled'], true ); ?>
									/> <?php echo esc_attr( $option_value ); ?></label>
							</li>
							<?php
					}
					?>
					</ul>
					<?php echo $this->get_description_html( $data ); ?>
				</fieldset>
			</td>
		</tr>
		<?php
		return ob_get_clean();
	}

	public function generate_toggle_html( $key, $data ) {

		$field_key = $this->get_field_key( $key );

		$defaults = array(
			'title'             => '',
			'disabled'          => false,
			'class'             => '',
			'css'               => '',
			'placeholder'       => '',
			'type'              => 'text',
			'desc_tip'          => false,
			'description'       => '',
			'custom_attributes' => array(),
			'options'           => array(),
			'parent_class'      => '',
			'default'           => '',
		);

		$data = wp_parse_args( $data, $defaults );

		$value = esc_attr( $this->get_option( $key ) );
		if ( $value === '' && $data['default'] !== '' ) {
			$value = $data['default'];
		}
		$value = intval( $value );
		ob_start();
		?>
		<tr valign="top">
			<th scope="row" class="titledesc">
				<?php echo $this->get_tooltip_html( $data ); ?>
				<label for="<?php echo esc_attr( $field_key ); ?>"><?php echo wp_kses_post( $data['title'] ); ?></label>
			</th>
			<td class="forminp forminp-<?php echo sanitize_title( $data['type'] ); ?><?php echo $data['parent_class'] ? ' ' . esc_attr( $data['parent_class'] ) : ''; ?>">
				<fieldset>
					<div class="toggle-wrapper<?php echo $data['disabled'] ? ' disabled' : ''; ?>">
						<span class="woocommerce-input-toggle
						<?php
						if ( ! $value ) {
							echo ' woocommerce-input-toggle--disabled';}
						?>
						">No</span>
						<input type="hidden" <?php disabled( $data['disabled'], true ); ?> name="<?php echo $field_key; ?>" value="<?php echo $value; ?>" />
					</div>
					<?php echo $this->get_description_html( $data ); ?>
				</fieldset>
			</td>
		</tr>
		<?php
		return ob_get_clean();
	}

	public function validate_toggle_field( $key, $value ) {
		try {
			$value = intval( $value );
			return ! is_null( $value ) && $value === 1 ? 1 : 0;
		} catch ( Exception $e ) {
			return 0;
		}
	}

	public function generate_json_html( $key, $data ) {

		$field_key = $this->get_field_key( $key );

		$defaults = array(
			'title'             => '',
			'disabled'          => false,
			'class'             => '',
			'css'               => '',
			'placeholder'       => '',
			'type'              => 'text',
			'desc_tip'          => false,
			'description'       => '',
			'custom_attributes' => array(),
			'options'           => array(),
			'parent_class'      => '',
			'default'           => '',
		);

		$data  = wp_parse_args( $data, $defaults );
		$value = $this->get_option( $key );
		if ( $value === '' && $data['default'] !== '' ) {
			$value = $data['default'];
		}
		ob_start();
		?>
		<tr valign="top">
			<th scope="row" class="titledesc">
				<?php echo $this->get_tooltip_html( $data ); ?>
				<label for="<?php echo esc_attr( $field_key ); ?>"><?php echo wp_kses_post( $data['title'] ); ?></label>
			</th>
			<td class="forminp forminp-<?php echo sanitize_title( $data['type'] ); ?><?php echo $data['parent_class'] ? ' ' . esc_attr( $data['parent_class'] ) : ''; ?>">
				<fieldset>
					<input type="hidden" <?php disabled( $data['disabled'], true ); ?> name="<?php echo $field_key; ?>" value="<?php echo htmlspecialchars( json_encode( $value ) ); ?>" />
				</fieldset>
			</td>
		</tr>
		<?php
		return ob_get_clean();
	}

	public function generate_radio_html( $key, $data ) {

		$field_key = $this->get_field_key( $key );

		$defaults = array(
			'title'             => '',
			'disabled'          => false,
			'class'             => '',
			'css'               => '',
			'placeholder'       => '',
			'type'              => 'text',
			'desc_tip'          => false,
			'description'       => '',
			'custom_attributes' => array(),
			'options'           => array(),
			'parent_class'      => '',
			'default'           => '',
		);

		$data  = wp_parse_args( $data, $defaults );
		$value = esc_attr( $this->get_option( $key ) );

		if ( ! $value && ( ! array_key_exists( $key, $this->settings ) || ( isset( $data['external'] ) && $data['external'] ) ) ) {
			if ( $data['default'] ) {
				$value = $data['default'];
			}
		}

		ob_start();
		?>
		<tr valign="top">
			<th scope="row" class="titledesc">
				<?php echo $this->get_tooltip_html( $data ); ?>
				<label for="<?php echo esc_attr( $field_key ); ?>">
					<?php echo wp_kses_post( $data['title'] ); ?>
				</label>
			</th>
			<td class="forminp forminp-<?php echo sanitize_title( $data['type'] ); ?><?php echo $data['parent_class'] ? ' ' . esc_attr( $data['parent_class'] ) : ''; ?>">
				<fieldset>
					<ul>
					<?php
					foreach ( (array) $data['options'] as $option_key => $option_value ) {
						?>
							<li>
								<label><input
									name="<?php echo esc_attr( $field_key ); ?>"
									value="<?php echo $option_key; ?>"
									type="radio"
									style="<?php echo esc_attr( $data['css'] ); ?>"
									class="<?php echo esc_attr( $data['class'] ); ?>"
									<?php echo $this->get_custom_attribute_html( $data ); ?>
									<?php checked( $option_key, $value ); ?>
									<?php disabled( $data['disabled'], true ); ?>
									/> <?php echo esc_attr( $option_value ); ?></label>
							</li>
							<?php
					}
					?>
					</ul>
					<?php echo $this->get_description_html( $data ); ?>
				</fieldset>
			</td>
		</tr>
		<?php
		return ob_get_clean();
	}

	public function validate_range_field( $key, $value ) {
		$validated = array(
			'from' => '',
			'to'   => '',
		);
		if ( is_array( $value ) ) {
			if ( isset( $value['from'] ) ) {
				$validated['from'] = $this->validate_price_field( $key, $value['from'] );
			}
			if ( isset( $value['to'] ) ) {
				$validated['to'] = $this->validate_price_field( $key, $value['to'] );
			}
		}
		if ( $validated['from'] === '' && $validated['to'] === '' ) {
			return '';
		}
		return $validated;
	}

	public function generate_range_html( $key, $data ) {

		$field_key = $this->get_field_key( $key );

		$defaults = array(
			'title'             => '',
			'disabled'          => false,
			'class'             => '',
			'css'               => '',
			'placeholder'       => '',
			'type'              => 'text',
			'desc_tip'          => false,
			'description'       => '',
			'custom_attributes' => array(),
		);

		$data  = wp_parse_args( $data, $defaults );
		$value = $this->get_option( $key );

		$value_from = $value && isset( $value['from'] ) ? $value['from'] : '';
		$value_to   = $value && isset( $value['to'] ) ? $value['to'] : '';
		ob_start();
		?>
		<tr valign="top" class="<?php echo Wc_Smart_Cod::$plugin_name . '-' . esc_attr( $data['type'] ) . '-field'; ?>">
			<th scope="row" class="titledesc">
				<?php echo $this->get_tooltip_html( $data ); ?>
				<label for="<?php echo esc_attr( $field_key ); ?>">
					<?php echo wp_kses_post( $data['title'] ); ?>
				</label>
			</th>
			<td class="forminp">
				<fieldset>
					<div>
						<input class="wc_input_price input-text regular-input <?php echo esc_attr( $data['class'] ); ?>" type="text" name="<?php echo esc_attr( $field_key ) . '[from]'; ?>" id="<?php echo esc_attr( $field_key . '[from]' ); ?>" style="<?php echo esc_attr( $data['css'] ); ?>" value="<?php echo esc_attr( wc_format_localized_price( $value_from ) ); ?>" placeholder="<?php _e( 'From', 'woocommerce' ); ?>" <?php disabled( $data['disabled'], true ); ?> <?php echo $this->get_custom_attribute_html( $data ); // WPCS: XSS ok. ?> />
					</div>
					<div>
						<input class="wc_input_price input-text regular-input <?php echo esc_attr( $data['class'] ); ?>" type="text" name="<?php echo esc_attr( $field_key ) . '[to]'; ?>" id="<?php echo esc_attr( $field_key . '[to]' ); ?>" style="<?php echo esc_attr( $data['css'] ); ?>" value="<?php echo esc_attr( wc_format_localized_price( $value_to ) ); ?>" placeholder="<?php _e( 'To', 'woocommerce' ); ?>" <?php disabled( $data['disabled'], true ); ?> <?php echo $this->get_custom_attribute_html( $data ); // WPCS: XSS ok. ?> />
					</div>
				</fieldset>
				<?php echo $this->get_description_html( $data ); // WPCS: XSS ok. ?>
			</td>
		</tr>
		<?php

		return ob_get_clean();

	}

	public function validate_radio_field( $key, $value ) {
		$value = is_null( $value ) ? '' : $value;
		return wc_clean( stripslashes( $value ) );
	}

	public function validate_checkboxes_field( $key, $value ) {
		$_value = array();
		if ( ! $value ) {
			return array();
		}
		foreach ( $value as $v ) {
			array_push( $_value, wc_clean( stripslashes( $v ) ) );
		}
		return $_value;
	}

	public function clean_up_gateway( $zone_id ) {

		$settings = get_option( 'woocommerce_cod_settings' );
		foreach ( $settings as $key => $setting ) {
			if ( $key === 'different_charge_' . $zone_id || strpos( $key, 'zonemethod_different_charge_' . $zone_id ) === 0 ) {
				unset( $settings[ $key ] );
			}
		}

		update_option( 'woocommerce_cod_settings', $settings );

	}

	public function clean_up_settings( $settings ) {

		if ( isset( $settings['fee_settings'] ) && $settings['fee_settings'] ) {
			$fee_settings = json_decode( $settings['fee_settings'], true );
			$needs_update = false;
			foreach ( $fee_settings as $k => $v ) {
				if ( ! isset( $this->prepared_fields[ $k ] ) ) {
					$needs_update = true;
					unset( $fee_settings[ $k ] );
				}
			}
			if ( $needs_update ) {
				$settings['fee_settings'] = json_encode( $fee_settings );
			}
		}

		foreach ( $settings as $key => $setting ) {

			if ( strpos( $key, 'different_charge_' ) === 0 || strpos( $key, 'zonemethod_different_charge_' ) === 0 || strpos( $key, 'method_different_charge_' ) === 0 ) {
				if ( ! is_numeric( $setting ) ) {
					unset( $settings[ $key ] );
				}
			}
		}

		delete_transient( 'wsc_i_a' );

		return $settings;

	}

	protected function get_json_settings( $key ) {

		if ( array_key_exists( $key, $this->settings ) ) {
			$option = json_decode( $this->settings[ $key ], true );
		} else {
			$option = array();
		}

		return $option;
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */

	/**
	 * Register the scripts and styles for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wc_Smart_Cod_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wc_Smart_Cod_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		$screen          = get_current_screen();
		$current_section = isset( $_GET['section'] ) ? $_GET['section'] : '';

		if ( isset( $screen->base ) && $screen->base === 'woocommerce_page_wc-settings' && $current_section === 'cod' ) {

			$messages = array(
				'nan'             => __( 'This field should be a number only.', 'wc-smart-cod' ),
				'please_save_msg' => __( 'Please save the changes to see the new settings', 'wc-smart-cod' ),
			);

			wp_register_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wc-smart-cod-admin.min.js', array( 'jquery' ), self::$version, false );

			$enhanced_select_variables = array(
				'i18n_no_matches'           => _x( 'No matches found', 'enhanced select', 'woocommerce' ),
				'i18n_ajax_error'           => _x( 'Loading failed', 'enhanced select', 'woocommerce' ),
				'i18n_input_too_short_1'    => _x( 'Please enter 1 or more characters', 'enhanced select', 'woocommerce' ),
				'i18n_input_too_short_n'    => _x( 'Please enter %qty% or more characters', 'enhanced select', 'woocommerce' ),
				'i18n_input_too_long_1'     => _x( 'Please delete 1 character', 'enhanced select', 'woocommerce' ),
				'i18n_input_too_long_n'     => _x( 'Please delete %qty% characters', 'enhanced select', 'woocommerce' ),
				'i18n_selection_too_long_1' => _x( 'You can only select 1 item', 'enhanced select', 'woocommerce' ),
				'i18n_selection_too_long_n' => _x( 'You can only select %qty% items', 'enhanced select', 'woocommerce' ),
				'i18n_load_more'            => _x( 'Loading more results&hellip;', 'enhanced select', 'woocommerce' ),
				'i18n_searching'            => _x( 'Searching&hellip;', 'enhanced select', 'woocommerce' ),
				'ajax_url'                  => admin_url( 'admin-ajax.php' ),
				'search_products_nonce'     => wp_create_nonce( 'search-products' ),
				'search_categories_nonce'   => wp_create_nonce( 'search-categories' ),
				'search_customers_nonce'    => wp_create_nonce( 'search-customers' ),
			);

			$variables = array(
				'messages'             => $messages,
				'enhanced_select'      => $enhanced_select_variables,
				'restriction_settings' => (object) $this->get_json_settings( 'restriction_settings' ),
				'fee_settings'         => (object) $this->get_json_settings( 'fee_settings' ),
				'wsc_csv_nonce'        => wp_create_nonce( 'wsc-csv-nonce' ),
				'a'                    => $this->__a(),
				'pu'                   => self::$plugin_url,
				'u'                    => $this->ga_u(),
				'ak'                   => $this->ga_k(),
				't'                    => self::get_current_addon(),
				'su'                   => $this->ga_su(),
			);

			global $wp_scripts;
			$select2     = array_key_exists( 'select2', $wp_scripts->registered ) ? $wp_scripts->registered['select2'] : false;
			$select2_ver = ( $select2 === false ? false : property_exists( $select2, 'ver' ) ) ? $select2->ver : false;

			if ( ! $select2 || ! $select2_ver || version_compare( $select2_ver, '4.0.3' ) === -1 ) {
				// compatibility with older WooCommerce.
				wp_deregister_script( 'select2' );
				wp_register_script( 'select2', plugin_dir_url( __FILE__ ) . 'js/select2.full.min.js', array( 'jquery' ), '4.0.3', false );
				wp_enqueue_style( 'select2', plugin_dir_url( __FILE__ ) . 'css/wc-smart-cod-select2.css', array(), '4.0.3', 'all' );
				wp_enqueue_script( 'select2' );
			}

			wp_enqueue_media();

			wp_localize_script( $this->plugin_name, 'smart_cod_variables', $variables );
			wp_enqueue_script( $this->plugin_name );
			wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wc-smart-cod-admin.css', array(), self::$version, 'all' );
		}

	}

}
