=== WooCommerce Smart COD PRO ===
Contributors: fullstackhouse
Tags: WooCommerce, Cash on Delivery, COD, COD Extra Fee, Smart COD, WooCommerce COD, Multiple Fees
Requires at least: 3.0.1
Tested up to: 6.0
Stable tag: 1.4.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

All the COD restrictions and extra fees you'll ever need, in a single plugin.