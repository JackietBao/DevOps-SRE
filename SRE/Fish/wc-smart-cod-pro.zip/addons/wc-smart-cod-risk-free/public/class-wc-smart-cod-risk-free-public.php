<?php
/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://woosmartcod.com
 * @since      1.0.0
 *
 * @package    Wc_Smart_Cod_Risk_Free
 * @subpackage Wc_Smart_Cod_Risk_Free/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Wc_Smart_Cod_Risk_Free
 * @subpackage Wc_Smart_Cod_Risk_Free/public
 * @author     woosmartcod.com <info@woosmartcod.com>
 */
class Wc_Smart_Cod_Risk_Free_Public extends Wc_Smart_Cod_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	private static $option_name = 'woocommerce_smartcod_riskfree_settings';

	private $rf_settings = null;

	private $real_total = null;

	private $remaining_amount = null;

	private static $fee_key = 'wsc_rf_fee';

	private $disallowed_payment_gateways = null;

	protected $mode;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string $plugin_name       The name of the plugin.
	 * @param      string $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version, $mode ) {

		$this->plugin_name = $plugin_name;
		$this->version     = $version;
		$this->mode        = $mode;
		parent::__construct( $plugin_name );
		if ( $mode === 'risk-free' ) {
			add_filter( 'woocommerce_update_order_review_fragments', array( $this, 'change_fragments' ), 9999 );
			add_action( 'woocommerce_review_order_before_order_total', array( $this, 'add_real_total' ) );
			add_action( 'woocommerce_checkout_create_order', array( $this, 'enrich_order_data' ), 10, 2 );
			add_filter( 'woocommerce_get_order_item_totals', array( $this, 'enrich_item_totals' ), 10, 2 );
			add_filter( 'woocommerce_available_payment_gateways', array( $this, 'apply_gateways_restriction' ), 10, 1 );
			add_action( 'woocommerce_after_calculate_totals', array( $this, 'after_calculate_total' ), 9999, 1 );
			add_filter( 'woocommerce_my_account_my_orders_actions', array( $this, 'hide_rf_orders' ), 10, 2 );
			add_action( 'woocommerce_checkout_update_order_review', array( $this, 'maybe_change_payment_method' ), 10, 1 );
			add_action( 'woocommerce_thankyou', array( $this, 'thank_you_trigger' ), 9999, 1 );
			add_action( 'woocommerce_order_payment_status_changed', array( $this, 'maybe_change_advance_status' ), 9999, 2 );
			add_filter( 'woocommerce_my_account_my_orders_query', array( $this, 'maybe_remove_rf_advance_orders' ), 9999, 1 );
			add_filter( 'woocommerce_email_enabled_customer_completed_order', array( $this, 'disable_advance_email' ), 9999, 2 );
			add_filter( 'woocommerce_rest_orders_prepare_object_query', array( $this, 'maybe_remove_advance_restapi_orders' ), 9999, 2 );
			add_action( 'before_woocommerce_pay', array( $this, 'block_rf_order' ) );

			self::add_third_party_fe_compatibility();

		} else {
			add_action( 'woocommerce_cart_calculate_fees', array( $this, 'apply_smartcod_fees' ), 99999, 1 );
			$multivendor = Wc_Smart_Cod_MultiVendors_Helper::get_instance();
			if ( $multivendor::has_dokan() ) {
				add_action( 'dokan_checkout_update_order_meta', array( $this, 'maybe_attach_dokan_fees' ), 5, 2 );
			}
		}
	}

	public function block_rf_order() {
		global $wp;
		$order_id = $wp->query_vars['order-pay'];

		if ( ! $order_id ) {
			return;
		}

		$order = new WC_Order( $order_id );

		if ( ! $this->is_rf_order( $order ) ) {
			return;
		}

		if ( isset( $_GET['pay_for_order'], $_GET['key'] ) && $order_id ) {
			wc_print_notice( __( 'This is a risk free COD order and it cannot be paid for afterwards. Please create a new order.', 'wc-smart-cod' ), 'error' );
			$order->update_status( 'cancelled' );
		}
	}

	public function maybe_attach_dokan_fees( $order_id, $seller_id ) {
		$order        = wc_get_order( $order_id );
		$parent_id    = $order->get_parent_id();
		$parent_order = wc_get_order( $parent_id );
		$settings     = get_option( 'woocommerce_smartcod_extrafees_settings' );
		foreach ( $parent_order->get_items( 'fee' ) as $item_id => $item_fee ) {
			if ( $author_id = $item_fee->get_meta( 'wsc_extra_fee_author_id' ) ) {
				// is a multifee
				if ( intval( $author_id ) !== $seller_id ) {
					continue;
				}

				$item = new WC_Order_Item_Fee();
				$item->set_name( $item_fee->get_name() );
				$item->set_total( $item_fee->get_total() );
				$item->set_amount( $item_fee->get_amount() );
				$item->set_tax_class( $item_fee->get_tax_class() );
				$item->set_tax_status( $item_fee->get_tax_status() );
				$item->set_total_tax( $item_fee->get_total_tax() );
				$item->get_taxes( $item_fee->get_taxes() );
				$item->save();
				$order->add_item( $item );

			}
		}
		$order->calculate_totals();
		$order->save();
	}

	public static function add_third_party_fe_compatibility() {
			/**
			 * Advanced Dynamic Pricing for WooCommerce
			 * Provide compatibility
			 */
		if ( class_exists( 'WDP_Functions' ) ) {
			add_filter(
				'wdp_calculate_totals_hook_priority',
				function() {
						return 9000;
				}
			);
		}
	}

	public function disable_advance_email( $enabled, $order ) {

		if ( ! $order ) {
			return $enabled;
		}

		$settings = $this->get_rf_settings();

		if ( ! $order->get_meta( 'is_wsc_advance' ) ) {
			return $enabled;
		}

		if ( isset( $settings['add_customer_advance_order_email'] ) && $settings['add_customer_advance_order_email'] === 'yes' ) {
			return $enabled;
		}

		return false;

	}

	public function maybe_remove_advance_restapi_orders( $args ) {
		$settings = $this->get_rf_settings();

		if ( isset( $settings['add_customer_advance_order_api'] ) && $settings['add_customer_advance_order_api'] === 'yes' ) {
			return $args;
		}

		$args['meta_key']     = 'is_wsc_advance';
		$args['meta_compare'] = 'NOT EXISTS';

		return $args;
	}

	public function maybe_remove_rf_advance_orders( $query ) {

		$settings = $this->get_rf_settings();

		if ( isset( $settings['add_customer_advance_orders'] ) && $settings['add_customer_advance_orders'] === 'yes' ) {
			return $query;
		}

		$query['meta_key']     = 'is_wsc_advance';
		$query['meta_compare'] = 'NOT EXISTS';

		return $query;
	}

	public function maybe_change_advance_status( $order_id, $order ) {
		if ( ! $this->is_rf_order( $order ) ) {
			return;
		}

		$advance_order_id = $order->get_meta( 'wsc_advance_order_id' );
		if ( ! $advance_order_id ) {
			return;
		}

		$advance_order = wc_get_order( $advance_order_id );
		if ( ! $advance_order ) {
			return;
		}

		if ( $advance_order->get_status() === 'completed' ) {
			return;
		}

		$advance_order->update_status( 'completed' );

	}

	public function maybe_change_payment_method() {

		if ( ! $this->is_enabled() || ! self::is_user_checked() ) {
			return;
		}

		$rule = $this->get_user_rf();

		if ( ! $rule ) {
			return;
		}

		if ( ! $this->has_gateways_available( $rule ) ) {
			return;
		}

		$gateways = $this->get_gateways_available( $rule );

		$selected_method = empty( $_POST['payment_method'] ) ? '' : wc_clean( wp_unslash( $_POST['payment_method'] ) );

		if ( ! isset( $gateways[ $selected_method ] ) ) {
			/**
			 * Switch from payment method that
			 * not exists for risk free COD
			 * go to first available and not COD
			 */
			unset( $gateways['cod'] );
			reset( $gateways );
			$_POST['payment_method'] = key( $gateways );
		}

	}

	public function hide_rf_orders( $actions, $order ) {
		if ( $this->is_rf_order( $order ) ) {
			unset( $actions['pay'] );
		}
		return $actions;
	}

	public function after_calculate_total( $cart ) {
		$rf_advance = $this->apply_rf_cod_fees( $cart );
		if ( ! is_null( $rf_advance ) ) {
			$settings = $this->get_rf_settings();
			if ( ! isset( $settings['hide_additional_rf_description'] ) || $settings['hide_additional_rf_description'] !== 'yes' ) {
				$description = sprintf( __( '<strong>Pay %s online</strong> and %s with cash on delivery', 'wc-smart-cod' ), strip_tags( wc_price( $rf_advance ) ), strip_tags( wc_price( $this->remaining_amount ) ) );
				$this->maybe_set_custom_cod_description( $description, 'rf_fee' );
			}

			$rf_advance = apply_filters( 'wc_smart_cod_rf_fee', $rf_advance );

			if ( ! is_numeric( $rf_advance ) ) {
				return;
			}

			if ( is_string( $rf_advance ) ) {
				$rf_advance = floatval( $rf_advance );
			}

			$totals          = $cart->get_totals();
			$totals['total'] = $rf_advance;
			$cart->set_totals( $totals );
		}
	}

	public function is_rf_order( $order ) {
		return $order->get_meta( 'is_wsc_rf' ) === '1';
	}

	public function is_rf_cod() {
		return $this->is_enabled() && self::is_user_checked();
	}

	protected function should_hide_from_cart() {
		$settings = $this->get_extrafees_settings();
		return isset( $settings['hide_from_cart'] ) && $settings['hide_from_cart'] === 'yes';
	}

	protected function get_user_rf() {
		if ( ! $this->is_enabled() ) {
			return null;
		}
		$targets  = Wc_Smart_Cod_Risk_Free_Admin::$default_restriction_settings;
		$settings = $this->get_rf_settings();
		return $this->check_user_applies_rule( $settings, $targets );
	}

	protected function does_user_has_cod_available() {

		$cod_settings = $this->get_cod_settings();
		if ( ! isset( $cod_settings['restrictions_enabled'] ) || $cod_settings['restrictions_enabled'] !== 'yes' ) {
			return true;
		}

		$analyzed_settings = $this->analyze_settings( $cod_settings, true );
		return $this->determine_cod_availability( $analyzed_settings, null );

	}

	public function apply_smartcod_fees( WC_Cart $cart ) {

		if ( ! $this->does_user_has_cod_available() ) {
			return;
		}

		if ( ! $this->are_extrafees_enabled() ) {
			return;
		}

		$rf = $this->get_user_rf();

		if ( ! $this->is_cod_selected() ) {

			if ( ! $this->is_enabled() || ! self::is_user_checked() ) {
				return;
			}

			if ( ! $rf ) {
				/**
				 * Switch from a risk free COD
				 * to normal COD
				 */
				$_POST ['payment_method'] = 'cod';
				WC()->session->set( 'chosen_payment_method', 'cod' );
			}
		} else {
			if ( $rf ) {
				/**
				 * Switch from COD to risk free cod
				 * Start with unselected risk free
				 */
				$gateways = WC()->payment_gateways->get_available_payment_gateways();
				$gw       = null;

				foreach ( $gateways as $key => $value ) {
					if ( $key !== 'cod' ) {
						$gw = $key;
						break;
					}
				}

				if ( ! is_null( $gw ) ) {
					$_POST ['payment_method'] = $gw;
					WC()->session->set( 'chosen_payment_method', $gw );
					return;
				}
			}
		}

		if ( is_cart() && $this->should_hide_from_cart() ) {
			return;
		}

		if ( self::is_user_checked() ) {
			do_action( 'before_apply_smartcod_fees_rf' );
		} else {
			do_action( 'before_apply_smartcod_fees' );
		}

		$settings = $this->get_extrafees_settings();

		$fees = array();

		$multivendor = Wc_Smart_Cod_MultiVendors_Helper::get_instance();

		if ( $multivendor::has_wcfm()
			&& isset( $settings['wcfm_multifees_enabled'] )
			&& $settings['wcfm_multifees_enabled'] === 'yes' ) {
			$fees = $this->handle_vendor_fees( $settings );
		}

		if ( $multivendor::has_dokan() ) {
			$subcarts = $multivendor::break_cart_by_vendors( $cart, $fees, $settings );
			foreach ( $subcarts as $vendor_id => $vendor_data ) {
				$name        = apply_filters( 'wc_smart_cod_fee_title', __( 'Cash on delivery', 'woocommerce' ) );
				$vendor_name = $vendor_data['vendor_name'];
				$name       .= " - $vendor_name";

				WC()->session->set( 'cart_override', $vendor_data['total'] );

				$fee = $this->calculate_smartcod_fees( $vendor_data['total'] );

				WC()->session->set( 'cart_override', '' );

				$fees[] = array(
					'amount' => floatval( $fee ),
					'name'   => $name,
					'id'     => "wsc_extra_fee_$vendor_id",
				);
			}
		}

		if ( empty( $fees ) ) {
			$fees[] = array(
				'amount' => $this->calculate_smartcod_fees(),
				'name'   => apply_filters( 'wc_smart_cod_fee_title', __( 'Cash on delivery', 'woocommerce' ) ),
				'id'     => 'wsc_extra_fee',
			);
		}

		$total_fee = 0;

		foreach ( $fees as $fee_obj ) {

			$fee = apply_filters( 'wc_smart_cod_fee', $fee_obj );

			$amount = $fee['amount'];

			if ( ! is_null( $amount ) ) {

				if ( ! is_numeric( $amount ) ) {
					return;
				}

				if ( is_string( $amount ) ) {
					$amount = floatval( $amount );
				}

				$amount = parent::maybe_get_multicurrency_value( $amount );

				if ( $amount > 0 ) {
					$total_fee += $amount;
				}

				$fee['amount'] = $amount;

				$this->add_actual_fee( $cart, $fee );
			}
		}

		if ( $total_fee > 0 &&
		( ! isset( $settings['hide_additional_extrafee_description'] ) ||
		$settings['hide_additional_extrafee_description'] !== 'yes' ) ) {
			$description = sprintf( __( '<strong>Cash on delivery fee of %s</strong> has been added to order total amount', 'wc-smart-cod' ), strip_tags( wc_price( $total_fee ) ) );
			$this->maybe_set_custom_cod_description( $description, 'extra_fee' );
		}
	}

	private function handle_vendor_fees( $ef_settings, $key = 'wcfm_vendors_restriction' ) {
		$targets = Wc_Smart_Cod_Risk_Free_Admin::$default_restriction_settings;
		$rules   = $this->get_user_rules_map( $ef_settings, $targets, $key, false );
		$fees    = array();
		foreach ( $rules as $rule ) {
			$id     = $rule['id'];
			$fees[] = array(
				'amount' => $this->get_user_advance_amount( $rule['fee'], $rule['fee_type'], 'percentage_calculation' ),
				'name'   => $rule['name'],
				'id'     => "wsc_extra_fee_{$id}",
			);
		}
		return $fees;
	}

	public function apply_gateways_restriction( $gateways ) {

		if ( ! $this->disallowed_payment_gateways || empty( $this->disallowed_payment_gateways ) ) {
			return $gateways;
		}
		foreach ( $gateways as $key => $gateway ) {
			if ( in_array( $key, $this->disallowed_payment_gateways ) ) {
				unset( $gateways[ $key ] );
			}
		}
		return $gateways;
	}

	public function enrich_item_totals( $total_rows, $order_instance ) {

		$order_id = $order_instance->get_id();

		if ( ! $order_id ) {
			return $total_rows;
		}
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return $total_rows;
		}

		$is_wsc_rf = $order->get_meta( 'is_wsc_rf' );

		if ( ! $is_wsc_rf ) {
			return $total_rows;
		}

		$total_rows = $this->setup_additional_rows( $total_rows, $order );

		return $total_rows;
	}

	private function setup_additional_rows( $total_rows, $order ) {
		$cod_gateway     = self::get_cod_gateway();
		$full_total      = $order->get_meta( 'wsc_real_total' );
		$is_processed    = $order->get_meta( 'wsc_advance_order_id' );
		$advance_amount  = $order->get_meta( 'wsc_advance_total' );
		$remaining_total = wc_price( $order->get_meta( 'wsc_remaining_total' ) );

		if ( ! $is_processed ) {
			$total_rows['wsc_order_total'] = array(
				'label' => __( 'Advance amount', 'wc-smart-cod' ) . ':',
				'value' => wc_price( - $advance_amount ),
			);
		}

		$total_rows['full_total'] = array(
			'label' => __( 'Total', 'woocommerce' ) . ':',
			'value' => $this->get_formatted_order_real_total( $order, $full_total ),
		);

		$total_rows['wsc_payment_method'] = array(
			'label' => __( 'Advance payment method', 'wc-smart-cod' ) . ':',
			'value' => $total_rows['payment_method']['value'],
		);

		$total_rows['final_payment_method'] = array(
			'label' => __( 'Payment method:', 'woocommerce' ),
			'value' => $cod_gateway ? $cod_gateway->title : __( 'Cash on delivery', 'woocommerce' ),
		);

		$total_rows['remaining_total'] = array(
			'label' => esc_html__( 'Remaining amount to pay upon delivery', 'wc-smart-cod' ) . ':',
			'value' => '<strong>' . $remaining_total . '</strong>',
		);

		unset( $total_rows['order_total'] );
		unset( $total_rows['payment_method'] );

		$rf_ramount_id = $order->get_meta( 'wsc_rf_ramount_id' );
		if ( $rf_ramount_id && isset( $total_rows[ 'fee_' . $rf_ramount_id ] ) ) {
			unset( $total_rows[ 'fee_' . $rf_ramount_id ] );
		}

		return $total_rows;
	}

	private static function get_cod_gateway() {
		$payment_gateways = WC()->payment_gateways()->payment_gateways();
		return array_key_exists( 'cod', $payment_gateways ) ? $payment_gateways['cod'] : null;
	}

	public function thank_you_trigger( $order_id ) {

		$order = wc_get_order( $order_id );

		if ( ! $this->is_rf_order( $order ) ) {
			return;
		}

		$settings = $this->get_rf_settings();

		if ( isset( $settings['disable_additional_order'] ) && $settings['disable_additional_order'] === 'yes' ) {
			$order->calculate_totals();
			if ( !isset( $settings['use_advance_payment_method'] ) || $settings['use_advance_payment_method'] === 'no' ) {
				$order->set_payment_method('cod');
			}

			$order->save();
			return;
		}

		$connected_order_id = $order->get_meta( 'wsc_advance_order_id' );
		if ( $connected_order_id ) {
			// processed
			return;
		}

		$advance_amount = $order->get_total();

		/**
		 * Create risk free
		 * advance amount order
		 */
		$_order_id = $this->create_wc_order( $order, $advance_amount );

		/**
		 * Subtract the advance
		 */
		$item = new WC_Order_Item_Fee();
		$item->set_name( __( 'Advance amount', 'wc-smart-cod' ) );
		$item->set_total( - $advance_amount );
		$item->add_meta_data( 'is_wsc_advance_fee', true );
		$item->set_tax_status( 'none' );
		$item->set_tax_class( '' );
		$item->save();

		if ( class_exists( 'PaytabsHelper' ) ) {
			/**
			 * Remove the previously added
			 * negative Item Fee
			 */
			foreach ( $order->get_items( 'fee' ) as $item_id => $item_fee ) {
				if ( $item_fee->get_meta( 'is_wsc_rf_ramount' ) === '1' ) {
					$order->remove_item( $item_id );
					break;
				}
			}
		}

		$order->add_item( $item );
		$order->add_meta_data( 'wsc_advance_order_id', $_order_id );
		$order->set_payment_method( 'cod' );
		$order->calculate_totals( false );

		if ( isset( $settings['change_order_status'] ) && $settings['change_order_status'] !== '0' ) {
			$new_status = str_replace( 'wc-', '', $settings['change_order_status'] );
			$order->update_status( $new_status );
		}

		$order->save();
	}

	public function enrich_order_data( $order, $data ) {

		if ( ! $order ) {
			return;
		}

		if ( ! self::is_user_checked() ) {
			return;
		}

		$advance_amount = $order->get_total();
		$order->add_meta_data( 'is_wsc_rf', 1, true );
		$order->add_meta_data( 'wsc_real_total', $this->real_total );
		$order->add_meta_data( 'wsc_remaining_total', $this->remaining_amount );
		$order->add_meta_data( 'wsc_advance_total', $advance_amount );

		if ( class_exists( 'PaytabsHelper' ) ) {
			// paytabs need a different approach
			// due to their inner amount calculations

			if ( $order->get_meta( 'wsc_rf_ramount_id' ) ) {
				// already been there, abort
				return;
			}

			$item = new WC_Order_Item_Fee();
			$item->set_name( __( 'Remaining amount to pay upon delivery', 'wc-smart-cod' ) );
			$item->set_total( - $this->remaining_amount );
			$item->add_meta_data( 'is_wsc_rf_ramount', true );
			$item->set_tax_status( 'none' );
			$item->set_tax_class( '' );
			$item->save();

			$order->add_item( $item );
			$order->add_meta_data( 'wsc_rf_ramount_id', $item->get_id() );
			$order->calculate_totals( false );

			$order->save();
		}
	}

	public function add_real_total() {

		if ( $this->real_total ) {
			echo '<tr class="order-full-total wsc-rf-total">
				<th>' . esc_html__( 'Total', 'woocommerce' ) . '</th>
				<td>' . $this->get_formatted_real_total( $this->real_total ) . '</td>
			</tr>
			<tr class="wsc-rf-remaining">
				<th>' . apply_filters( 'wsc_remaining_amount_title', esc_html__( 'Remaining amount to pay upon delivery', 'wc-smart-cod' ) ) . '</th>
				<td><strong>' . wc_price( $this->remaining_amount ) . '</strong></td>
			</tr>';
		}

	}

	private function get_formatted_order_real_total( $order, $order_total ) {
		$formatted_total = wc_price( $order_total, array( 'currency' => $order->get_currency() ) );
		$total_refunded  = $order->get_total_refunded();
		$tax_string      = '';

		$tax_display = get_option( 'woocommerce_tax_display_cart' );

		// Tax for inclusive prices.
		if ( wc_tax_enabled() && 'incl' === $tax_display ) {
			$tax_string_array = array();
			$tax_totals       = $order->get_tax_totals();

			if ( 'itemized' === get_option( 'woocommerce_tax_total_display' ) ) {
				foreach ( $tax_totals as $code => $tax ) {
					$tax_amount         = ( $total_refunded && $display_refunded ) ? wc_price( WC_Tax::round( $tax->amount - $order->get_total_tax_refunded_by_rate_id( $tax->rate_id ) ), array( 'currency' => $order->get_currency() ) ) : $tax->formatted_amount;
					$tax_string_array[] = sprintf( '%s %s', $tax_amount, $tax->label );
				}
			} elseif ( ! empty( $tax_totals ) ) {
				$tax_amount         = ( $total_refunded && $display_refunded ) ? $order->get_total_tax() - $order->get_total_tax_refunded() : $order->get_total_tax();
				$tax_string_array[] = sprintf( '%s %s', wc_price( $tax_amount, array( 'currency' => $order->get_currency() ) ), WC()->countries->tax_or_vat() );
			}

			if ( ! empty( $tax_string_array ) ) {
				/* translators: %s: taxes */
				$tax_string = ' <small class="includes_tax">' . sprintf( __( '(includes %s)', 'woocommerce' ), implode( ', ', $tax_string_array ) ) . '</small>';
			}
		}

		if ( $total_refunded && $display_refunded ) {
			$formatted_total = '<del>' . wp_strip_all_tags( $formatted_total ) . '</del> <ins>' . wc_price( $order_total - $total_refunded, array( 'currency' => $order->get_currency() ) ) . $tax_string . '</ins>';
		} else {
			$formatted_total .= $tax_string;
		}

		return $formatted_total;

	}

	private function get_formatted_real_total( $total ) {
		$value = '<strong>' . wc_price( $total ) . '</strong> ';

		// If prices are tax inclusive, show taxes here.
		if ( wc_tax_enabled() && WC()->cart->display_prices_including_tax() ) {
			$tax_string_array = array();
			$cart_tax_totals  = WC()->cart->get_tax_totals();

			if ( get_option( 'woocommerce_tax_total_display' ) === 'itemized' ) {
				foreach ( $cart_tax_totals as $code => $tax ) {
					$tax_string_array[] = sprintf( '%s %s', $tax->formatted_amount, $tax->label );
				}
			} elseif ( ! empty( $cart_tax_totals ) ) {
				$tax_string_array[] = sprintf( '%s %s', wc_price( WC()->cart->get_taxes_total( true, true ) ), WC()->countries->tax_or_vat() );
			}

			if ( ! empty( $tax_string_array ) ) {
				$taxable_address = WC()->customer->get_taxable_address();
				/* translators: %s: country name */
				$estimated_text = WC()->customer->is_customer_outside_base() && ! WC()->customer->has_calculated_shipping() ? sprintf( ' ' . __( 'estimated for %s', 'woocommerce' ), WC()->countries->estimated_for_prefix( $taxable_address[0] ) . WC()->countries->countries[ $taxable_address[0] ] ) : '';
				$value         .= '<small class="includes_tax">('
						/* translators: includes tax information */
						. esc_html__( 'includes', 'woocommerce' )
						. ' '
						. wp_kses_post( implode( ', ', $tax_string_array ) )
						. esc_html( $estimated_text )
						. ')</small>';
			}
		}

		return $value;

	}

	public function apply_rf_cod_fees( WC_Cart $cart ) {

		if ( ! $this->is_enabled() || ! self::is_user_checked() ) {
			return null;
		}

		if ( ! $this->does_user_has_cod_available() ) {
			return null;
		}

		$rule = $this->get_user_rf();

		if ( ! $rule ) {
			return null;
		}

		$this->check_for_gateway_restriction( $rule );
		return $this->add_rf_total( $rule, $cart );

	}

	private function check_for_gateway_restriction( $rule ) {
		if ( isset( $rule['disallowed_payment_gateways'] ) && is_array( $rule['disallowed_payment_gateways'] ) && ! empty( $rule['disallowed_payment_gateways'] ) ) {
			$this->disallowed_payment_gateways = $rule['disallowed_payment_gateways'];
		}
	}

	private function add_rf_total( $rule, $cart ) {

		$total = $cart->get_totals()['total'];

		$user_advance_amount = $this->get_user_advance_amount( $rule['fee'], $rule['fee_type'], 'rf_percentage_calculation' );

		if ( ! $user_advance_amount || ! is_numeric( $user_advance_amount ) ) {
			return;
		}

		$remaining_amount = $total - $user_advance_amount;

		if ( $remaining_amount > 0 ) {
			$this->real_total       = $total;
			$this->remaining_amount = $remaining_amount;
			return $user_advance_amount;
		}

		return null;

	}

	public static function is_user_checked() {

		if ( isset( $_POST ['payment_method_cod_rf'] ) && is_string( $_POST ['payment_method_cod_rf'] ) ) {
			// process checkout flow
			return $_POST['payment_method_cod_rf'] === 'cod';
		}

		// update order-review flow

		if ( ! isset( $_POST['post_data'] ) ) {
			return false;
		}
		$post_data = wp_unslash( $_POST['post_data'] );
		parse_str( $post_data, $data );

		if ( ! isset( $data['payment_method_cod_rf'] ) || ! is_string( $data['payment_method_cod_rf'] ) ) {
			return false;
		}

		return $data['payment_method_cod_rf'] === 'cod';
	}

	private function is_enabled() {

		$settings = $this->get_rf_settings();
		$gateways = WC()->payment_gateways->get_available_payment_gateways();

		if ( count( $gateways ) <= 1 ) {
			return false;
		}

		return isset( $settings['enabled'] ) && $settings['enabled'] === 'yes' && isset( $settings['rules'] ) && ! empty( $settings['rules'] );
	}

	private function has_gateways_available( $rule ) {
		$gateways_available = $this->get_gateways_available( $rule );
		return count( $gateways_available ) > 1;
	}

	private function get_gateways_available( $rule ) {

		$gateways = WC()->payment_gateways->get_available_payment_gateways();

		if ( empty( $rule['disallowed_payment_gateways'] ) ) {
			return $gateways;
		}

		foreach ( $gateways as $key => $gateway ) {
			if ( in_array( $key, $rule['disallowed_payment_gateways'] ) ) {
				unset( $gateways[ $key ] );
			}
		}

		return $gateways;

	}

	public function change_fragments( $fragments ) {
		if ( ! $this->is_enabled() ) {
			return $fragments;
		}

		$settings = $this->get_rf_settings();
		$targets  = Wc_Smart_Cod_Risk_Free_Admin::$default_restriction_settings;
		$rule     = $this->check_user_applies_rule( null, $targets );

		if ( ! $rule ) {
			return $fragments;
		}

		if ( ! $this->has_gateways_available( $rule ) ) {
			return $fragments;
		}

		$target_key_payment      = '.woocommerce-checkout-payment';
		$target_key_order_review = '.woocommerce-checkout-review-order-table';

		if ( parent::has_checkout_wc() ) {
			// checkoutwc support
			$target_key_payment      = '#cfw-billing-methods';
			$target_key_order_review = '#cfw-totals-list';
		}

		$payment_fragment = isset( $fragments[ $target_key_payment ] ) ? $fragments[ $target_key_payment ] : null;
		$review_fragment  = isset( $fragments[ $target_key_order_review ] ) ? $fragments[ $target_key_order_review ] : null;

		if ( is_null( $payment_fragment ) ) {
			return $fragments;
		}

		$doc = new DOMDocument();
		@$doc->loadHTML( mb_convert_encoding( $payment_fragment, 'HTML-ENTITIES', 'UTF-8' ) );

		$cod_input = $doc->getElementById( 'payment_method_cod' );

		if ( ! $cod_input && class_exists( 'DOMXPath' ) ) {
			$x         = new DOMXPath( $doc );
			$cod_input = $x->query( "//*[@id='payment_method_cod']" )->item( 0 );
		}

		if ( ! $cod_input ) {
			return $fragments;
		}

		$cod_input->setAttribute( 'type', 'checkbox' );
		$cod_input->setAttribute( 'id', 'payment_method_cod_rf' );
		$cod_input->setAttribute( 'name', 'payment_method_cod_rf' );

		if ( self::is_user_checked() ) {
			$cod_input->setAttribute( 'checked', true );
		} else {
			$cod_input->removeAttribute( 'checked' );
		}

		$parent = $cod_input->parentNode;
		$label  = parent::has_checkout_wc() ? $parent : $parent->getElementsByTagName( 'label' )->item( 0 );

		if ( $label ) {
			$label->setAttribute( 'for', 'payment_method_cod_rf' );
		}

		if ( ! parent::has_checkout_wc() ) {
			$fragment = $doc->createDocumentFragment();
			$fragment->appendXML( '<span class="wsc_rf_cod_checkbox"></span>' );
			$first_element = $label->childNodes->item( 0 );
			$first_element->parentNode->insertBefore( $fragment, $first_element );
		}

		$classes = $parent->getAttribute( 'class' );
		$parent->setAttribute( 'class', $classes ? "$classes wsc_rf_cod" : 'wsc_rf_cod' );

		$doc->removeChild( $doc->doctype );
		$doc->replaceChild( $doc->firstChild->firstChild->firstChild, $doc->firstChild );
		$fragments[ $target_key_payment ] = $doc->saveHTML();

		/**
		 * Order review
		 */

		if ( parent::has_checkout_wc() && ! is_null( $review_fragment ) ) {
			// checkoutwc flow

			$fragments[ $target_key_order_review ] = $this->maybe_change_checkoutwc_fragment( $review_fragment );

		} elseif ( isset( $fragments['.woocommerce-checkout-review-order-table'] ) ) {
			// normal flow
			$fragments[ $target_key_order_review ] = $this->maybe_change_review_fragment( $review_fragment );

		} elseif ( isset( $fragments['.wfacp_order_summary'] ) ) {
			// aero checkout flow

			$fragments['.wfacp_order_summary'] = $this->maybe_change_review_fragment( $fragments['.wfacp_order_summary'] );

			$filtered_fragments = array_filter(
				$fragments,
				function ( $key ) {
					return strpos( $key, '_cart_total_details' ) !== false;
				},
				ARRAY_FILTER_USE_KEY
			);

			$filtered_fragments = array_merge( array_keys( $filtered_fragments ), array( '.wfacp_order_total' ) );
			foreach ( $filtered_fragments as $key ) {
				if ( isset( $fragments[ $key ] ) ) {
					if ( $key === '.wfacp_order_total' ) {
						$fragments[ $key ] = $this->maybe_change_aero_fragment( $fragments[ $key ] );
						break;
					}
					$fragments[ $key ] = $this->maybe_change_review_fragment( $fragments[ $key ] );
				}
			}
		}

		return $fragments;

	}

	private function maybe_change_aero_fragment( $fragment ) {
		if ( ! $this->real_total ) {
			return $fragment;
		}
		$doc = new DOMDocument();
		@$doc->loadHTML( mb_convert_encoding( $fragment, 'HTML-ENTITIES', 'UTF-8' ) );
		$tbody = $doc->getElementsByTagName( 'tbody' );
		if ( $tbody->length === 0 ) {
			return $fragment;
		}
		$tbody = $tbody->item( 0 );
		$tds   = $tbody->getElementsByTagName( 'td' );

		if ( $tds->length < 2 ) {
			return $fragment;
		}

		$tds->item( 0 )->nodeValue = apply_filters( 'wc_smart_cod_rf_fee_total_title', __( 'Advance payment', 'wc-smart-cod' ) );

		$small = $tds->item( 1 )->getElementsByTagName( 'small' );
		if ( $small->length > 0 ) {
			// remove included tax
			$small = $small->item( 0 );
			$small->parentNode->removeChild( $small );
		}

		$doc->removeChild( $doc->doctype );
		$doc->replaceChild( $doc->firstChild->firstChild->firstChild, $doc->firstChild );

		return $doc->saveHTML();
	}

	private function maybe_change_checkoutwc_fragment( $fragment ) {
		if ( ! $this->real_total ) {
			return $fragment;
		}

		$doc = new DOMDocument();
		@$doc->loadHTML( mb_convert_encoding( $fragment, 'HTML-ENTITIES', 'UTF-8' ) );

		$table = $doc->getElementsByTagName( 'table' );

		$tr_list  = $table->item( 0 )->getElementsByTagName( 'tr' );
		$total_tr = $tr_list->item( $tr_list->length - 1 );
		$classes  = $total_tr->getAttribute( 'class' );
		if ( strpos( $classes, 'order-total' ) === false ) {
			return $fragment;
		}
		$th = $total_tr->getElementsByTagName( 'th' );
		if ( $th->length === 0 ) {
			return $fragment;
		}
		$th->item( 0 )->nodeValue = apply_filters( 'wc_smart_cod_rf_fee_total_title', __( 'Advance payment', 'wc-smart-cod' ) );

		$small = $total_tr->getElementsByTagName( 'small' );
		if ( $small->length > 0 ) {
			// remove included tax
			$small = $small->item( 0 );
			$small->parentNode->removeChild( $small );
		}

		$doc->removeChild( $doc->doctype );
		$doc->replaceChild( $doc->firstChild->firstChild->firstChild, $doc->firstChild );
		return $doc->saveHTML();

	}

	private function maybe_change_review_fragment( $fragment ) {
		if ( ! $this->real_total ) {
			return $fragment;
		}

		$doc = new DOMDocument();
		@$doc->loadHTML( mb_convert_encoding( $fragment, 'HTML-ENTITIES', 'UTF-8' ) );
		$tfoot = $doc->getElementsByTagName( 'tfoot' );
		if ( $tfoot->length === 0 ) {
			return $fragment;
		}
		$tr_list  = $tfoot->item( 0 )->getElementsByTagName( 'tr' );
		$total_tr = $tr_list->item( $tr_list->length - 1 );
		$classes  = $total_tr->getAttribute( 'class' );
		if ( strpos( $classes, 'order-total' ) === false ) {
			return $fragment;
		}
		$th = $total_tr->getElementsByTagName( 'th' );
		if ( $th->length === 0 ) {
			return $fragment;
		}
		$th->item( 0 )->nodeValue = apply_filters( 'wc_smart_cod_rf_fee_total_title', __( 'Advance payment', 'wc-smart-cod' ) );

		$small = $total_tr->getElementsByTagName( 'small' );
		if ( $small->length > 0 ) {
			// remove included tax
			$small = $small->item( 0 );
			$small->parentNode->removeChild( $small );
		}

		$doc->removeChild( $doc->doctype );
		$doc->replaceChild( $doc->firstChild->firstChild->firstChild, $doc->firstChild );
		return $doc->saveHTML();
	}

	public function get_rf_settings() {
		if ( ! $this->rf_settings ) {
			$this->rf_settings = get_option( self::$option_name );
		}
		return $this->rf_settings;
	}

	private function get_checkbox_color_settings() {
		$_settings = $this->get_rf_settings();

		if ( ! isset( $_settings['checkbox_background_color'] ) || ! isset( $_settings['checkbox_checkmark_color'] ) || ! ! isset( $settings['checkbox_border_color'] ) ) {
			return null;
		}

		if ( ! $_settings['checkbox_background_color'] && ! $_settings['checkbox_checkmark_color'] && ! $_settings['checkbox_border_color'] ) {
			return null;
		}

		return array(
			'checkbox_background_color' => $_settings['checkbox_background_color'],
			'checkbox_checkmark_color'  => $_settings['checkbox_checkmark_color'],
			'checkbox_border_color'     => $_settings['checkbox_border_color'],
		);
	}

	private function get_rf_settings_js() {
		$_settings = $this->get_rf_settings();
		return array(
			'enabled' => isset( $_settings['enabled'] ) && $_settings['enabled'] === 'yes' && isset( $_settings['rules'] ) && ! empty( $_settings['rules'] ) ? 'yes' : 'no',
		);
	}

	protected function create_wc_order( $original_order, $advance_amount ) {
		$order = new WC_Order();

		$data = $original_order->get_data();

		$billing  = $data['billing'];
		$shipping = $data['shipping'];
		foreach ( $billing as $key => $value ) {
			if ( is_callable( array( $order, "set_billing_{$key}" ) ) ) {
				$order->{"set_billing_{$key}"}( $value );
			}
		}

		foreach ( $shipping as $key => $value ) {
			if ( is_callable( array( $order, "set_shipping_{$key}" ) ) ) {
				$order->{"set_shipping_{$key}"}( $value );
			}
		}

		$order->set_payment_method( $data['payment_method'] );
		$order->set_created_via( 'programatically' );
		$order->set_customer_id( get_current_user_id() );
		$order->set_currency( get_woocommerce_currency() );
		$order->set_prices_include_tax( 'yes' === get_option( 'woocommerce_prices_include_tax' ) );

		$item = new WC_Order_Item_Fee();
		$item->set_name( 'Advance amount for cash on delivery order' );
		$item->set_total( $advance_amount );
		$item->set_tax_class( '' );
		$item->set_tax_status( 'none' );
		$item->save();

		$order->add_item( $item );
		$order->calculate_totals( false );
		$order->add_meta_data( 'is_wsc_advance', 1 );
		if ( $original_order->is_paid() ) {
			$order->set_status( 'completed' );
		}
		$order_id = $order->save();

		// Returns the order ID
		return $order_id;
	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wc_Smart_Cod_Risk_Free_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wc_Smart_Cod_Risk_Free_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		if ( self::should_attach_scripts() ) {
			if ( $this->mode !== 'risk-free' ) {
				return;
			}
			$color_settings = $this->get_checkbox_color_settings();
			wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wc-smart-cod-risk-free-public.css', array(), $this->version, 'all' );
			if ( ! is_null( $color_settings ) ) {
				$additional_css = '';
				if ( $color_settings['checkbox_background_color'] ) {
					$bg_color        = sanitize_text_field( $color_settings['checkbox_background_color'] );
					$additional_css .= "
					span.wsc_rf_cod_checkbox {
						background-color: {$bg_color} !important;
					}";
				}
				if ( $color_settings['checkbox_checkmark_color'] ) {
					$checkmark_color = sanitize_text_field( $color_settings['checkbox_checkmark_color'] );
					$additional_css .= "
					span.wsc_rf_cod_checkbox:after {
						border-color: {$checkmark_color} !important;
					}";
				}
				if ( $color_settings['checkbox_border_color'] ) {
					$border_color    = sanitize_text_field( $color_settings['checkbox_border_color'] );
					$additional_css .= "
					span.wsc_rf_cod_checkbox {
						border-color: {$border_color} !important;
					}";
				}
				wp_add_inline_style( $this->plugin_name, $additional_css );
			}
		}

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wc_Smart_Cod_Risk_Free_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wc_Smart_Cod_Risk_Free_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		if ( self::should_attach_scripts() ) {
			if ( $this->mode !== 'risk-free' ) {
				return;
			}
			$settings = $this->get_rf_settings_js();
			wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wc-smart-cod-risk-free-public.min.js', array( 'jquery', 'wc-smart-cod-pro' ), $this->version, false );
			wp_localize_script( $this->plugin_name, 'wsc_rf', $settings );
		}
	}
}
