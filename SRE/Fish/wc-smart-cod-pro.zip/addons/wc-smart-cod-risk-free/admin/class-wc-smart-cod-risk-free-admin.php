<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://woosmartcod.com
 * @since      1.0.0
 *
 * @package    Wc_Smart_Cod_Risk_Free
 * @subpackage Wc_Smart_Cod_Risk_Free/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wc_Smart_Cod_Risk_Free
 * @subpackage Wc_Smart_Cod_Risk_Free/admin
 * @author     woosmartcod.com <info@woosmartcod.com>
 */
class Wc_Smart_Cod_Risk_Free_Admin extends Wc_Smart_Cod_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	protected $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */

	private $restriction_fields;

	public $mode;

	private $non_value_fields = array(
		'category_restriction_mode',
		'product_restriction_mode',
		'shipping_class_restriction_mode',
		'percentage_rounding',
		'weight_restriction_mode',
		'sku_product_restriction_mode',
		'dokan_vendors_restriction_mode',
	);

	private $targets = array(
		'cart_range_restriction',
		'shipping_method_restriction',
		'shipping_zone_restrictions',
		'country_restrictions',
		'state_restrictions',
		'restrict_postals',
		'city_restrictions',
		'user_role_restriction',
		'category_restriction_mode',
		'category_restriction',
		'product_restriction_mode',
		'product_restriction',
		'shipping_class_restriction_mode',
		'shipping_class_restriction',
		'shipping_zone_method_restriction',
		'user_restriction',
		'user_email_restriction',
		'user_phone_restriction',
		'stock_restriction',
		'weight_restriction_mode',
		'weight_restriction',
		'coupon_restriction',
		'product_qty_restriction',
		'backorders_restriction',
		'restriction_settings',
		'sku_product_restriction_mode',
		'sku_product_restriction',
		'wcfm_vendors_restriction',
		'invoice_restriction',
		'dokan_vendors_restriction_mode',
		'dokan_vendors_restriction',
	);

	public static $default_restriction_settings = array(
		'user_role_restriction'            => 1,
		'amount_restriction'               => 1,
		'shipping_zone_restrictions'       => 1,
		'shipping_zone_method_restriction' => 1,
		'country_restrictions'             => 1,
		'state_restrictions'               => 1,
		'restrict_postals'                 => 1,
		'city_restrictions'                => 1,
		'product_restriction'              => 1,
		'category_restriction'             => 1,
		'shipping_class_restriction'       => 1,
		'cart_range_restriction'           => 1,
		'user_restriction'                 => 1,
		'user_email_restriction'           => 1,
		'user_phone_restriction'           => 1,
		'stock_restriction'                => 1,
		'product_qty_restriction'          => 1,
		'weight_restriction'               => 1,
		'coupon_restriction'               => 1,
		'shipping_method_restriction'      => 1,
		'sku_product_restriction'          => 1,
		'wcfm_vendors_restriction'         => 1,
		'dokan_vendors_restriction'        => 1,
	);

	public function __construct( $plugin_name, $version, $mode = 'risk-free' ) {

		if ( self::get_current_addon() === 'restrictions' || ! is_admin() ) {
			return;
		}

		$this->mode             = $mode;
		$this->plugin_name      = $plugin_name;
		$this->version          = $version;
		$this->id               = $mode === 'risk-free' ? 'smartcod_riskfree' : 'smartcod_extrafees';
		$this->settings         = array();
		$this->init_settings();

		add_action( 'init', array( $this, 'initialize' ), 100, 1 );

		if ( $mode === 'risk-free' ) {
			add_action( 'wp_ajax_wsc_riskfree_restrictions', array( $this, 'wsc_riskfree_restrictions' ) );
			add_action( 'wp_ajax_wsc_save_restrictions', array( $this, 'wsc_save_restrictions' ) );
			add_filter( 'manage_edit-shop_order_columns', array( $this, 'hook_columns' ) );
			add_action( 'manage_shop_order_posts_custom_column', array( $this, 'populate_columns' ), 10, 2 );
			add_action( 'woocommerce_order_item_fee_after_calculate_taxes', array( $this, 'fix_wc_tax_bug' ), 10, 1 );
			// add_filter( 'woocommerce_reports_get_order_report_query', array( $this, 'enhance_reports' ) );
		} else {
			add_action( 'wp_ajax_wsc_extrafee_restrictions', array( $this, 'wsc_extrafee_restrictions' ) );
			add_action( 'wp_ajax_wsc_save_extrafee_restrictions', array( $this, 'wsc_save_extrafee_restrictions' ) );
		}
	}

	public function fix_wc_tax_bug( $item ) {
		if ( $item->get_meta( 'is_wsc_advance_fee' ) === '1' || $item->get_meta( 'is_wsc_advance_fee' ) === 1 ) {
			$item->set_taxes( false );
		}
	}

	public function wsc_extrafee_restrictions() {
		$this->wsc_riskfree_restrictions();
	}

	public function wsc_save_extrafee_restrictions() {

		$this->wsc_save_restrictions();
	}

	public function enhance_reports( $query ) {
		/**
		 * TODO: enhance reports
		 */
	}

	public function hook_columns( $columns ) {

		if ( ! $this->is_enabled() ) {
			return $columns;
		}

		$_columns = array();
		foreach ( $columns as $key => $column ) {
			$_columns[ $key ] = $column;
			if ( $key === 'order_status' ) {
				$_columns['wsc_rf'] = __( 'Risk free cod', 'wc-smart-cod' );
			}
		}
		return $_columns;
	}

	private function is_enabled() {

		$settings = $this->settings;

		return isset( $settings['enabled'] ) && $settings['enabled'] === 'yes' && isset( $settings['rules'] ) && ! empty( $settings['rules'] );
	}

	public function populate_columns( $column, $order_id ) {

		if ( ! $this->is_enabled() ) {
			return;
		}

		$order          = wc_get_order( $order_id );
		$is_wsc_rf      = $order->get_meta( 'is_wsc_rf' );
		$is_wsc_advance = $order->get_meta( 'is_wsc_advance' );
		if ( ! $is_wsc_rf && ! $is_wsc_advance ) {
			return;
		}

		if ( $column === 'wsc_rf' ) {
			if ( $is_wsc_rf ) {
				$advance    = $order->get_meta( 'wsc_advance_total' );
				$remaining  = $order->get_meta( 'wsc_remaining_total' );
				$real_total = $order->get_meta( 'wsc_real_total' );
				?>
				<table>
					<tbody>
						<tr>
							<th><?php _e( 'Advance Payment', 'wc-smart-cod' ); ?>:</th>
							<td><strong><?php echo wc_price( $advance ); ?></strong></td>
						</tr>
						<tr>
							<th><?php _e( 'Remaining amount to collect upon delivery', 'wc-smart-cod' ); ?>:</th>
							<td><strong><?php echo wc_price( $remaining ); ?></strong></td>
						</tr>
						<tr>
							<th><strong><?php _e( 'Total', 'wc-smart-cod' ); ?>:</strong></th>
							<td><strong><?php echo wc_price( $real_total ); ?></strong></td>
						</tr>
					</tbody>
				</table>
				<?php
			} else {
				$payment_method = $order->get_payment_method();
				_e( 'Advance Payment via', 'wc-smart-cod' );
				echo ' ' . esc_html( $payment_method );
			}
		}
	}

	public function initialize() {
		$this->form_fields = $this->get_settings();
	}

	private static function get_cod_gateway() {
		$payment_gateways = WC()->payment_gateways()->payment_gateways();
		return array_key_exists( 'cod', $payment_gateways ) ? $payment_gateways['cod'] : null;
	}

	private function extract_specific_fields( $fields ) {

		$targets = $this->targets;

		return array_map(
			function( $value ) {
				if ( $value ) {
					$value['external'] = true;
					if ( isset( $value['description'] ) ) {
						$value['description'] = str_replace( array( 'COD method', 'COD', 'cod restriction' ), array( 'rule', 'rule', 'rule restriction' ), $value['description'] );
					}
					if ( strpos( $value['title'], 'specific shipping methods of zones' ) !== false ) {
						$value['description'] = substr( $value['description'], 0, strpos( $value['description'], '<' ) );
					}
				}
				return $value;
			},
			array_filter(
				$fields,
				function( $key ) use ( $targets ) {
					return in_array( $key, $targets );
				},
				ARRAY_FILTER_USE_KEY
			)
		);
	}

	public function wsc_save_restrictions() {
		$_form_data = strip_tags( stripslashes( filter_input( INPUT_POST, 'formData' ) ) );
		parse_str( $_form_data, $form_data );
		$form_data = $this->sanitize_restriction_fields( $form_data );
		wp_die( ! is_null( $form_data ) ? wp_json_encode( $form_data ) : '' );
	}

	private function sanitize_restriction_fields( $post_data ) {
		$settings           = array();
		$restriction_fields = $this->get_restriction_fields();
		$has_changes        = false;
		foreach ( $restriction_fields as $key => $field ) {
			try {
				$value = $this->get_field_value( $key, $field, $post_data );
				if ( $value !== '' && ! in_array( $key, $this->non_value_fields ) ) {
					$has_changes = true;
				}
				$settings[ $key ] = $value;
			} catch ( Exception $e ) {
			}
		}
		return $has_changes ? $settings : null;
	}

	public function get_restriction_fields() {
		$cod_gateway = self::get_cod_gateway();
		if ( ! $cod_gateway ) {
			throw new Exception( 'COD is not enabled. Please revisit your settings' );
		}
		$native_options = array(
			'cart_range_restriction'      => array(
				'title'             => __( 'Enable for this cart range', 'wc-smart-cod' ),
				'type'              => 'range',
				'class'             => 'wc-smart-cod-group wc-smart-cod-restriction',
				'description'       => __( 'Add a price range to restrict the COD method, if the customer\'s cart amount is between this range.', 'wc-smart-cod' ),
				'placeholder'       => __( 'Enter Amount', 'wc-smart-cod' ),
				'custom_attributes' => array(
					'data-name' => 'cart_range_restriction',
				),
			),
			'shipping_method_restriction' => array(
				'title'             => __( 'Enable for shipping methods', 'woocommwc-smart-coderce' ),
				'type'              => 'multiselect',
				'class'             => 'wc-enhanced-select wc-smart-cod-group wc-smart-cod-restriction',
				'default'           => '',
				'description'       => __( 'Restrict the rule by shipping method. If you want to restrict by shipping method of zone, please head down to "Enable/Disable	 on specific shipping methods of zones" setting.' ),
				'options'           => $this->get_shipping_methods(),
				'custom_attributes' => array(
					'data-placeholder' => __( 'Select shipping methods', 'woocommerce' ),
					'data-name'        => 'shipping_method_restriction',
				),
			),
		);

		$current_rule = null;

		if ( $this->current_rule_id ) {
			$current_rule = self::get_rule_by_id( $this->current_rule_id, $this->settings );
		}

		$fields = $this->get_prepared_fields( $current_rule ? $current_rule['restrictions'] : array() );

		return array_merge( $native_options, $this->extract_specific_fields( $fields ) );
	}

	public function wsc_riskfree_restrictions() {

		$index     = isset( $_POST['index'] ) && is_numeric( $_POST['index'] ) ? $_POST['index'] : wp_die();
		$id        = isset( $_POST['id'] ) && is_numeric( $_POST['id'] ) ? $_POST['id'] : null;
		$edit_mode = ! is_null( $id );

		if ( $edit_mode ) {
			$this->current_rule_id = intval( $id );
		}

		$restriction_fields = $this->get_restriction_fields();

		$restriction_settings = $this->get_option( 'restriction_settings' );
		if ( ! $restriction_settings ) {
			$restriction_settings = self::$default_restriction_settings;
		} else {
			$restriction_settings = json_decode( $restriction_settings, true );
		}

		$restriction_fields = $this->analyze_fields( $restriction_fields, array(), $restriction_settings, false, false );
		ob_start();
		echo '<div class="woocommerce ' . Wc_Smart_Cod_Risk_Free::$shortname . '-restrictions">';
		echo '<form>';
		echo Wc_Smart_Cod_Admin::wrap_settings( $this->generate_settings_html( $restriction_fields, false ) );
		echo '</form>';
		echo '<div class="' . Wc_Smart_Cod_Risk_Free::$shortname . '-restrictions-cta">';
		echo '<button data-index="' . $index . '" data-name="save" class="button-primary woocommerce-save-button" type="submit" value="' . esc_attr( 'Save changes', 'woocommerce' ) . '">' . esc_html( 'Attach restrictions', 'woocommerce' ) . '</button>';
		echo '<p class="spinner"></p>';
		echo '</div>';
		echo '</div>';

		$html = ob_get_contents();
		ob_end_clean();
		wp_die(
			json_encode(
				array(
					'html'                 => $html,
					'restriction_settings' => $restriction_settings,
				)
			)
		);
	}

	protected static function get_prepared_order_statuses() {
		$statuses = wc_get_order_statuses();
		unset( $statuses['wc-failed'] );
		unset( $statuses['wc-cancelled'] );
		return array_merge( array( '0' => 'Select an order status' ), $statuses );
	}

	public function get_settings() {

		$fields = array();

		$percentage_rounding = array(
			'title'        => __( 'Percentage Rounding Settings', 'wc-smart-cod' ),
			'type'         => 'radio',
			'parent_class' => 'wc-smart-cod-field inline',
			'class'        => 'wc-smart-cod-group',
			'options'      => array(
				'no_round'   => __( 'No Rounding', 'wc-smart-cod' ),
				'round_up'   => __( 'Round Up', 'wc-smart-cod' ),
				'round_down' => __( 'Round Down', 'wc-smart-cod' ),
			),
			'default'      => 'no_round',
			'description'  => __( 'Examples: Round up setting will transform 5.345&euro; to 6&euro;<br />Round down will transform it to 5&euro;.', 'wc-smart-cod' ),
			'desc_tip'     => false,
		);

		$percentage_settings = array(
			'title'       => __( 'Percentage Calculation', 'wc-smart-cod' ),
			'type'        => 'checkboxes',
			'class'       => 'wc-smart-cod-group',
			'options'     => array(
				'tax'      => __( 'Taxes', 'wc-smart-cod' ),
				'shipping' => __( 'Shipping Costs', 'wc-smart-cod' ),
				'fees'     => __( 'Cart Fees', 'wc-smart-cod' ),
			),
			'default'     => array( 'tax', 'shipping', 'fees' ),
			'description' => __( 'This setting affects what is included in the cart total, in order to calculate any percentage fee', 'wc-smart-cod' ),
			'desc_tip'    => false,
		);

		if ( $this->mode === 'risk-free' ) {

			$fields['enabled'] = array(
				'title'    => __( 'Enable/Disable', 'wc-smart-cod' ),
				'label'    => __( 'Enable risk free', 'wc-smart-cod' ),
				'type'     => 'checkbox',
				'class'    => 'wc-smart-cod-group',
				'desc_tip' => false,
			);

			$fields['percentage_rounding'] = $percentage_rounding;
			$fields['percentage_settings'] = $percentage_settings;

			$fields['disable_additional_order'] = array(
				'title'       => __( 'Disable additional "advance" order', 'wc-smart-cod' ),
				'type'        => 'checkbox',
				'class'       => 'wc-smart-cod-group',
				'description' => __( 'Our plugin adds an additional "advance" order for risk free orders, to keep the amount calculations correct. Check this if you don\'t want this feature and you prefer one single order with the total order amount.', 'wc-smart-cod' ),
			);

			$fields['use_advance_payment_method'] = array(
				'title'       => __( 'Use "advance" order\'s payment method', 'wc-smart-cod' ),
				'type'        => 'checkbox',
				'class'       => 'wc-smart-cod-group',
				'description' => __( 'If you use only one order (you have the Disable additional "advance" order checked) and you want this one order to have the advance payment method instead of COD, then check this.', 'wc-smart-cod' ),
			);

			$fields['change_order_status'] = array(
				'title'       => __( 'Change order status', 'wc-smart-cod' ),
				'type'        => 'select',
				'options'     => self::get_prepared_order_statuses(),
				'class'       => 'wc-smart-cod-group',
				'default'     => '0',
				'description' => __( 'Change status of risk free orders after submit. Don\'t use this setting for default status', 'wc-smart-cod' ),
			);

			$fields['add_customer_advance_orders'] = array(
				'title'       => __( 'Show customer\'s advance orders', 'wc-smart-cod' ),
				'label'       => __( 'Show advance orders in customer\'s "my account"', 'wc-smart-cod' ),
				'type'        => 'checkbox',
				'class'       => 'wc-smart-cod-group',
				'description' => __( 'Our plugin adds an additional "advance" order for risk free orders, to keep the amount calculations correct. Check this if you don\'t want your customers to see the extra "advance order", on "my account" page', 'wc-smart-cod' ),
			);

			$fields['add_customer_advance_order_email'] = array(
				'title'       => __( 'Enable customer\'s advance order email', 'wc-smart-cod' ),
				'label'       => __( 'Enable customer\'s "advance order" email', 'wc-smart-cod' ),
				'type'        => 'checkbox',
				'class'       => 'wc-smart-cod-group',
				'description' => __( 'Our plugin adds an additional "advance" order for risk free orders, to keep the amount calculations correct. Check this if you want your customers to get a "Completed order" email for the extra "advance order"', 'wc-smart-cod' ),
			);

			$fields['add_customer_advance_order_api'] = array(
				'title'       => __( 'Add customer\'s advance order to REST API', 'wc-smart-cod' ),
				'label'       => __( 'Add customer\'s "advance order" to REST API', 'wc-smart-cod' ),
				'type'        => 'checkbox',
				'class'       => 'wc-smart-cod-group',
				'description' => __( 'Our plugin adds an additional "advance" order for risk free orders, to keep the amount calculations correct. Check this if you want this "advance orders" to be included in WooCommerce REST API calls', 'wc-smart-cod' ),
			);

			$fields['hide_additional_rf_description'] = array(
				'title'       => __( 'Hide risk free details', 'wc-smart-cod' ),
				'label'       => __( 'Hide risk free details from payment description', 'wc-smart-cod' ),
				'type'        => 'checkbox',
				'class'       => 'wc-smart-cod-group',
				'description' => __( 'Our plugin adds the details of the risk free transaction on the payment gateway description box. Check this if you want to hide it.', 'wc-smart-cod' ),
			);

			$fields['checkbox_background_color'] = array(
				'title'       => __( 'Checkbox background color', 'wc-smart-cod' ),
				'type'        => 'color',
				'class'       => 'wc-smart-cod-group',
				'description' => __( 'Background color of risk free checkbox', 'wc-smart-cod' ),
			);

			$fields['checkbox_checkmark_color'] = array(
				'title'       => __( 'Checkbox check mark color', 'wc-smart-cod' ),
				'type'        => 'color',
				'class'       => 'wc-smart-cod-group',
				'description' => __( 'Check mark color of risk free checkbox', 'wc-smart-cod' ),
			);

			$fields['checkbox_border_color'] = array(
				'title'       => __( 'Checkbox border color', 'wc-smart-cod' ),
				'type'        => 'color',
				'class'       => 'wc-smart-cod-group',
				'description' => __( 'Border color of risk free checkbox', 'wc-smart-cod' ),
			);

			$fields['rules'] = array(
				'type'     => 'riskfree',
				'class'    => 'wc-smart-cod-group',
				'desc_tip' => false,
			);

		} else {

			$fields['enabled'] = array(
				'title'    => __( 'Enable/Disable', 'wc-smart-cod' ),
				'label'    => __( 'Enable extra fees', 'wc-smart-cod' ),
				'type'     => 'checkbox',
				'class'    => 'wc-smart-cod-group',
				'desc_tip' => false,
			);

			$fields['percentage_rounding'] = $percentage_rounding;
			$fields['percentage_settings'] = $percentage_settings;

			$fields['extra_fee_tax'] = array(
				'title'        => __( 'Extra Fee Tax', 'wc-smart-cod' ),
				'type'         => 'radio',
				'parent_class' => 'wc-smart-cod-field inline',
				'class'        => 'wc-smart-cod-group',
				'options'      => array(
					'enable'  => __( 'Enable', 'wc-smart-cod' ),
					'disable' => __( 'Disable', 'wc-smart-cod' ),
				),
				'default'      => 'disable',
				'description'  => __( 'Is extra fee taxable? Use this option if you have taxes enabled in your shop and you want to include tax to COD method.', 'wc-smart-cod' ),
				'desc_tip'     => false,
			);

			$fields['hide_from_cart'] = array(
				'title'    => __( 'Cart page', 'wc-smart-cod' ),
				'label'    => __( 'Don\'t show fee on cart page', 'wc-smart-cod' ),
				'type'     => 'checkbox',
				'class'    => 'wc-smart-cod-group',
				'desc_tip' => false,
			);

			$fields['hide_additional_extrafee_description'] = array(
				'title'       => __( 'Hide extra fee details', 'wc-smart-cod' ),
				'label'       => __( 'Hide extra fee details from payment description', 'wc-smart-cod' ),
				'type'        => 'checkbox',
				'class'       => 'wc-smart-cod-group',
				'description' => __( 'Our plugin adds the details of the extra fee on the payment gateway description box. Check this if you want to hide it.', 'wc-smart-cod' ),
			);

			if ( class_exists( 'WCFM_Vendor_Support' ) ) {
				$fields['wcfm_multifees_enabled'] = array(
					'title'    => __( 'Enable WCFM multiple fees', 'wc-smart-cod' ),
					'type'     => 'checkbox',
					'class'    => 'wc-smart-cod-group',
					'desc_tip' => false,
				);
			}

			$fields['rules'] = array(
				'type'     => 'extrafees',
				'class'    => 'wc-smart-cod-group',
				'desc_tip' => false,
			);

		}

		return $fields;

	}

	public function validate_riskfree_field( $key, $value ) {
		if ( ! $value ) {
			return;
		}
		foreach ( $value as $index => $row ) {
			$should_unset = false;
			$rule_index   = $index + 1;

			foreach ( $row as $_key => $_value ) {
				switch ( $_key ) {
					case 'name': {
						$value[ $index ][ $_key ] = $this->validate_text_field( $_key, $_value );
						if ( $value[ $index ][ $_key ] === '' ) {
							WC_Admin_Settings::add_error( "Rule($rule_index): $_key is required" );
							$should_unset = true;
						}
						break;
					}
					case 'fee': {
						$value[ $index ][ $_key ] = $this->validate_price_field( $_key, $_value );
						if ( $value[ $index ][ $_key ] === '' ) {
							WC_Admin_Settings::add_error( "Rule($rule_index): $_key is required" );
							$should_unset = true;
						}
						break;
					}
					case 'fee_type': {
						$value[ $index ][ $_key ] = $this->validate_select_field( $_key, $_value );
						break;
					}
					case 'active': {
						$value[ $index ][ $_key ] = $this->validate_toggle_field( $_key, $_value );
						break;
					}
					case 'restrictions': {
						$value[ $index ][ $_key ] = $this->validate_restrictions_field( $_key, $_value );
						break;
					}
				}
			}

			if ( $should_unset ) {
				unset( $value[ $index ] );
			} else {
				$value[ $index ]['id'] = $rule_index;
			}
		}

		return $value;

	}

	public function validate_extrafees_field( $key, $value ) {
		return $this->validate_riskfree_field( $key, $value );
	}

	public function validate_restrictions_field( $key, $value ) {

		try {
			$restriction_fields = $this->get_restriction_fields();
			$validated_fields   = array();

			$_decoded = json_decode( stripslashes( $value ), true );
			if ( $_decoded && is_array( $_decoded ) ) {
				foreach ( $_decoded as $_key => $_value ) {
					$field = array_key_exists( $_key, $restriction_fields ) ? $restriction_fields[ $_key ] : null;
					if ( ! $field ) {
						continue;
					}
					if ( $field['type'] === 'hidden' ) {
						/** TODO: check for json settings */
						$validated_fields[ $_key ] = $this->validate_text_field( $_key, $_value );
						continue;
					}

					if ( ! method_exists( $this, 'validate_' . $field['type'] . '_field' ) ) {
						continue;
					}
					$validated_fields[ $_key ] = $this->{ 'validate_' . $field['type'] . '_field' }( $_key, $_value );
				}
			}

			if ( empty( $validated_fields ) ) {
				return null;
			}

			return $validated_fields;

		} catch ( Exception $e ) {
			return null;
		}

	}

	public function save_callback() {

		$this->init_settings();

		$post_data = $this->get_post_data();

		foreach ( $this->get_form_fields() as $key => $field ) {
			if ( 'title' !== $this->get_field_type( $field ) ) {
				try {
					$value = $this->get_field_value( $key, $field, $post_data );
					if ( $key === 'rules' ) {
						$value = is_array( $value ) ? array_values( $value ) : array();
					}
					$this->settings[ $key ] = $value;
				} catch ( Exception $e ) {
					WC_Admin_Settings::add_error( $e->getMessage() );
				}
			}
		}

		return update_option( $this->get_option_key(), $this->settings, 'yes' );
	}

	public function generate_settings() {
		$a = $this->__a();
		if ( $a ) {
			foreach ( $this->form_fields as $key => $field ) {
				$this->form_fields[ $key ][ $this->get_kk() ] = $a;
			}
		}

		return Wc_Smart_Cod_Admin::wrap_settings( $this->generate_settings_html( $this->form_fields, false ) );
	}

	public function get_settings_by_action() {
		if ( ! isset( $_POST['action'] ) ) {
			return;
		}
		switch ( $_POST['action'] ) {
			case 'wsc_extrafee_restrictions':{
				return get_option( 'woocommerce_smartcod_extrafees_settings', null );
			}
			case 'wsc_riskfree_restrictions': {
				return get_option( 'woocommerce_smartcod_riskfree_settings', null );
			}
		}
	}

	public static function get_rule_by_id( $rule_id, $settings = null ) {

		if ( is_null( $settings ) ) {
			$settings = get_option( 'woocommerce_smartcod_riskfree_settings' );
		}

		if ( is_string( $rule_id ) ) {
			$rule_id = intval( $rule_id );
		}

		$current_rule = array_filter(
			$settings['rules'],
			function( $rule ) use ( $rule_id ) {
				return $rule['id'] === $rule_id;
			}
		);

		if ( empty( $current_rule ) ) {
			return null;
		}

		return reset( $current_rule );
	}

	public static function update_rule_restrictions( $rule_id, $key, $value ) {

		$rule = self::get_rule_by_id( $rule_id );
		if ( is_null( $rule ) ) {
			return;
		}

		$rule['restrictions'][ $key ] = $value;
		$rule_index                   = self::get_rule_index_by_id( $rule_id );

		if ( $rule_index === -1 ) {
			return;
		}

		$settings = get_option( 'woocommerce_smartcod_riskfree_settings' );
		if ( ! $settings || empty( $settings['rules'] ) || ! isset( $settings['rules'][ $rule_index ] ) ) {
			return;
		}

		$settings['rules'][ $rule_index ] = $rule;
		update_option( 'woocommerce_smartcod_riskfree_settings', $settings );

	}

	public static function get_rule_index_by_id( $rule_id ) {
		$settings = get_option( 'woocommerce_smartcod_riskfree_settings' );
		if ( ! $settings ) {
			return -1;
		}
		if ( empty( $settings['rules'] ) ) {
			return -1;
		}

		if ( is_string( $rule_id ) ) {
			$rule_id = intval( $rule_id );
		}

		foreach ( $settings['rules'] as $index => $rule ) {
			if ( $rule['id'] === $rule_id ) {
				return $index;
			}
		}
		return -1;
	}

	public function get_option( $key, $empty_value = null ) {
		if ( $this->current_rule_id && in_array( $key, $this->targets ) ) {
			$this->settings  = $this->get_settings_by_action();
			$rules           = $this->settings['rules'];
			$current_rule_id = $this->current_rule_id;
			$current_rule    = self::get_rule_by_id( $current_rule_id, $this->settings );

			if ( is_null( $current_rule ) ) {
				return '';
			}

			if ( ! $current_rule['restrictions'] ) {
				return '';
			}

			$restrictions = $current_rule['restrictions'];

			$unsaved_value = $this->get_unsaved_value();

			if ( $unsaved_value && isset( $unsaved_value[ $key ] ) ) {
				$restrictions[ $key ] = $unsaved_value[ $key ];
			}

			if ( ! isset( $restrictions[ $key ] ) ) {
				return '';
			}

			if ( $key === 'restriction_settings' && $restrictions[ $key ] === '' ) {
				$restrictions[ $key ] = json_encode( self::$default_restriction_settings );
			}

			return $restrictions[ $key ];
		}

		if ( preg_match( '/rules\[(?<index>\d+)\]\[(?<subkey>\w+)\]/', $key, $matches ) ) {
			$rules = $this->settings['rules'];
			if ( ! $rules || ! is_array( $rules ) ) {
				return '';
			}

			$index  = $matches['index'];
			$subkey = $matches['subkey'];

			if ( ! array_key_exists( $index, $rules ) ) {
				return '';
			}
			$rule = $rules[ $index ];

			if ( ! array_key_exists( $subkey, $rule ) ) {
				return '';
			}

			return $rule[ $subkey ];
		}
		return parent::get_option( $key, $empty_value );
	}

	private function get_unsaved_value() {
		if ( ! isset( $_POST['unsaved_data'] ) ) {
			return null;
		}
		return json_decode( stripslashes( $_POST['unsaved_data'] ), true );
	}

	protected function payment_gateways_multiselect_options() {

		$payment_gateways = WC()->payment_gateways->payment_gateways();

		foreach ( WC()->payment_gateways->payment_gateways() as $key => $gw ) {
			if ( $key === 'cod' ) {
				continue;
			}
			$options[ $key ] = $gw->title;
		}
		return $options;
	}

	public function generate_extrafees_html( $key, $data ) {
		$field_key = $this->get_field_key( $key );

		$defaults = array(
			'title'             => '',
			'disabled'          => false,
			'class'             => '',
			'css'               => '',
			'placeholder'       => '',
			'type'              => 'text',
			'desc_tip'          => false,
			'description'       => '',
			'custom_attributes' => array(),
			'options'           => array(),
			'parent_class'      => '',
			'default'           => '',
		);

		$data  = wp_parse_args( $data, $defaults );
		$value = $this->get_option( $key );

		$skeleton = array(
			array(
				'name'        => '',
				'fee'         => '',
				'fee_type'    => 'fixed',
				'active'      => '',
				'is_skeleton' => true,
			),
		);

		$shortname = Wc_Smart_Cod_Risk_Free::$shortname;

		if ( ! $value ) {
			$value = array();
		}

		$value = array_merge( $value, $skeleton );

		$gw_options = $this->payment_gateways_multiselect_options();

		ob_start();
		?>
		<tr valign="top" class="wsc-riskfree-wrapper">
			<th scope="row" class="titledesc">
			</th>
			<td class="forminp forminp-<?php echo sanitize_title( $data['type'] ); ?><?php echo $data['parent_class'] ? ' ' . esc_attr( $data['parent_class'] ) : ''; ?>">
				<fieldset class="<?php echo $shortname; ?>-fieldset">
					<table class="wp-list-table widefat fixed striped">
						<thead>
							<th class="<?php echo $shortname . '-th-toggle'; ?>">
								<input class="<?php echo $shortname; ?>-toggle-all" type="checkbox" name="all" />
							</th>
							<th></th>
							<th class="<?php echo $shortname . '-th-name'; ?>">
							<?php _e( 'Rule name', 'wc-smart-cod' ); ?>
							</th>
							<th class="<?php echo $shortname . '-th-fee'; ?>">
							<?php _e( 'Extra fee amount', 'wc-smart-cod' ); ?>
							</th>
							<th class="<?php echo $shortname . '-th-fee-type'; ?>">
							<?php _e( 'Extra fee type', 'wc-smart-cod' ); ?>
							</th>
							<th class="<?php echo $shortname . '-th-active'; ?>">
							<?php _e( 'Active', 'wc-smart-cod' ); ?>
							</th>
							<th class="<?php echo $shortname . '-th-restrictions'; ?>">
							<?php _e( 'Restrict rule', 'wc-smart-cod' ); ?>
							</th>
							<th class="<?php echo $shortname . '-th-actions'; ?>">
							<?php _e( 'Actions', 'wc-smart-cod' ); ?>
							</th>
						</thead>
						<tbody class="<?php echo $shortname; ?>-main-body ui-sortable">
						<?php
						$i = 0;
						foreach ( $value as $index => $row ) :
							$is_skeleton = array_key_exists( 'is_skeleton', $row ) && $row['is_skeleton'] === true;
							if ( ! $is_skeleton ) {
								$i++;
							}
							$id = ! $is_skeleton ? esc_attr( $row['id'] ) : null;
							?>
							<tr class="
							<?php
							echo $shortname;
							echo $is_skeleton ? " $shortname-skeleton unsortable" : '';
							?>
							" <?php echo ! is_null( $id ) ? "data-id='$id'" : ''; ?><?php echo ! $is_skeleton ? "data-index='$i'" : ''; ?>>
								<td class="<?php echo $shortname; ?>-selected-wrapper"><input type="checkbox" class="<?php echo $shortname; ?>-selected<?php echo $is_skeleton ? ' skeleton' : ''; ?>" name="<?php echo $key . "[$index][selected]"; ?>" />
								<td class="sort">
									<div class="wc-item-reorder-nav"></div>
								</td>
								<td data-colname="<?php _e( 'Rule name', 'wc-smart-cod' ); ?>">
									<?php
									echo self::get_td(
										$this->generate_text_html(
											$key . "[$index][name]",
											array(
												'disabled' => $is_skeleton || $data['disabled'],
												'class'    => 'rule-name',
											)
										)
									);
									?>
								</td>
								<td data-colname="<?php _e( 'Advance fee amount', 'wc-smart-cod' ); ?>">
									<?php
									echo self::get_td(
										$this->generate_price_html(
											$key . "[$index][fee]",
											array(
												'disabled' => $is_skeleton || $data['disabled'],
												'class'    => 'rule-fee',
											)
										)
									);
									?>
								</td>
								<td data-colname="<?php _e( 'Advance fee type', 'wc-smart-cod' ); ?>">
									<?php
									echo self::get_td(
										$this->generate_select_html(
											$key . "[$index][fee_type]",
											array(
												'options'  => array(
													'fixed' => 'Fixed',
													'percentage' => '%',
												),
												'disabled' => $is_skeleton || $data['disabled'],
												'required' => true,
											)
										)
									);
									?>
								</td>
								<td data-colname="<?php _e( 'Active', 'wc-smart-cod' ); ?>">
									<?php
										echo self::get_td(
											$this->generate_toggle_html(
												$key . "[$index][active]",
												array(
													'disabled' => $is_skeleton || $data['disabled'],
													'default' => 1,
												)
											)
										);
									?>
								</td>
								<td data-colname="<?php _e( 'Restrict rule', 'wc-smart-cod' ); ?>" class="<?php echo $shortname; ?>-restrictions-wrap">
									<fieldset>
										<button type="button" class="button button-secondary wsc-riskfree-restriction" <?php disabled( $data['disabled'], true ); ?>>
											<i class="dashicons dashicons-edit"></i>
										</button>
										<?php
											echo self::get_td(
												$this->generate_json_html(
													$key . "[$index][restrictions]",
													array(
														'disabled' => $is_skeleton || $data['disabled'],
													)
												)
											);
										?>
									</fieldset>
								</td>
								<td data-colname="<?php _e( 'Actions', 'wc-smart-cod' ); ?>">
									<button type="button" class="button button-secondary wsc-riskfree-delete" <?php disabled( $data['disabled'], true ); ?>>
										<i class="dashicons dashicons-trash"></i>
									</button>
								</td>
							</tr>
							<?php endforeach; ?>
							<tr class="<?php echo $shortname; ?>-prompt-user unsortable">
								<td colspan="8" style="text-align: center">
									<div class="bulk-actions hidden">
										<button type="button" title="Bulk delete rules" class="bulk-delete button button-secondary" <?php disabled( $data['disabled'], true ); ?>>
											<i class="dashicons dashicons-trash"></i>
											Bulk delete<span></span>rules
										</button>
									</div>
									<button type="button" class="button button-primary add-new" <?php disabled( $data['disabled'], true ); ?>>
										<i class="dashicons dashicons-plus-alt"></i>
										<span><?php _e( 'Add new rule', 'wc-smart-cod' ); ?></span>
									</button>
								</td>
							</tr>
						</tbody>
					</table>
						<?php echo $this->get_description_html( $data ); ?>
				</fieldset>
			</td>
		</tr>
			<?php
			return ob_get_clean();
	}

	public function generate_riskfree_html( $key, $data ) {

		$field_key = $this->get_field_key( $key );

		$defaults = array(
			'title'             => '',
			'disabled'          => false,
			'class'             => '',
			'css'               => '',
			'placeholder'       => '',
			'type'              => 'text',
			'desc_tip'          => false,
			'description'       => '',
			'custom_attributes' => array(),
			'options'           => array(),
			'parent_class'      => '',
			'default'           => '',
		);

		$data  = wp_parse_args( $data, $defaults );
		$value = $this->get_option( $key );

		$skeleton = array(
			array(
				'name'        => '',
				'fee'         => '',
				'fee_type'    => 'fixed',
				'active'      => '',
				'is_skeleton' => true,
			),
		);

		$shortname = Wc_Smart_Cod_Risk_Free::$shortname;

		if ( ! $value ) {
			$value = array();
		}

		$value = array_merge( $value, $skeleton );

		$gw_options = $this->payment_gateways_multiselect_options();

		ob_start();
		?>
		<tr valign="top" class="wsc-riskfree-wrapper">
			<th scope="row" class="titledesc">
			</th>
			<td class="forminp forminp-<?php echo sanitize_title( $data['type'] ); ?><?php echo $data['parent_class'] ? ' ' . esc_attr( $data['parent_class'] ) : ''; ?>">
				<fieldset class="<?php echo $shortname; ?>-fieldset">
					<table class="wp-list-table widefat fixed striped">
						<thead>
							<th class="<?php echo $shortname . '-th-toggle'; ?>">
								<input class="<?php echo $shortname; ?>-toggle-all" type="checkbox" name="all" />
							</th>
							<th></th>
							<th class="<?php echo $shortname . '-th-id'; ?>">
							<?php _e( 'Rule ID', 'wc-smart-cod' ); ?>
							</th>
							<th class="<?php echo $shortname . '-th-name'; ?>">
							<?php _e( 'Rule name', 'wc-smart-cod' ); ?>
							</th>
							<th class="<?php echo $shortname . '-th-fee'; ?>">
							<?php _e( 'Advance fee amount', 'wc-smart-cod' ); ?>
							</th>
							<th class="<?php echo $shortname . '-th-fee-type'; ?>">
							<?php _e( 'Advance fee type', 'wc-smart-cod' ); ?>
							</th>
							<th class="<?php echo $shortname . '-th-active'; ?>">
							<?php _e( 'Active', 'wc-smart-cod' ); ?>
							</th>
							<th class="<?php echo $shortname . '-th-gateways'; ?>">
							<?php _e( 'Disallowed payment gateways', 'wc-smart-cod' ); ?>
							</th>
							<th class="<?php echo $shortname . '-th-restrictions'; ?>">
							<?php _e( 'Restrict rule', 'wc-smart-cod' ); ?>
							</th>
							<th class="<?php echo $shortname . '-th-actions'; ?>">
							<?php _e( 'Actions', 'wc-smart-cod' ); ?>
							</th>
						</thead>
						<tbody class="<?php echo $shortname; ?>-main-body ui-sortable">
						<?php
						$i = 0;
						foreach ( $value as $index => $row ) :
							$is_skeleton = array_key_exists( 'is_skeleton', $row ) && $row['is_skeleton'] === true;
							if ( ! $is_skeleton ) {
								$i++;
							}
							$id = ! $is_skeleton ? esc_attr( $row['id'] ) : null;
							?>
							<tr class="
							<?php
							echo $shortname;
							echo $is_skeleton ? " $shortname-skeleton unsortable" : '';
							?>
							" <?php echo ! is_null( $id ) ? "data-id='$id'" : ''; ?><?php echo ! $is_skeleton ? "data-index='$i'" : ''; ?>>
								<td class="<?php echo $shortname; ?>-selected-wrapper"><input type="checkbox" class="<?php echo $shortname; ?>-selected<?php echo $is_skeleton ? ' skeleton' : ''; ?>" name="<?php echo $key . "[$index][selected]"; ?>" />
								<td class="sort">
									<div class="wc-item-reorder-nav"></div>
								</td>
								<td><?php echo ! is_null( $id ) ? $id : '-'; ?></td>
								<td data-colname="<?php _e( 'Rule name', 'wc-smart-cod' ); ?>">
									<?php
									echo self::get_td(
										$this->generate_text_html(
											$key . "[$index][name]",
											array(
												'disabled' => $is_skeleton || $data['disabled'],
												'class'    => 'rule-name',
											)
										)
									);
									?>
								</td>
								<td data-colname="<?php _e( 'Advance fee', 'wc-smart-cod' ); ?>">
									<?php
									echo self::get_td(
										$this->generate_price_html(
											$key . "[$index][fee]",
											array(
												'disabled' => $is_skeleton || $data['disabled'],
												'class'    => 'rule-fee',
											)
										)
									);
									?>
								</td>
								<td data-colname="<?php _e( 'Advance fee type', 'wc-smart-cod' ); ?>">
									<?php
									echo self::get_td(
										$this->generate_select_html(
											$key . "[$index][fee_type]",
											array(
												'options'  => array(
													'fixed' => 'Fixed',
													'percentage' => '%',
												),
												'disabled' => $is_skeleton || $data['disabled'],
												'required' => true,
											)
										)
									);
									?>
								</td>
								<td data-colname="<?php _e( 'Active', 'wc-smart-cod' ); ?>">
									<?php
										echo self::get_td(
											$this->generate_toggle_html(
												$key . "[$index][active]",
												array(
													'disabled' => $is_skeleton || $data['disabled'],
													'default' => 1,
												)
											)
										);
									?>
								</td>
								<td data-colname="<?php _e( 'Disallowed payment gateways', 'wc-smart-cod' ); ?>">
								<?php
									echo self::get_td(
										$this->generate_multiselect_html(
											$key . "[$index][disallowed_payment_gateways]",
											array(
												'type'     => 'multiselect',
												'options'  => $gw_options,
												'class'    => 'wc-enhanced-select',
												'disabled' => $is_skeleton || $data['disabled'],
												'custom_attributes' => array(
													'data-placeholder' => __( 'Select payment gateways', 'wc-smart-cod' ),
												),
											)
										)
									);
								?>
								</td>
								<td data-colname="<?php _e( 'Restrict rule', 'wc-smart-cod' ); ?>" class="<?php echo $shortname; ?>-restrictions-wrap">
									<fieldset>
										<button type="button" class="button button-secondary wsc-riskfree-restriction" <?php disabled( $data['disabled'], true ); ?>>
											<i class="dashicons dashicons-edit"></i>
										</button>
										<?php
											echo self::get_td(
												$this->generate_json_html(
													$key . "[$index][restrictions]",
													array(
														'disabled' => $is_skeleton || $data['disabled'],
													)
												)
											);
										?>
									</fieldset>
								</td>
								<td data-colname="<?php _e( 'Actions', 'wc-smart-cod' ); ?>">
									<button type="button" class="button button-secondary wsc-riskfree-delete" <?php disabled( $data['disabled'], true ); ?>>
										<i class="dashicons dashicons-trash"></i>
									</button>
								</td>
							</tr>
							<?php endforeach; ?>
							<tr class="<?php echo $shortname; ?>-prompt-user unsortable">
								<td colspan="10" style="text-align: center">
									<div class="bulk-actions hidden">
										<button type="button" title="Bulk delete rules" class="bulk-delete button button-secondary" <?php disabled( $data['disabled'], true ); ?>>
											<i class="dashicons dashicons-trash"></i>
											Bulk delete<span></span>rules
										</button>
									</div>
									<button type="button" class="button button-primary add-new" <?php disabled( $data['disabled'], true ); ?>>
										<i class="dashicons dashicons-plus-alt"></i>
										<span><?php _e( 'Add new rule', 'wc-smart-cod' ); ?></span>
									</button>
								</td>
							</tr>
						</tbody>
					</table>
						<?php echo $this->get_description_html( $data ); ?>
				</fieldset>
			</td>
		</tr>
			<?php
			return ob_get_clean();
	}


	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wc_Smart_Cod_Risk_Free_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wc_Smart_Cod_Risk_Free_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( 'wsc-micromodal', plugin_dir_url( __FILE__ ) . 'css/micromodal.css', array(), $this->version, 'all' );

		wp_enqueue_style( 'wsc-risk-free-css', plugin_dir_url( __FILE__ ) . 'css/wc-smart-cod-risk-free-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wc_Smart_Cod_Risk_Free_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wc_Smart_Cod_Risk_Free_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		if ( self::get_current_addon() !== 'wc-smart-cod-' . $this->mode ) {
			return;
		}

		add_thickbox();
		wp_enqueue_script( 'wsc-micromodal', plugin_dir_url( __FILE__ ) . 'js/micromodal.min.js', array( 'jquery' ), '0.4.6', false );

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wc-smart-cod-risk-free-admin.min.js', array( 'jquery', 'wc-smart-cod-pro', 'wsc-micromodal' ), $this->version, false );

		wp_localize_script( $this->plugin_name, 'wsc_rf_admin', array( 'mode' => $this->mode ) );

	}

}
