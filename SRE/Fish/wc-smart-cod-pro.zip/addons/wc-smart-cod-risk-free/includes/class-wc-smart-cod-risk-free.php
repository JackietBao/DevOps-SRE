<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://woosmartcod.com
 * @since      1.0.0
 *
 * @package    Wc_Smart_Cod_Risk_Free
 * @subpackage Wc_Smart_Cod_Risk_Free/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Wc_Smart_Cod_Risk_Free
 * @subpackage Wc_Smart_Cod_Risk_Free/includes
 * @author     woosmartcod.com <info@woosmartcod.com>
 */
class Wc_Smart_Cod_Risk_Free {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Wc_Smart_Cod_Risk_Free_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */

	protected $plugin_admin;

	private $mode;

	public static $shortname = 'wsc-riskfree';

	public function __construct( $mode ) {
		$this->mode = $mode;
		if ( defined( 'SMART_COD_VER' ) ) {
			$this->version = SMART_COD_VER;
		} else {
			$this->version = '1.0.0';
		}

		$this->plugin_name    = $mode === 'risk-free' ? 'wc-smart-cod-risk-free' : 'wc-smart-cod-extra-fees';
		$this->plugin_tabname = $mode === 'risk-free' ? 'Risk free COD' : 'Extra fees';

		add_action( 'plugins_loaded', array( $this, 'initialize_addon' ), 20 );
		add_filter( 'wsc_addons', array( $this, 'register_addon' ), 10, 1 );
	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Wc_Smart_Cod_Risk_Free_Loader. Orchestrates the hooks of the plugin.
	 * - Wc_Smart_Cod_Risk_Free_i18n. Defines internationalization functionality.
	 * - Wc_Smart_Cod_Risk_Free_Admin. Defines all hooks for the admin area.
	 * - Wc_Smart_Cod_Risk_Free_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */


	public static function get_riskfree_rules( $key_value_pair = false ) {
		$settings = get_option( 'woocommerce_smartcod_riskfree_settings' );
		
		if ( ! $settings || ! is_array( $settings ) ) {
			return array();
		}
		if ( ! isset( $settings['rules'] ) || ! is_array( $settings['rules'] ) ) {
			return array();
		}
		if( ! $key_value_pair ) {
			return $settings['rules'];
		}

		return array_reduce( $settings[ 'rules' ], function( $accumulator, $value ) {
			$accumulator[ $value[ 'id' ] ] = $value[ 'name' ];
			return $accumulator;
		}, array() );

	}

	public function register_addon( $addons ) {
		$addons[] = (object) array(
			'slug'          => $this->plugin_name,
			'name'          => $this->plugin_tabname,
			'settings'      => array( $this->plugin_admin, 'generate_settings' ),
			'save_callback' => array( $this->plugin_admin, 'save_callback' ),
		);
		return $addons;
	}

	public function initialize_addon() {
		if ( ! class_exists( 'WooCommerce' ) || ! class_exists( 'Wc_Smart_Cod' ) ) {
			return;
		}
		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();
		$this->run();
	}


	private function load_dependencies() {
		if ( ! class_exists( 'WooCommerce' ) || ! class_exists( 'Wc_Smart_Cod' ) ) {
			return;
		}

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wc-smart-cod-risk-free-loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wc-smart-cod-risk-free-i18n.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-wc-smart-cod-risk-free-admin.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-wc-smart-cod-risk-free-public.php';

		$this->loader = new Wc_Smart_Cod_Risk_Free_Loader();
	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Wc_Smart_Cod_Risk_Free_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new Wc_Smart_Cod_Risk_Free_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks() {

		$this->plugin_admin = new Wc_Smart_Cod_Risk_Free_Admin( $this->get_plugin_name(), $this->get_version(), $this->mode );

		$this->loader->add_action( 'admin_enqueue_scripts', $this->plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $this->plugin_admin, 'enqueue_scripts' );

	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks() {

		$plugin_public = new Wc_Smart_Cod_Risk_Free_Public( $this->get_plugin_name(), $this->get_version(), $this->mode );

		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );

	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Wc_Smart_Cod_Risk_Free_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}

}
