<?php

/**
 * Fired during plugin activation
 *
 * @link       https://woosmartcod.com
 * @since      1.0.0
 *
 * @package    Wc_Smart_Cod_Risk_Free
 * @subpackage Wc_Smart_Cod_Risk_Free/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wc_Smart_Cod_Risk_Free
 * @subpackage Wc_Smart_Cod_Risk_Free/includes
 * @author     woosmartcod.com <info@woosmartcod.com>
 */
class Wc_Smart_Cod_Risk_Free_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
