<?php
class Wc_Smart_Cod_Updater {

	private static $plugin_slug;

	private static $plugin_main_file;

	private static $info_url;

	private static $file_url;

	private $current_version;

	public function __construct( $plugin_slug, $current_version, $pro_url ) {

		self::$plugin_slug      = $plugin_slug;
		self::$plugin_main_file = str_replace( '-pro', '', $plugin_slug );
		self::$info_url         = $pro_url . '/update-service/info.php';
		self::$file_url         = $pro_url . '/update-service/update.php';
		$this->current_version  = $current_version;

		add_filter( 'plugins_api', array( $this, 'register_plugin_update_details' ), 20, 3 );

		add_filter( 'site_transient_update_plugins', array( $this, 'plugin_push_update' ), 10, 1 );

		add_filter( 'http_request_args', array( $this, 'after_parse' ), 10, 2 );

		add_filter( 'upgrader_pre_download', array( $this, 'pre_download' ), 10, 2 );

		add_action( 'upgrader_process_complete', array( $this, 'after_update' ), 10, 2 );

	}

	public function after_update( $upgrader_object, $options ) {

		if ( $options['action'] === 'update' && $options['type'] === 'plugin' ) {
			delete_transient( 'upgrade_' . self::$plugin_slug );
			delete_transient( 'update_' . self::$plugin_slug );
		}
	}

	public function after_parse( $parsed_args, $url ) {

		if ( $url !== self::$file_url ) {
			return $parsed_args;
		}

		$gc = $this->gc();

		$parsed_args['headers'] = array_merge(
			$parsed_args['headers'],
			array(
				'X-Wscu'  => $gc['u'],
				'X-Wscak' => $gc['ak'],
				'X-Wscsu' => get_site_url(),
			)
		);

		return $parsed_args;
	}

	public function pre_download( $reply, $package ) {
		if ( $package !== self::$file_url ) {
			return $reply;
		}
		$gc = $this->gc();
		if ( is_null( $gc ) || ( is_null( $gc['u'] ) || is_null( $gc['ak'] ) ) ) {
			return new WP_Error( 'download_failed', __( 'Please add your WooCommerce Smart COD PRO credentials.' ) );
		}
		return $reply;
	}

	public function plugin_push_update( $transient ) {

		if( ! is_object( $transient ) ) {
			$transient = new stdClass();
		}

		if ( false === $remote = get_transient( 'upgrade_' . self::$plugin_slug ) ) {

			$remote = wp_remote_get(
				self::$info_url,
				array(
					'timeout' => 10,
					'headers' => array(
						'Accept' => 'application/json',
					),
				)
			);

			if ( ! is_wp_error( $remote ) && isset( $remote['response']['code'] ) && $remote['response']['code'] == 200 && ! empty( $remote['body'] ) ) {
				// 2 hours cache
				set_transient( 'upgrade_' . self::$plugin_slug, $remote, 7200 );
			}
		}

		if ( $remote && ! is_wp_error( $remote ) ) {

			$remote = json_decode( $remote['body'] );
			if ( $remote && version_compare( $this->current_version, $remote->version, '<' ) ) {
				$res                                 = new stdClass();
				$res->slug                           = self::$plugin_slug;
				$res->plugin                         = self::$plugin_slug . '/' . self::$plugin_main_file . '.php';
				$res->new_version                    = $remote->version;
				$res->tested                         = $remote->tested;
				$res->package                        = $remote->download_url;
				$res->icons                          = (array) $remote->icons;
				$transient->response[ $res->plugin ] = $res;
			}
		}
		return $transient;
	}

	public function register_plugin_update_details( $res, $action, $args ) {

		if ( 'plugin_information' !== $action ) {
			return false;
		}

		$plugin_slug = self::$plugin_slug;

		if ( $plugin_slug !== $args->slug ) {
			return false;
		}

		// trying to get from cache first
		if ( false === $remote = get_transient( 'update_' . $plugin_slug ) ) {

			$remote = wp_remote_get(
				self::$info_url,
				array(
					'timeout' => 10,
					'headers' => array(
						'Accept' => 'application/json',
					),
				)
			);

			if ( ! is_wp_error( $remote ) && isset( $remote['response']['code'] ) && $remote['response']['code'] == 200 && ! empty( $remote['body'] ) ) {
				// 2 hours cache
				set_transient( 'update_' . $plugin_slug, $remote, 7200 );
			}
		}

		if ( ! is_wp_error( $remote ) && isset( $remote['response']['code'] ) && $remote['response']['code'] == 200 && ! empty( $remote['body'] ) ) {

			$remote = json_decode( $remote['body'] );
			$res    = new stdClass();

			$res->name          = $remote->name;
			$res->slug          = $plugin_slug;
			$res->version       = $remote->version;
			$res->tested        = $remote->tested;
			$res->requires      = $remote->requires;
			$res->author        = $remote->author;
			$res->download_link = $remote->download_url;
			$res->trunk         = $remote->download_url;
			$res->requires_php  = $remote->requires_php;
			$res->last_updated  = $remote->last_updated;
			$res->sections      = array(
				'description'  => $remote->sections->description,
				'installation' => $remote->sections->installation,
				'changelog'    => $remote->sections->changelog,
				'screenshots'  => $remote->sections->screenshots,
			);

			$res->banners = (array) $remote->banners;
			return $res;

		}

		return false;
	}

	private function gc() {
		$settings = get_site_option( 'woocommerce_cod_settings' );
		if ( ! $settings ) {
			return null;
		}
		return array(
			'u'  => isset( $settings['wsc_api_username'] ) && trim( $settings['wsc_api_username'] ) !== '' ? $settings['wsc_api_username'] : null,
			'ak' => isset( $settings['wsc_api_key'] ) && trim( $settings['wsc_api_key'] ) !== '' ? $settings['wsc_api_key'] : null,
		);
	}

}
