<?php

class Wc_Smart_Cod_A {
	private static $instance = null;
	private $a;

	private function __construct( $u, $k, $su, $pu ) {
		$this->a = $this->is_a_u( $u, $k, $su, $pu );
	}

	private function is_a_u( $u, $k, $su, $pu ) {
		$_o = get_transient( 'wsc_i_a' );
		if ( intval( $_o ) === 1 ) {
			return boolval( $_o );
		}
		$res = wp_remote_post(
			$pu,
			array(
				'body' => array(
					'u'  => $u,
					'ak' => $k,
					'su' => $su,
				),
			)
		);

		$o = ( $res
			&& isset( $res['response'] )
			&& isset( $res['response']['code'] )
			&& $res['response']['code'] === 200
		);

		if ( $o ) {
			set_transient( 'wsc_i_a', 1, 3600 );
		} else {
			$GLOBALS['hide_save_button'] = false;
		}
		return $o;
	}

	private function is_l( $whitelist = array( '127.0.0.1', '::1' ) ) {
		return in_array( $_SERVER['REMOTE_ADDR'], $whitelist );
	}

	public function __a() {
		return $this->a;
	}


	public static function get_instance( $u, $k, $su, $pu ) {
		if ( self::$instance == null ) {
			self::$instance = new Wc_Smart_Cod_A( $u, $k, $su, $pu );
		}

		return self::$instance;
	}
}
