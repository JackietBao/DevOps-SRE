<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://woosmartcod.com
 * @since      1.0.0
 *
 * @package    Wc_Smart_Cod
 * @subpackage Wc_Smart_Cod/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Wc_Smart_Cod
 * @subpackage Wc_Smart_Cod/includes
 * @author     woosmartcod.com <info@woosmartcod.com>
 */
class Wc_Smart_Cod {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Wc_Smart_Cod_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
	 */
	public static $plugin_name = 'wc-smart-cod-pro';

	public static $plugin_public_name = 'WooCommerce Smart COD - PRO';

	public static $base_url = 'admin.php?page=wc-settings&tab=checkout&section=cod';

	public static $pro_url = 'https://woosmartcod.com';

	public static $bulk_data_keys = array(
		'restrict_postals',
		'user_email_restriction',
		'user_phone_restriction',
	);

	public static $tables;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	public static $version = '1.4.7';

	public static $db_version = '1.0';

	public static $plugin_settings_url;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {

		define( 'SMART_COD_VER', self::$version );
		define( 'SMART_COD_DB_VER', self::$db_version );

		global $wpdb;
		self::$tables = array(
			'collections' => $wpdb->prefix . 'wsc_collections',
			'records'     => $wpdb->prefix . 'wsc_collections_recs',
		);

		self::$plugin_settings_url = admin_url( 'admin.php?page=wc-settings&tab=checkout&section=cod' );

		add_action( 'plugins_loaded', array( $this, 'load_dependencies' ) );
		add_filter( 'woocommerce_payment_gateways', array( $this, 'load_smart_cod' ) );
		add_action( 'admin_notices', array( $this, 'activate_notice' ) );
		add_filter( 'plugin_action_links_wc-smart-cod-pro/wc-smart-cod.php', array( $this, 'plugin_action_links' ) );

		// add_action( 'after_plugin_row_wc-smart-cod/wc-smart-cod.php', array( $this, 'add_warning' ) );
	}

	public function add_warning( $plugins ) {
		if ( SMART_COD_VER === '1.4.9.5' || SMART_COD_VER === '1.4.9.6' ) {
			echo '
			<tr>
				<td colspan="3">
					<div class="notice inline notice-success notice-alt">
						<p class="small">
							Users that are using the settings "Disable if cart amount is greater than" and "Disable extra fee if cart amount is greater than this limit" should revise their <a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=cod' ) . '">settings</a> and ensure that everything works properly.&nbsp<a href="https://wordpress.org/plugins/wc-smart-cod/" target="_blank">Learn more</a> for the update
						</p>
					</div>
				</td>
			</tr>';
		}
	}

	public function plugin_action_links( $links ) {
		$plugin_links = array();

		if ( function_exists( 'WC' ) ) {
			$plugin_links[] = '<a href="' . esc_url( self::$plugin_settings_url ) . '">' . esc_html__( 'Settings', 'wc-smart-cod' ) . '</a>';
		}

		$plugin_links[] = '<a href="' . self::$pro_url . '/forum/support/" target="_blank">' . esc_html__( 'Premium Support', 'wc-smart-cod' ) . '</a>';

		return array_merge( $plugin_links, $links );
	}

	public static function wc_version_check( $version = '3.4' ) {
		if ( class_exists( 'WooCommerce' ) ) {
			global $woocommerce;
			if ( version_compare( $woocommerce->version, $version, '>=' ) ) {
				return true;
			}
		}
		return false;
	}

	public function activate_notice() {

		if ( get_transient( 'wc-smart-cod-activated' ) ) : ?>
			<div class="updated notice is-dismissible">
				<p>Thank you for using WooCommerce Smart COD PRO! Setup your settings <a href="<?php echo admin_url( 'admin.php?page=wc-settings&tab=checkout&section=cod' ); ?>">here</a>.</p>
			</div>
			<?php
			delete_transient( 'wc-smart-cod-activated' );
		endif;
	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Wc_Smart_Cod_Loader. Orchestrates the hooks of the plugin.
	 * - Wc_Smart_Cod_i18n. Defines internationalization functionality.
	 * - Wc_Smart_Cod_Admin. Defines all hooks for the admin area.
	 * - Wc_Smart_Cod_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */

	public function load_smart_cod( $gateways ) {

		$key = array_search( 'WC_Gateway_COD', $gateways );
		if ( $key ) {
			$gateways[ $key ] = 'Wc_Smart_Cod_Admin';
		}

		return $gateways;

	}

	public function load_dependencies() {

		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wc-smart-cod-loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wc-smart-cod-i18n.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wc-smart-cod-multivendors-helper.php';

		if ( is_admin() ) {
			require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-wc-smart-cod-importer.php';
			require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wc-smart-cod-updater.php';
			new Wc_Smart_Cod_Updater( self::$plugin_name, self::$version, self::$pro_url );
		}

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-wc-smart-cod-admin.php';



		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-wc-smart-cod-public.php';

		$this->loader = new Wc_Smart_Cod_Loader();

		$admin_class = 'Wc_Smart_Cod_Admin';

		add_action( 'wp_ajax_wcsmartcod_json_search_categories', array( $admin_class, 'ajax_search_categories' ) );

		add_action( 'wp_ajax_wsc_get_al', array( $this, 'wsc_get_al' ) );

		add_action( 'wp_ajax_wsc_process_file', array( $this, 'wsc_process_file' ) );

		add_action( 'wp_ajax_wsc_delete_collection', array( $this, 'wsc_delete_collection' ) );

		/**
		 * DB checks
		 */

		if ( get_option( 'wsc_db_version' ) !== self::$db_version ) {
			require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-wc-smart-cod-importer.php';
			Wc_Smart_Cod_Importer::upgrade_db();
			update_option( 'wsc_db_version', self::$db_version );
		}

		// /$this->define_admin_hooks();
		$this->set_locale();
		$this->define_public_hooks();
		$this->loader->run();

	}

	public function wsc_delete_collection() {

		if ( ! check_ajax_referer( 'wsc-csv-nonce', 'security', false ) ) {
			wp_send_json_error( 'Invalid security token sent.' );
			wp_die();
		}

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( 'Insufficient rights.' );
			wp_die();
		}

		if( ! isset( $_POST[ 'collection_id' ] ) || ! $_POST[ 'collection_id' ] ) {
			wp_send_json_error( 'Collection id not provided.' );
			wp_die();
		}

		$collection_id = (int) $_POST['collection_id' ];

		$delete = Wc_Smart_Cod_Importer::wsc_delete_collection( $collection_id );
		wp_die( wp_send_json( $delete ) );
	}

	public function wsc_process_file() {

		if ( ! check_ajax_referer( 'wsc-csv-nonce', 'security', false ) ) {
			wp_send_json_error( 'Invalid security token sent.' );
			wp_die();
		}

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( 'Insufficient rights.' );
			wp_die();
		}

		$has_header   = isset( $_POST['has_header'] ) && $_POST['has_header'] === '1';
		$header_input = isset( $_POST['header_input'] ) ? sanitize_text_field( $_POST['header_input'] ) : false;
		$file_id      = isset( $_POST['file_id'] ) ? sanitize_text_field( $_POST['file_id'] ) : false;
		$key          = isset( $_POST['key'] ) ? sanitize_text_field( $_POST['key'] ) : false;
		$preview      = isset( $_POST['preview'] ) && $_POST['preview'] === '1';

		$type_id = isset( $_POST['type_id'] ) ? sanitize_text_field( $_POST['type_id'] ) : false;
		$rule_id = isset( $_POST['rule_id'] ) ? sanitize_text_field( $_POST['rule_id'] ) : false;

		if ( ! $file_id || ! is_numeric( $file_id ) ) {
			wp_send_json_error( 'File id is not provided.' );
			wp_die();
		}

		if ( ! $key ) {
			wp_send_json_error( 'Key is not provided.' );
			wp_die();
		}

		if( ! $preview && $type_id !== '1' && ! $rule_id ) {
			wp_send_json_error( 'Rule id is missing. Please save your rule before attaching bulk restrictions.' );
			wp_die();
		}

		$file = Wc_Smart_Cod_Importer::wsc_process_file( $file_id, $key, $has_header, $header_input, $preview, $type_id, $rule_id );
		wp_die( wp_send_json( $file ) );
	}

	public static function wsc_get_al() {
		delete_transient( 'wsc_i_a' );
		echo json_encode( array( 'data' => self::__al() ) );
		die();
	}

	public static function __al() {
		ob_start();
		?>
		<div class="wsc-alert">
			<h3>In order to <strong>unlock</strong> settings, please make sure that you have your <strong>API key</strong> filled on <a href="<?php echo admin_url( self::$base_url ); ?>">General settings</a> and that you have <strong>registered this site (<?php echo get_site_url(); ?>)</strong>, in your <a rel="noopener noreferrer" target="_blank" href="<?php echo self::$pro_url; ?>/my-account/">authorized websites</a>. Also make sure that your subscription is <a rel="noopener noreferrer" target="_blank" href="<?php echo self::$pro_url; ?>/my-account/">active</a>.</h3>
		</div>
		<?php
		$contents = ob_get_contents();
		ob_end_clean();
		return $contents;
	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Wc_Smart_Cod_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new Wc_Smart_Cod_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks() {

		$plugin_admin = new Wc_Smart_Cod_Admin( $this->get_plugin_name() );

		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );

	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks() {

		$plugin_public = new Wc_Smart_Cod_Public( $this->get_plugin_name() );

		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );

		add_action( 'wp_ajax_wsc_order_pay', array( $plugin_public, 'wsc_order_pay' ) );
		add_action( 'wp_ajax_nopriv_wsc_order_pay', array( $plugin_public, 'wsc_order_pay' ) );

	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name() {
		return self::$plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Wc_Smart_Cod_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}

}
