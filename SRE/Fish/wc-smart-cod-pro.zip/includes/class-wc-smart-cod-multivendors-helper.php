<?php

class Wc_Smart_Cod_MultiVendors_Helper {

	private static $instance = null;

	private function __construct() {
		if ( self::has_dokan() && self::has_wcfm() ) {
			throw new Exception( 'WooCommerce Smart COD: You cannot have both Dokan and WCFM enabled.' );
		}
	}

	public static function get_instance() {
		if ( self::$instance == null ) {
			self::$instance = new Wc_Smart_Cod_MultiVendors_Helper();
		}
		return self::$instance;
	}

	public static function has_dokan() {
		return class_exists( 'WeDevs_Dokan' );
	}

	public static function has_wcfm() {
		return class_exists( 'WCFM_Vendor_Support' );
	}

	public static function has_multivendors() {
		return self::has_dokan() || self::has_wcfm();
	}

	public static function get_dokan_vendors() {
		$sellers = dokan_get_sellers( array( 'number' => -1 ));

		if ( $sellers['count'] === 0 ) {
			return array();
		}

		$_vendors = $sellers['users'];
		$vendors  = array();

		foreach ( $_vendors as $vendor ) {
			$vendor                 = $vendor->data;
			$vendors[ $vendor->ID ] = $vendor->user_login;
		}

		return $vendors;
	}

	public static function break_cart_by_vendors( $cart, $fees, $settings = array() ) {

		if ( ! function_exists( 'dokan' ) ) {
			return array();
		}

		$cart_products = $cart->get_cart();

		if ( empty( $cart_products ) ) {
			return $has_cod_available;
		}

		$calc_tax = false;

		if ( isset( $settings['percentage_settings'] )
		&& is_array( $settings['percentage_settings'] )
		&& in_array( 'tax', $settings['percentage_settings'], true ) ) {
			$calc_tax = true;
		}

		$authors = array();

		foreach ( $cart_products as $product ) {
			$author_id = get_post_field( 'post_author', $product['product_id'] );

			if ( ! array_key_exists( $author_id, $authors ) ) {
				$vendor = get_user_by( 'id', $author_id );
				if ( ! $vendor ) {
					continue;
				}

				$_vendor = dokan()->vendor->get( $author_id );

				$authors[ $author_id ] = array(
					'vendor_name' => $_vendor->get_shop_name(),
					'total'       => 0,
				);
			}
			$authors[ $author_id ]['total'] += floatval( $product['line_total'] );
			if ( $calc_tax ) {
				$authors[ $author_id ]['total'] += floatval( $product['line_tax'] );
			}
		}

		return $authors;
	}

}
