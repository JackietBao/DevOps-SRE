const { PrismaClient } = require('@prisma/client');
const { getClientIp } = require('./ip');

const prisma = new PrismaClient();

/**
 * 记录日志
 * @param {Object} req - Express请求对象
 * @param {String} type - 日志类型
 * @param {String} title - 日志标题
 * @param {String} info - 日志详细信息
 */
const logAction = async (req, type, title, info = '') => {
  try {
    const ip = getClientIp(req);
    const userAgent = req.headers['user-agent'];

    // 如果没有提供详细信息，使用标题作为详细信息
    const logInfo = info || title;

    await prisma.log.create({
      data: {
        type,
        title,
        info: `${logInfo} | IP: ${ip} | UA: ${userAgent}`,
      },
    });
  } catch (error) {
    console.error('Error logging action:', error);
  }
};

/**
 * 获取日志
 * @param {String} type - 日志类型，可选
 * @param {Number} limit - 限制返回数量，默认100
 * @returns {Array} 日志数组
 */
const getLogs = async (type = null, limit = 100) => {
  try {
    const where = type ? { type } : {};

    const logs = await prisma.log.findMany({
      where,
      orderBy: {
        createdAt: 'desc',
      },
      take: limit,
    });

    return logs;
  } catch (error) {
    console.error('Error getting logs:', error);
    return [];
  }
};

/**
 * 清除旧日志
 * @param {Number} days - 保留天数，默认30天
 */
const cleanOldLogs = async (days = 30) => {
  try {
    const date = new Date();
    date.setDate(date.getDate() - days);

    await prisma.log.deleteMany({
      where: {
        createdAt: {
          lt: date,
        },
      },
    });

    console.log(`Cleaned logs older than ${days} days`);
  } catch (error) {
    console.error('Error cleaning old logs:', error);
  }
};

module.exports = {
  logAction,
  getLogs,
  cleanOldLogs,
};
