const Keyv = require('keyv');
const KeyvRedis = require('@keyv/redis');
const config = require('./index');

const redisStore = new KeyvRedis(config.redis.url);
const cache = new Keyv({ store: redisStore, namespace: 'app' });

cache.on('error', (err) => {
  console.error('Redis connection error:', err);
});

module.exports = cache;
