const express = require('express');
const compression = require('compression');
const cookieParser = require('cookie-parser');
const cors = require('cors');
const { createExpressMiddleware } = require('@trpc/server/adapters/express');
const { PrismaClient } = require('@prisma/client');
const fs = require('fs-extra');
const path = require('path');
const { appRouter } = require('./trpc/router');
const { createContext } = require('./trpc/context');
const config = require('./config');
const errorMiddleware = require('./middleware/error');
const ipBlacklistMiddleware = require('./middleware/ipBlacklist');

// 路由文件
const adminRoutes = require('./routes/admin');
const dataRoutes = require('./routes/data');
const settingRoutes = require('./routes/setting');
const ipBlacklistRoutes = require('./routes/ipBlacklist');
const logRoutes = require('./routes/log');

// 初始化Express应用
const app = express();

// 初始化Prisma客户端
const prisma = new PrismaClient();

// 中间件
app.use(compression());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(cors());

// IP黑名单中间件 - 应用于所有路由
app.use(ipBlacklistMiddleware);

// 确保上传目录存在
fs.ensureDirSync(config.uploadDir);

// 路由
app.use('/api/admin', adminRoutes);
app.use('/api/data', dataRoutes);
app.use('/api/settings', settingRoutes);
app.use('/api/blacklist', ipBlacklistRoutes);
app.use('/api/logs', logRoutes);

// tRPC
app.use(
  '/trpc',
  createExpressMiddleware({
    router: appRouter,
    createContext,
  })
);

// 静态文件
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

// 错误处理
app.use(errorMiddleware);

// 启动服务器
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`Environment: ${config.env}`);
});

// 优雅关闭
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully');
  await prisma.$disconnect();
  process.exit(0);
});

module.exports = app;
