const jwt = require('jsonwebtoken');
const { PrismaClient } = require('@prisma/client');
const config = require('../config');
const { logAction } = require('../utils/logger');

const prisma = new PrismaClient();

/**
 * 管理员认证中间件
 */
const authMiddleware = async (req, res, next) => {
  try {
    const token = req.cookies.token || req.headers.authorization?.split(' ')[1];

    if (!token) {
      return res.status(401).json({ message: '需要认证' });
    }

    const decoded = jwt.verify(token, config.jwtSecret);
    const admin = await prisma.admin.findUnique({
      where: { id: decoded.id },
    });

    if (!admin) {
      return res.status(401).json({ message: '管理员不存在' });
    }

    req.admin = admin;
    next();
  } catch (error) {
    return res.status(401).json({ message: '无效的令牌' });
  }
};

/**
 * 超级管理员权限中间件
 */
const superAdminMiddleware = async (req, res, next) => {
  try {
    if (req.admin.role !== 'super') {
      await logAction(req, '安全', '权限拒绝', `管理员 ${req.admin.account} 尝试访问超级管理员功能`);
      return res.status(403).json({ message: '需要超级管理员权限' });
    }
    next();
  } catch (error) {
    return res.status(403).json({ message: '需要超级管理员权限' });
  }
};

/**
 * API密钥认证中间件
 */
const apiKeyMiddleware = async (req, res, next) => {
  try {
    const apiKey = req.headers['x-api-key'];

    if (!apiKey) {
      return res.status(401).json({ message: '需要API密钥' });
    }

    // 从设置中获取API密钥
    const apiKeySetting = await prisma.setting.findFirst({
      where: {
        type: 'api',
        name: 'key',
      },
    });

    if (!apiKeySetting || apiKeySetting.value !== apiKey) {
      await logAction(req, '安全', 'API密钥无效', `无效的API密钥尝试`);
      return res.status(401).json({ message: '无效的API密钥' });
    }

    next();
  } catch (error) {
    return res.status(401).json({ message: '认证失败' });
  }
};

module.exports = {
  authMiddleware,
  superAdminMiddleware,
  apiKeyMiddleware
};
