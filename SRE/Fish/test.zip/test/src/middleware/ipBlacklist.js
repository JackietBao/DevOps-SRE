const { PrismaClient } = require('@prisma/client');
const { getClientIp } = require('../utils/ip');
const { logAction } = require('../utils/logger');

const prisma = new PrismaClient();

/**
 * IP黑名单中间件
 * 检查请求的IP是否在黑名单中，如果是，则拒绝请求
 */
const ipBlacklistMiddleware = async (req, res, next) => {
  try {
    const ip = getClientIp(req);
    
    // 检查IP是否在黑名单中
    const blacklisted = await prisma.iPBlacklist.findFirst({
      where: { ip },
    });

    if (blacklisted) {
      // 记录被拒绝的请求
      await logAction(req, '安全', 'IP黑名单拦截', `拦截了来自黑名单IP的请求: ${ip}`);
      
      return res.status(403).json({
        status: 'error',
        message: '您的IP已被禁止访问',
      });
    }

    next();
  } catch (error) {
    console.error('IP黑名单检查错误:', error);
    // 出错时继续处理请求，不阻止
    next();
  }
};

module.exports = ipBlacklistMiddleware;
