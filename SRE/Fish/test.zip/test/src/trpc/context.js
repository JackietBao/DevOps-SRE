const { PrismaClient } = require('@prisma/client');
const jwt = require('jsonwebtoken');
const config = require('../config');

const prisma = new PrismaClient();

const createContext = async ({ req, res }) => {
  let admin = null;

  try {
    const token = req.cookies.token || req.headers.authorization?.split(' ')[1];

    if (token) {
      const decoded = jwt.verify(token, config.jwtSecret);
      admin = await prisma.admin.findUnique({
        where: { id: decoded.id },
      });
    }
  } catch (error) {
    console.error('Error verifying token:', error);
  }

  return {
    req,
    res,
    prisma,
    admin,
  };
};

module.exports = {
  createContext,
};
