const { initTRPC, TRPCError } = require('@trpc/server');
const { z } = require('zod');

const t = initTRPC.context().create();

const isAuthed = t.middleware(({ ctx, next }) => {
  if (!ctx.admin) {
    throw new TRPCError({
      code: 'UNAUTHORIZED',
      message: '需要认证',
    });
  }
  return next({
    ctx: {
      admin: ctx.admin,
      prisma: ctx.prisma,
    },
  });
});

const isSuperAdmin = t.middleware(({ ctx, next }) => {
  if (!ctx.admin || ctx.admin.role !== 'super') {
    throw new TRPCError({
      code: 'FORBIDDEN',
      message: '需要超级管理员权限',
    });
  }
  return next({
    ctx: {
      admin: ctx.admin,
      prisma: ctx.prisma,
    },
  });
});

const publicProcedure = t.procedure;
const protectedProcedure = t.procedure.use(isAuthed);
const superAdminProcedure = t.procedure.use(isSuperAdmin);

const appRouter = t.router({
  // 公共过程
  hello: publicProcedure
    .input(z.object({ name: z.string().optional() }))
    .query(({ input }) => {
      return {
        greeting: `Hello ${input.name || 'World'}`,
      };
    }),

  // 获取统计信息
  getStats: protectedProcedure.query(async ({ ctx }) => {
    // 数据总数
    const dataCount = await ctx.prisma.data.count();

    // 今日数据量
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayDataCount = await ctx.prisma.data.count({
      where: {
        createdAt: {
          gte: today,
        },
      },
    });

    // 黑名单IP数量
    const blacklistCount = await ctx.prisma.iPBlacklist.count();

    // 日志数量
    const logCount = await ctx.prisma.log.count();

    return {
      data: {
        total: dataCount,
        today: todayDataCount,
      },
      blacklist: blacklistCount,
      logs: logCount,
    };
  }),

  // 获取当前管理员
  getAdmin: protectedProcedure.query(({ ctx }) => {
    return ctx.admin;
  }),

  // 获取所有管理员 - 需要超级管理员权限
  getAdmins: superAdminProcedure.query(async ({ ctx }) => {
    const admins = await ctx.prisma.admin.findMany({
      select: {
        id: true,
        account: true,
        role: true,
        createdAt: true,
        updatedAt: true,
      },
    });
    return admins;
  }),
});

module.exports = {
  appRouter,
};
