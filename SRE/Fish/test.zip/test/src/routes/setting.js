const express = require('express');
const { authMiddleware, superAdminMiddleware } = require('../middleware/auth');
const { 
  getAllSettings, 
  getSettingsByType, 
  getSetting, 
  upsertSetting, 
  batchUpdateSettings, 
  deleteSetting 
} = require('../controllers/setting');

const router = express.Router();

// 所有设置路由都需要认证
router.use(authMiddleware);

// 获取所有设置
router.get('/', getAllSettings);

// 按类型获取设置
router.get('/type/:type', getSettingsByType);

// 获取单个设置
router.get('/:type/:name', getSetting);

// 创建或更新设置
router.post('/', upsertSetting);

// 批量更新设置
router.post('/batch', batchUpdateSettings);

// 删除设置 - 需要超级管理员权限
router.delete('/:id', superAdminMiddleware, deleteSetting);

module.exports = router;
