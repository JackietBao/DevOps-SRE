const express = require('express');
const { authMiddleware } = require('../middleware/auth');
const { 
  getAllBlacklist, 
  addToBlacklist, 
  removeFromBlacklist, 
  batchAddToBlacklist, 
  checkIPInBlacklist 
} = require('../controllers/ipBlacklist');

const router = express.Router();

// 所有黑名单路由都需要认证
router.use(authMiddleware);

// 获取所有黑名单IP
router.get('/', getAllBlacklist);

// 检查IP是否在黑名单中
router.get('/check/:ip', checkIPInBlacklist);

// 添加IP到黑名单
router.post('/', addToBlacklist);

// 批量添加IP到黑名单
router.post('/batch', batchAddToBlacklist);

// 从黑名单中删除IP
router.delete('/:id', removeFromBlacklist);

module.exports = router;
