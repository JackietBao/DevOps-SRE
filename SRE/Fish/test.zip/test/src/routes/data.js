const express = require('express');
const { authMiddleware, superAdminMiddleware, apiKeyMiddleware } = require('../middleware/auth');
const {
  getAllData,
  getData,
  createData,
  updateData,
  deleteData,
  batchDeleteData,
  getDataStats,
  exportDataToCsv
} = require('../controllers/data');

const router = express.Router();

// 公开API - 需要API密钥
router.post('/collect', apiKeyMiddleware, createData);

// 管理员路由 - 需要认证
router.use(authMiddleware);

// 获取数据统计
router.get('/stats', getDataStats);

// 获取所有数据
router.get('/', getAllData);

// 获取单条数据
router.get('/:id', getData);

// 更新数据
router.put('/:id', updateData);

// 删除数据
router.delete('/:id', deleteData);

// 批量删除数据
router.post('/batch-delete', batchDeleteData);

module.exports = router;
