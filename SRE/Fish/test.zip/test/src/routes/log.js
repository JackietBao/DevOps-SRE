const express = require('express');
const { authMiddleware, superAdminMiddleware } = require('../middleware/auth');
const { 
  getAllLogs, 
  getLogTypes, 
  deleteLogs, 
  cleanLogs 
} = require('../controllers/log');

const router = express.Router();

// 所有日志路由都需要认证
router.use(authMiddleware);

// 获取所有日志
router.get('/', getAllLogs);

// 获取日志类型
router.get('/types', getLogTypes);

// 删除日志 - 需要超级管理员权限
router.post('/delete', superAdminMiddleware, deleteLogs);

// 清理旧日志 - 需要超级管理员权限
router.post('/clean', superAdminMiddleware, cleanLogs);

module.exports = router;
