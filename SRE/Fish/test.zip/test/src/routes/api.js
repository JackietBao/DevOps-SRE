const express = require('express');
const { authMiddleware } = require('../middleware/auth');
const { uploadFile } = require('../controllers/upload');
const { exportData, exportDataByFormat } = require('../controllers/export');

const router = express.Router();

router.get('/data', authMiddleware, (req, res) => {
  res.json({ message: 'Data endpoint' });
});

router.post('/upload', authMiddleware, uploadFile);
router.get('/export', authMiddleware, exportData);
router.get('/export/:format', authMiddleware, exportDataByFormat);

module.exports = router;
