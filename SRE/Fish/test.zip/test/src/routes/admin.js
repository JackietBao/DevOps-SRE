const express = require('express');
const { authMiddleware, superAdminMiddleware } = require('../middleware/auth');
const {
  getAdmins,
  createAdmin,
  updateAdmin,
  deleteAdmin,
  adminLogin,
  getAdminProfile
} = require('../controllers/admin');

const router = express.Router();

// 登录路由 - 不需要认证
router.post('/login', adminLogin);

// 以下路由需要认证
router.use(authMiddleware);

// 获取当前管理员信息
router.get('/profile', getAdminProfile);

// 以下路由需要超级管理员权限
router.use(superAdminMiddleware);

// 管理员管理
router.get('/', getAdmins);
router.post('/', createAdmin);
router.put('/:id', updateAdmin);
router.delete('/:id', deleteAdmin);

module.exports = router;
