const { PrismaClient } = require('@prisma/client');
const fs = require('fs-extra');
const path = require('path');

const prisma = new PrismaClient();

const exportData = async (req, res) => {
  try {
    const data = await prisma.data.findMany();

    return res.status(200).json({
      status: 'success',
      results: data.length,
      data,
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

const exportDataByFormat = async (req, res) => {
  try {
    const { format } = req.params;
    const data = await prisma.data.findMany();

    if (format === 'json') {
      return res.status(200).json({
        status: 'success',
        results: data.length,
        data,
      });
    } else if (format === 'csv') {
      // 创建CSV内容
      const header = 'id,content,userId,createdAt,updatedAt\n';
      const rows = data.map(item => 
        `${item.id},"${item.content.replace(/"/g, '""')}",${item.userId || ''},${item.createdAt},${item.updatedAt}`
      ).join('\n');
      const csv = header + rows;

      // 设置响应头
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename=data.csv');

      return res.status(200).send(csv);
    } else {
      return res.status(400).json({ message: 'Unsupported format' });
    }
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

module.exports = {
  exportData,
  exportDataByFormat,
};
