const { PrismaClient } = require('@prisma/client');
const { logAction } = require('../utils/logger');

const prisma = new PrismaClient();

/**
 * 获取所有设置
 */
const getAllSettings = async (req, res) => {
  try {
    const settings = await prisma.setting.findMany({
      orderBy: {
        type: 'asc',
      },
    });

    return res.status(200).json({
      status: 'success',
      results: settings.length,
      data: settings,
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

/**
 * 按类型获取设置
 */
const getSettingsByType = async (req, res) => {
  try {
    const { type } = req.params;

    const settings = await prisma.setting.findMany({
      where: { type },
      orderBy: {
        name: 'asc',
      },
    });

    return res.status(200).json({
      status: 'success',
      results: settings.length,
      data: settings,
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

/**
 * 获取单个设置
 */
const getSetting = async (req, res) => {
  try {
    const { type, name } = req.params;

    const setting = await prisma.setting.findFirst({
      where: { 
        type,
        name,
      },
    });

    if (!setting) {
      return res.status(404).json({ message: '设置不存在' });
    }

    return res.status(200).json({
      status: 'success',
      data: setting,
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

/**
 * 创建或更新设置
 */
const upsertSetting = async (req, res) => {
  try {
    const { type, name, value } = req.body;

    if (!type || !name || value === undefined) {
      return res.status(400).json({ message: '类型、名称和值都是必需的' });
    }

    const setting = await prisma.setting.upsert({
      where: {
        type_name: {
          type,
          name,
        },
      },
      update: {
        value,
      },
      create: {
        type,
        name,
        value,
      },
    });

    // 记录日志
    await logAction(req, '设置更新', `更新设置: ${type}.${name}`, `值: ${value}`);

    return res.status(200).json({
      status: 'success',
      data: setting,
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

/**
 * 批量更新设置
 */
const batchUpdateSettings = async (req, res) => {
  try {
    const { settings } = req.body;

    if (!settings || !Array.isArray(settings)) {
      return res.status(400).json({ message: '无效的参数' });
    }

    const results = [];

    for (const setting of settings) {
      const { type, name, value } = setting;
      
      if (!type || !name || value === undefined) {
        continue;
      }

      const result = await prisma.setting.upsert({
        where: {
          type_name: {
            type,
            name,
          },
        },
        update: {
          value,
        },
        create: {
          type,
          name,
          value,
        },
      });

      results.push(result);
    }

    // 记录日志
    await logAction(req, '设置批量更新', `批量更新设置`, `更新了 ${results.length} 项设置`);

    return res.status(200).json({
      status: 'success',
      results: results.length,
      data: results,
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

/**
 * 删除设置
 */
const deleteSetting = async (req, res) => {
  try {
    const { id } = req.params;

    const setting = await prisma.setting.findUnique({
      where: { id: Number(id) },
    });

    if (!setting) {
      return res.status(404).json({ message: '设置不存在' });
    }

    await prisma.setting.delete({
      where: { id: Number(id) },
    });

    // 记录日志
    await logAction(req, '设置删除', `删除设置`, `删除了设置: ${setting.type}.${setting.name}`);

    return res.status(204).send();
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getAllSettings,
  getSettingsByType,
  getSetting,
  upsertSetting,
  batchUpdateSettings,
  deleteSetting,
};
