const { PrismaClient } = require('@prisma/client');
const { hashPassword, comparePassword } = require('../utils/password');
const jwt = require('jsonwebtoken');
const config = require('../config');
const { logAction } = require('../utils/logger');

const prisma = new PrismaClient();

// 获取所有管理员
const getAdmins = async (req, res) => {
  try {
    const admins = await prisma.admin.findMany({
      select: {
        id: true,
        account: true,
        role: true,
        createdAt: true,
        updatedAt: true,
      },
    });

    return res.status(200).json({
      status: 'success',
      results: admins.length,
      data: admins,
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

// 创建管理员
const createAdmin = async (req, res) => {
  try {
    const { account, passwd, role } = req.body;

    const existingAdmin = await prisma.admin.findUnique({
      where: { account },
    });

    if (existingAdmin) {
      return res.status(400).json({ message: '账号已存在' });
    }

    const hashedPassword = await hashPassword(passwd);

    const admin = await prisma.admin.create({
      data: {
        account,
        passwd: hashedPassword,
        role,
      },
    });

    // 记录日志
    await logAction(req, '创建管理员', `创建了管理员账号: ${account}`);

    return res.status(201).json({
      status: 'success',
      data: {
        id: admin.id,
        account: admin.account,
        role: admin.role,
      },
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

// 更新管理员
const updateAdmin = async (req, res) => {
  try {
    const { id } = req.params;
    const { account, role, passwd } = req.body;

    const admin = await prisma.admin.findUnique({
      where: { id: Number(id) },
    });

    if (!admin) {
      return res.status(404).json({ message: '管理员不存在' });
    }

    const updateData = {};

    if (account) updateData.account = account;
    if (role) updateData.role = role;
    if (passwd) {
      updateData.passwd = await hashPassword(passwd);
    }

    const updatedAdmin = await prisma.admin.update({
      where: { id: Number(id) },
      data: updateData,
      select: {
        id: true,
        account: true,
        role: true,
        createdAt: true,
        updatedAt: true,
      },
    });

    // 记录日志
    await logAction(req, '更新管理员', `更新了管理员账号: ${admin.account}`);

    return res.status(200).json({
      status: 'success',
      data: updatedAdmin,
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

// 删除管理员
const deleteAdmin = async (req, res) => {
  try {
    const { id } = req.params;

    const admin = await prisma.admin.findUnique({
      where: { id: Number(id) },
    });

    if (!admin) {
      return res.status(404).json({ message: '管理员不存在' });
    }

    await prisma.admin.delete({
      where: { id: Number(id) },
    });

    // 记录日志
    await logAction(req, '删除管理员', `删除了管理员账号: ${admin.account}`);

    return res.status(204).send();
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

// 管理员登录
const adminLogin = async (req, res) => {
  try {
    const { account, passwd } = req.body;

    const admin = await prisma.admin.findUnique({
      where: { account },
    });

    if (!admin || !(await comparePassword(passwd, admin.passwd))) {
      return res.status(401).json({ message: '账号或密码错误' });
    }

    const token = jwt.sign({ id: admin.id, role: admin.role }, config.jwtSecret, {
      expiresIn: config.jwtExpiresIn,
    });

    res.cookie('token', token, {
      httpOnly: true,
      secure: config.env === 'production',
      maxAge: 24 * 60 * 60 * 1000, // 1 day
    });

    // 记录日志
    await logAction(req, '管理员登录', `管理员 ${account} 登录成功`);

    return res.status(200).json({
      status: 'success',
      token,
      admin: {
        id: admin.id,
        account: admin.account,
        role: admin.role,
      },
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

// 获取当前管理员信息
const getAdminProfile = async (req, res) => {
  try {
    const admin = await prisma.admin.findUnique({
      where: { id: req.admin.id },
      select: {
        id: true,
        account: true,
        role: true,
        createdAt: true,
      },
    });

    if (!admin) {
      return res.status(404).json({ message: '管理员不存在' });
    }

    return res.status(200).json({
      status: 'success',
      data: admin,
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getAdmins,
  createAdmin,
  updateAdmin,
  deleteAdmin,
  adminLogin,
  getAdminProfile,
};
