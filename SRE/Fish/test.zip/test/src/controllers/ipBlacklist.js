const { PrismaClient } = require('@prisma/client');
const { logAction } = require('../utils/logger');

const prisma = new PrismaClient();

/**
 * 获取所有黑名单IP
 */
const getAllBlacklist = async (req, res) => {
  try {
    const blacklist = await prisma.iPBlacklist.findMany({
      orderBy: {
        createdAt: 'desc',
      },
    });

    return res.status(200).json({
      status: 'success',
      results: blacklist.length,
      data: blacklist,
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

/**
 * 添加IP到黑名单
 */
const addToBlacklist = async (req, res) => {
  try {
    const { ip, remark } = req.body;

    if (!ip) {
      return res.status(400).json({ message: 'IP地址是必需的' });
    }

    // 检查IP是否已经在黑名单中
    const existing = await prisma.iPBlacklist.findFirst({
      where: { ip },
    });

    if (existing) {
      return res.status(400).json({ message: '该IP已在黑名单中' });
    }

    const blacklistItem = await prisma.iPBlacklist.create({
      data: {
        ip,
        remark: remark || '',
      },
    });

    // 记录日志
    await logAction(req, '黑名单', '添加IP到黑名单', `IP: ${ip}, 备注: ${remark || '无'}`);

    return res.status(201).json({
      status: 'success',
      data: blacklistItem,
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

/**
 * 从黑名单中删除IP
 */
const removeFromBlacklist = async (req, res) => {
  try {
    const { id } = req.params;

    const blacklistItem = await prisma.iPBlacklist.findUnique({
      where: { id: Number(id) },
    });

    if (!blacklistItem) {
      return res.status(404).json({ message: '黑名单项不存在' });
    }

    await prisma.iPBlacklist.delete({
      where: { id: Number(id) },
    });

    // 记录日志
    await logAction(req, '黑名单', '从黑名单中删除IP', `IP: ${blacklistItem.ip}`);

    return res.status(204).send();
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

/**
 * 批量添加IP到黑名单
 */
const batchAddToBlacklist = async (req, res) => {
  try {
    const { ips } = req.body;

    if (!ips || !Array.isArray(ips) || ips.length === 0) {
      return res.status(400).json({ message: '无效的参数' });
    }

    const results = [];
    const errors = [];

    for (const item of ips) {
      const { ip, remark } = typeof item === 'string' ? { ip: item, remark: '' } : item;
      
      if (!ip) {
        continue;
      }

      // 检查IP是否已经在黑名单中
      const existing = await prisma.iPBlacklist.findFirst({
        where: { ip },
      });

      if (existing) {
        errors.push({ ip, error: '该IP已在黑名单中' });
        continue;
      }

      const blacklistItem = await prisma.iPBlacklist.create({
        data: {
          ip,
          remark: remark || '',
        },
      });

      results.push(blacklistItem);
    }

    // 记录日志
    await logAction(req, '黑名单', '批量添加IP到黑名单', `添加了 ${results.length} 个IP`);

    return res.status(200).json({
      status: 'success',
      results: results.length,
      data: results,
      errors,
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

/**
 * 检查IP是否在黑名单中
 */
const checkIPInBlacklist = async (req, res) => {
  try {
    const { ip } = req.params;

    const blacklistItem = await prisma.iPBlacklist.findFirst({
      where: { ip },
    });

    return res.status(200).json({
      status: 'success',
      isBlacklisted: !!blacklistItem,
      data: blacklistItem,
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getAllBlacklist,
  addToBlacklist,
  removeFromBlacklist,
  batchAddToBlacklist,
  checkIPInBlacklist,
};
