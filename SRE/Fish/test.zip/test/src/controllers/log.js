const { PrismaClient } = require('@prisma/client');
const { getLogs, cleanOldLogs } = require('../utils/logger');

const prisma = new PrismaClient();

/**
 * 获取所有日志
 */
const getAllLogs = async (req, res) => {
  try {
    const { type, limit } = req.query;
    const logs = await getLogs(type, limit ? parseInt(limit) : 100);

    return res.status(200).json({
      status: 'success',
      results: logs.length,
      data: logs,
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

/**
 * 获取日志类型列表
 */
const getLogTypes = async (req, res) => {
  try {
    const types = await prisma.log.groupBy({
      by: ['type'],
    });

    return res.status(200).json({
      status: 'success',
      data: types.map(t => t.type),
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

/**
 * 删除日志
 */
const deleteLogs = async (req, res) => {
  try {
    const { ids } = req.body;

    if (!ids || !Array.isArray(ids)) {
      return res.status(400).json({ message: '无效的参数' });
    }

    await prisma.log.deleteMany({
      where: {
        id: {
          in: ids.map(id => Number(id)),
        },
      },
    });

    return res.status(200).json({
      status: 'success',
      message: `成功删除 ${ids.length} 条日志`,
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

/**
 * 清理旧日志
 */
const cleanLogs = async (req, res) => {
  try {
    const { days } = req.body;
    
    await cleanOldLogs(days || 30);

    return res.status(200).json({
      status: 'success',
      message: `成功清理 ${days || 30} 天前的日志`,
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getAllLogs,
  getLogTypes,
  deleteLogs,
  cleanLogs,
};
