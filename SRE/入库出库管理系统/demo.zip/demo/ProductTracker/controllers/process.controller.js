const processModel = require('../models/process.model');
const ExcelExporter = require('../utils/excelExporter');
const fs = require('fs');
const path = require('path');

// 流程类型到中文名称的映射
const processNameMap = {
  'storage': '入库',
  'film': '贴膜',
  'cutting': '切割',
  'inspection': '检验',
  'shipping': '出货'
};

class ProcessController {
  // 记录批次操作
  async recordProcess(req, res) {
    try {
      const { batchId, processType } = req.body;
      
      // 验证参数
      if (!batchId || !processType) {
        return res.status(400).json({
          success: false,
          message: '批次ID和操作类型不能为空'
        });
      }
      
      const result = await processModel.recordProcess(batchId, processType);
      return res.status(200).json(result);
    } catch (error) {
      return res.status(400).json({
        success: false,
        message: error.message
      });
    }
  }
  
  // 根据时间范围查询数据
  async queryByTimeRange(req, res) {
    try {
      const { processType, startTime, endTime } = req.query;
      
      // 验证参数
      if (!processType || !startTime || !endTime) {
        return res.status(400).json({
          success: false,
          message: '操作类型、开始时间和结束时间不能为空'
        });
      }
      
      const data = await processModel.queryByTimeRange(processType, startTime, endTime);
      return res.status(200).json({
        success: true,
        data
      });
    } catch (error) {
      return res.status(400).json({
        success: false,
        message: error.message
      });
    }
  }
  
  // 导出Excel文件
  async exportExcel(req, res) {
    try {
      const { processType, startTime, endTime } = req.query;
      
      // 验证参数
      if (!processType || !startTime || !endTime) {
        return res.status(400).json({
          success: false,
          message: '操作类型、开始时间和结束时间不能为空'
        });
      }
      
      const data = await processModel.queryByTimeRange(processType, startTime, endTime);
      
      // 确保导出目录存在
      const exportDir = path.join(__dirname, '../exports');
      if (!fs.existsSync(exportDir)) {
        fs.mkdirSync(exportDir, { recursive: true });
      }
      
      // 生成Excel文件
      const exporter = new ExcelExporter();
      exporter.initSheet(`${processNameMap[processType]}数据`);
      exporter.addData(data);
      
      const filename = `${processNameMap[processType]}_${startTime.replace(/[:-]/g, '')}_${endTime.replace(/[:-]/g, '')}.xlsx`;
      const filePath = path.join(exportDir, filename);
      
      await exporter.generateExcel(filePath);
      
      // 设置响应头并发送文件
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename=${filename}`);
      res.sendFile(filePath, err => {
        if (err) {
          console.error('发送文件失败:', err);
          return res.status(500).json({
            success: false,
            message: '文件下载失败'
          });
        }
        
        // 发送后删除临时文件
        fs.unlinkSync(filePath);
      });
    } catch (error) {
      return res.status(400).json({
        success: false,
        message: error.message
      });
    }
  }
  
  // 获取批次所有流程数据
  async getBatchData(req, res) {
    try {
      const { batchId } = req.params;
      
      if (!batchId) {
        return res.status(400).json({
          success: false,
          message: '批次ID不能为空'
        });
      }
      
      const data = await processModel.getAllProcessData(batchId);
      return res.status(200).json({
        success: true,
        data
      });
    } catch (error) {
      return res.status(400).json({
        success: false,
        message: error.message
      });
    }
  }
}

module.exports = new ProcessController(); 