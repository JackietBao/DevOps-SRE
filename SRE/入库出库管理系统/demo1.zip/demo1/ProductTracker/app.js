const express = require('express');
const cors = require('cors');
const path = require('path');
const { initDatabase } = require('./config/db');
const processRoutes = require('./routes/process.routes');

// 创建Express应用
const app = express();
const PORT = process.env.PORT || 3000;

// 中间件
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// 静态文件服务
app.use(express.static(path.join(__dirname, 'public')));

// 初始化数据库
initDatabase();

// API路由
app.use('/api', processRoutes);

// 根路由
app.get('/', (req, res) => {
  res.send('生产流程追踪系统API服务正在运行');
});

// 错误处理中间件
app.use((err, req, res, next) => {
  console.error('服务器错误:', err);
  res.status(500).json({
    success: false,
    message: '服务器内部错误'
  });
});

// 启动服务器
app.listen(PORT, () => {
  console.log(`服务器已启动，正在监听端口 ${PORT}`);
  console.log(`访问 http://localhost:${PORT} 查看API文档`);
}); 