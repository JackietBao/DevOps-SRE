<?php
error_reporting(0);
$do = isset($_GET['do']) ? $_GET['do'] : null;
$ti = isset($_GET['ti']) ? $_GET['ti'] : null;
switch ($do) {
    case 'color':
        $url = isset($_GET['url']) ? $_GET['url'] : null;
        $imageInfo = getimagesize($url);
        $imgType = strtolower(substr(image_type_to_extension($imageInfo[2]), 1));
        $imageFun = 'imagecreatefrom' . ($imgType == 'jpg' ? 'jpeg' : $imgType);
        $i = $imageFun($url);
        $rColorNum = $gColorNum = $bColorNum = $total = 0;
        for ($x = 0; $x < imagesx($i); $x++) {
            for ($y = 0; $y < imagesy($i); $y++) {
                $rgb = imagecolorat($i, $x, $y);
                $r = $rgb >> 16 & 0xff;
                $g = $rgb >> 8 & 0xff;
                $b = $rgb & 0xff;
                $rColorNum += $r;
                $gColorNum += $g;
                $bColorNum += $b;
                $total++;
            }
        }
        $rgb = array();
        $rgb['r'] = round($rColorNum / $total);
        $rgb['g'] = round($gColorNum / $total);
        $rgb['b'] = round($bColorNum / $total);
        echo "var ccont = '" . $rgb['r'] . "," . $rgb['g'] . "," . $rgb['b'] . "';";
        $R = (abs(255 - $rgb['r']*2) < 100) ? abs($rgb['r'] - 100) : (255 - $rgb['r']);
        $G = (abs(255 - $rgb['g']*2) < 100) ? abs($rgb['g'] - 100) : (255 - $rgb['g']);
        $B = (abs(255 - $rgb['b']*2) < 100) ? abs($rgb['b'] - 100) : (255 - $rgb['b']);
        echo "var ccont1 = '" . $R . "," . $G . "," . $B . "';";
        break;
    case 'song':
        echo "var NeiCeLists =[";
        $sj = isset($_GET['sj']) ? $_GET['sj'] : null;
        $id = isset($_GET['id']) ? $_GET['id'] : null;
        $name = isset($_GET['name']) ? $_GET['name'] : null;
        $type = isset($_GET['type']) ? $_GET['type'] : null;
        $from = isset($_GET['from']) ? $_GET['from'] : null;
        switch ($type) {
            case 'wy':
                $userplaylist = array();
                $response = json_decode(get_curl("http://music.163.com/api/user/playlist/?offset=0&limit=1001&uid=" . $id), true);
                foreach ($response[playlist] as $tracks) {
                    $userplaylist[] = array("song_album_id" => $tracks[id], "song_album" => $tracks[name], "song_album1" => $from, "song_list" => "");
                }
                $userplaylist[0][song_album] = $name . '音乐库';
                $sj == "YES" && shuffle($userplaylist);
                $c = count($userplaylist);
                for ($i = 0; $i < $c; $i++) {
                    $albumlist = $userplaylist[$i];
                    $song_lists = array();
                    $songs = json_decode(get_curl("http://music.163.com/api/playlist/detail?id=" . $userplaylist[$i][song_album_id]), true);
                    foreach ($songs[result][tracks] as $tracks) {
                        $song_lists[] = array("song_id" => $tracks[id], "song_title" => $tracks[name], "singer" => $tracks[artists][0][name], "album" => $tracks[album][name], "pic" => $tracks[album][picUrl], "mp3url" => 'https://music.163.com/song/media/outer/url?id='.$tracks[id].'');
                    }
                    $albumlist[song_list] = $song_lists;
                    print_r(json_encode($albumlist));
                    echo $i < $c - 1 ? "," : "";
                }
                break;
        }
        echo "]";
        break;
    case 'lyric':
        $id = isset($_GET['id']) ? $_GET['id'] : null;
        $type = isset($_GET['type']) ? $_GET['type'] : null;
        switch ($type) {
            case 'wy':
                $str = json_decode(str_replace('\\n', '', get_curl('http://music.163.com/api/song/lyric?os=pc&id=' . $id . '&lv=-1&kv=-1&tv=-1')), true);
                $str = $str['lrc']['lyric'];
                break;
        }
        echo 'var cont ="[00:00.01]~键：播放/暂停 ' . $ti . $str . '";';
        break;
}
function get_curl($url)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    $httpheader[] = "Accept:application/json";
    $httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
    $httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
    $httpheader[] = "Cookie: " . "appver=1.5.0.75771;";
    $httpheader[] = "Connection:close";
    curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (MSIE 9.0; Windows NT 6.1; Trident/5.0)");
    curl_setopt($ch, CURLOPT_ENCODING, "gzip");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $ret = curl_exec($ch);
    curl_close($ch);
    return $ret;
}
