<?php
header('Content-Type: text/html; charset=utf-8');
ERROR_REPORTING(0);
function decodeUnicode($str)
{
    return preg_replace_callback('/\\\\u([0-9a-f]{4})/i',
        create_function(
            '$matches',
            'return mb_convert_encoding(pack("H*", $matches[1]), "UTF-8", "UCS-2BE");'
        ),
        $str);
}
if(isset($_GET['id'])){
$id = $_GET['id'];
$getjson = 'http://tingapi.ting.baidu.com/v1/restserver/ting?songid='.$id.'&format=json&method=baidu.ting.song.lry';
$content = file_get_contents($getjson);
preg_match('|"lrcContent":"(.+)"|U', $content, $matches);
$lrc = $matches[1];
$lrc = str_replace('\n', "\n", $lrc);
$lrc = str_replace('\r\n', "\r\n", $lrc);
echo decodeUnicode($lrc);
}
?>