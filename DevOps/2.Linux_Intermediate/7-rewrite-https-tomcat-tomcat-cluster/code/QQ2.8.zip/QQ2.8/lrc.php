<?php  
header("Content-type: text/html; charset=utf-8");
ERROR_REPORTING(0);
if(isset($_GET['id'])){
$id = $_GET['id'];
$url = 'http://music.baidu.com/data2/lrc/'.$id.'/'.$id.'.lrc';
$content = @file_get_contents($url);
echo $content;   
  }
?>