<?php

if ( !empty( $_SERVER['SCRIPT_FILENAME'] ) && 'comments.php' == basename( $_SERVER['SCRIPT_FILENAME'] ) )
  die ('请不要直接加载该页面！');

if ( post_password_required() ) { ?>
  <p class="nocomments"><?php _e( '该评论需要权限查看，请输入密码。', 'contempo' ); ?></p>
<?php
  return;
}
?>

<div id="comments">
	<?php if(_hui('qq_fengge')){ ?>
		<div class="c-header">
			<span class="left"><i class="fa fa-qq"></i>评论&留言</span>
			<span class="right"><i class="fa fa-remove"></i></span>
			<span class="right"><i class="fa fa-minus"></i></span>
		</div>
	<?php } ?>
	<?php if ( comments_open() ): ?>
		<div class="comment-header">
		<div class="comment-logo" id="real-avatar">
			<span class="publish-logo">
			<?php if(isset($_COOKIE['comment_author_email_'.COOKIEHASH])) : ?>
				<?php echo get_avatar($comment_author_email, 48);?>
			<?php else :?>
				<?php global $user_email;?><?php echo get_avatar($user_email, 48); ?>
			<?php endif;?>		
				</span>
		</div>
		<?php if($user_ID): ?>
		<div class="comment-welcome">已登录 : <a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a>&nbsp;，&nbsp;<a href="<?php echo wp_logout_url(get_permalink()); ?>" title="Log out of this account">注销？</a></div>
		<?php else: ?>
		<?php if(isset($_COOKIE['comment_author_email_'.COOKIEHASH]) && isset($_COOKIE['comment_author_'.COOKIEHASH]))  : ?>
		<div class="comment-welcome">
		<?php printf(__('hello, <a>%1s</a>, 欢迎回来!'), $comment_author); ?>
		</div>		
		<?php else:?>
			<div class="comment-welcome">
				欢迎新朋友你的到来！
			</div>
		<?php endif; ?><?php endif; ?>	
		<?php if(have_comments()):?>
		<?php global $comment_ids; $comment_ids = array();
			foreach ( $comments as $comment ) {
			if (get_comment_type() == "comment") {
			$comment_ids[get_comment_id()] = ++$comment_i;}
		} ?>
		<div id="prompt"><i class="fa fa-hand-o-right"></i>已经有<?php comments_number('', '1 条评论', '% 条评论' );?>抢在你前面了~</div>
		<?php else : ?>
		<div id="prompt"><i class="fa fa-bullhorn"></i>还没有人抢沙发呢~</div>
		<?php endif; ?>
		</div>
		
		<div id="respond">
			
			<form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform">
				<?php if($user_ID): ?>
					
				<?php else: ?>
				<div class="comment-show">
				  <div class="input-inline">
					<div class="input-group">
						<span class="input-group-addon">昵称</span>
						<input type="text" class="form-control" name="author" id="author" placeholder="必填" value="<?php echo $comment_author; ?>" tabindex="1" <?php if($req) echo "aria-required='true'"; ?> />
					</div>
				  </div>
				  <div class="input-inline">
					<div class="input-group">
						<span class="input-group-addon">邮箱</span>
						<input type="text" class="form-control" name="email" id="email" placeholder="必填" value="<?php echo $comment_author_email; ?>" tabindex="2" <?php if($req) echo "aria-required='true'"; ?> />
					</div>
					</div>
					<div class="input-inline comment-form-url">
					<div class="input-group">
						<span class="input-group-addon">网站</span>
						<input type="text" class="form-control" name="url" id="url" value="<?php echo $comment_author_url; ?>" tabindex="3" />
					</div>
					</div>
				</div>
				<?php endif; ?>
				<div class="comment-textarea">
					<textarea name="comment" id="comment" tabindex="4" onkeydown="if(event.ctrlKey&&event.keyCode==13){document.getElementById('submit').click();return false};"></textarea>
				</div>
				<div class="comment-ctrl">
					<span class="cancel_comment_reply">
						<?php cancel_comment_reply_link('<i class="fa fa-times-circle"></i>取消回复'); ?>
					</span>
					<button class="btn btn-theme" name="submit" type="submit" id="submit" tabindex="5"><i class="fa fa-check-square-o"></i>提交评论</button>
					<?php comment_id_fields(); ?>
				</div>
				<?php do_action('comment_form',$post->ID); ?>
			</form>
		</div>
		<div class="alert alert-warning alert-dismissible fade in" role="alert">
			<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
			<strong>亲爱的朋友：</strong> 上面的信息框请您不要胡乱填写，尊重博主就等于尊重您自己，祝您每天都有一个好心情！
		</div>
		<ol class="comment-list">
			<?php wp_list_comments("type=comment&callback=commentlist"); ?>
		</ol>
		
		<div class="comment-navi">
			<span id="cp_post_id" style="display:none;">
				<?php echo $post->ID; ?>
			</span>
			<?php paginate_comments_links('prev_text=«上一页&next_text=下一页»');?>
		</div>
	<?php else: ?>
		<p class="close-comment">评论已关闭</p>
	<?php endif; ?><!--comments_open-->
</div>