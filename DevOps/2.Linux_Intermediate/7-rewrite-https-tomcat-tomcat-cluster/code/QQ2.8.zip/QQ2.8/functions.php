<?php 
// include qq theme functions file
include 'function.qq.php';


// custom functions