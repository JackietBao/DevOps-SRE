﻿<?php
header('Content-Type: text/html; charset=utf-8');
ERROR_REPORTING(0);
$id = $_GET['id'];
$lycid = intval($id) % 100;
$xmlfile = file_get_contents('http://music.qq.com/miniportal/static/lyric/' . $lycid . '/' . $id . '.xml');
$fileType = mb_detect_encoding($xmlfile, array('UTF-8', 'GBK', 'LATIN1', 'BIG5'));
$xmlfile = mb_convert_encoding($xmlfile, 'utf-8', $fileType);
$str = str_replace(PHP_EOL, '', $xmlfile);
$str = substr(strstr($str, '[0'), 0, -11);
echo $str;
?>