<?php if ( $_POST['action'] != 'ajax_post' ) : ?>
<?php get_header(); ?>
<div id="m-container">
<?php endif; ?>
	<div class="container containerall">
	<div class="main">
		<div id="content" class="post-single">
			<div id="singular-content">
			<?php /* The loop */ ?>
			<?php while ( have_posts() ) : the_post(); ?>
			<?php get_template_part('single-1', get_post_format()); ?>
			<?php endwhile; ?>
			</div>
		</div><!--content-->
		<?php comments_template('', true); ?>
	</div>
	<?php get_sidebar(); ?>
	</div>
<?php if ( $_POST['action'] != 'ajax_post' ) : ?>
</div>
<?php get_footer(); ?>
<?php endif; ?>