<?php if ( $_POST['action'] != 'ajax_post' ) : ?>
<?php get_header(); ?>
<div id="m-container">
<?php endif; ?>
	<div class="container containerall">
	<div class="main">
		<div id="content" class="post-single">
			<div id="singular-content">
				<?php qq_404(); ?>
			</div>
		</div><!--content-->
	</div>
	<?php get_sidebar(); ?>
	</div>
<?php if ( $_POST['action'] != 'ajax_post' ) : ?>
</div>
<?php get_footer(); ?>
<?php endif; ?>