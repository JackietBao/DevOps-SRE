<?php if ( $_POST['action'] != 'ajax_post' ) : ?>
<?php get_header(); ?>
<div id="m-container">
<?php endif; ?>
	<?php if(_hui('qq_fengge')){ ?>
		<?php hui_moloader2('index-3'); ?>
	<?php }else{ ?>
		<?php if( _hui('fengge') == 'jingdian_off' ) { ?>
			<?php hui_moloader2('index-1'); ?>
		<?php }else{ ?>
			<?php hui_moloader2('index-2'); ?>
		<?php } ?>
	<?php } ?>
<?php if ( $_POST['action'] != 'ajax_post' ) : ?>
</div>
<?php get_footer(); ?>
<?php endif; ?>
