	<div class="container containerall">
	<div class="main">
		<div id="content" class="index-single">
			<?php include(TEMPLATEPATH . '/function/post_header.php'); ?>
			<div class="qqfengget">
				<?php global $query_string; ?>
				<?php query_posts( $query_string . '&ignore_sticky_posts=1' ); ?>
				<?php if ( have_posts() ) : ?>
				<?php while ( have_posts() ) : the_post(); ?>
				<?php get_template_part('qq_content', get_post_format()); ?>
				<?php endwhile; ?>
				<?php endif; ?>
			</div>
		</div>
		<div class="paging">
			<?php pagenavi(); ?>
		</div>
	</div>
	<?php get_sidebar(); ?>
	</div>