<?php preg_match_all( '/\<img.+?src="(.+?)".*?\/>/',$post->post_content,$matches ,PREG_SET_ORDER); ?>

<?php if ( has_post_format( 'image' ) ) : //图片形式 ?>
	
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> >
		<header>
			<h2>
				<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" class="post-title"><?php the_title(); ?></a>
				<small class="text-muted" title="<?php echo get_post_images_number().'张图片' ?>"><span class="fa fa-photo"></span><?php echo get_post_images_number(); ?></small>
			</h2>
		</header>
		<div class="post-images-item">
			<ul>
				<?php echo qq_get_thumbnail();?>
			</ul>
		</div>
		<div class="posts-default-content">
			<div class="posts-text">
			<?php 
			if( !post_password_required() ){
				if ( has_excerpt() ) { //文章摘要 
					the_excerpt();
				}else{//无文章摘要 
					echo qq_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 55, '...');
				}
			}else{
				if ( has_excerpt() ) { //密码保护文章摘要 
					echo qq_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_excerpt)), 0, 55, '...');
				}
				echo '密码保护文章，暂无摘要！';
			}
			?>
			</div>
			<ul class="post-muted">
				<li class="post-author"><div class="avatar"><?php echo get_avatar( get_the_author_meta('email'), '' ); ?></div><a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ) ?>" target="_blank"><?php echo get_the_author() ?></a>  <?php the_time('Y/m/d'); ?></li>
				<li class="post-views"><i class="fa fa-eye"></i><?php echo qq_get_post_views(get_the_ID()); ?></li>
				<li class="post-comments"><i class="fa fa-comments-o"></i><?php comments_number( '0', '1', '%' ); ?></li>
			</ul>
		</div>
</article>

<?php elseif ( has_post_format( 'gallery' ) ) : //相册形式 ?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> >
		<header>
			<h2>
				<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" class="post-title"><?php the_title(); ?></a>
				<small class="text-muted" title="<?php echo get_post_images_number().'张图片' ?>"><span class="fa fa-photo"></span><?php echo get_post_images_number(); ?></small>
			</h2>
		</header>
		<div class="slider lazy">
			<?php all_imgt($post->post_content);?>
		</div>
		<div class="posts-default-content">
			<div class="posts-text">
			<?php 
			if( !post_password_required() ){
				if ( has_excerpt() ) { //文章摘要 
					the_excerpt();
				}else{//无文章摘要 
					echo qq_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 55, '...');
				}
			}else{
				if ( has_excerpt() ) { //密码保护文章摘要 
					echo qq_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_excerpt)), 0, 55, '...');
				}
				echo '密码保护文章，暂无摘要！';
			}
			?>
			</div>
			<ul class="post-muted">
				<li class="post-author"><div class="avatar"><?php echo get_avatar( get_the_author_meta('email'), '' ); ?></div><a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ) ?>" target="_blank"><?php echo get_the_author() ?></a>  <?php the_time('Y/m/d'); ?></li>
				<li class="post-views"><i class="fa fa-eye"></i><?php echo qq_get_post_views(get_the_ID()); ?></li>
				<li class="post-comments"><i class="fa fa-comments-o"></i><?php comments_number( '0', '1', '%' ); ?></li>
			</ul>
		</div>
</article>

<?php elseif ( has_post_format( 'aside' ) ) : //日志形式 ?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> >
		<header>
			<h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" class="post-title"><?php the_title(); ?></a></h2>
		</header>
		<div class="posts-default-content">
			<div class="posts-text">
			<?php 
			if( !post_password_required() ){
				if ( has_excerpt() ) { //文章摘要 
					the_excerpt();
				}else{//无文章摘要 
					echo qq_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 55, '...');
				}
			}else{
				if ( has_excerpt() ) { //密码保护文章摘要 
					echo qq_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_excerpt)), 0, 55, '...');
				}
				echo '密码保护文章，暂无摘要！';
			}
			?>
			</div>
			<ul class="post-muted">
				<li class="post-author"><div class="avatar"><?php echo get_avatar( get_the_author_meta('email'), '' ); ?></div><a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ) ?>" target="_blank"><?php echo get_the_author() ?></a>  <?php the_time('Y/m/d'); ?></li>
				<li class="post-views"><i class="fa fa-eye"></i><?php echo qq_get_post_views(get_the_ID()); ?></li>
				<li class="post-comments"><i class="fa fa-comments-o"></i><?php comments_number( '0', '1', '%' ); ?></li>
			</ul>
		</div>
</article>

<?php elseif ( has_post_format( 'link' ) ) : //心情形式 ?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> >
		<div class="post-author-img">
			<?php echo get_avatar( get_the_author_meta('email'), '' ); ?>
		</div>
		<div class="posts-link-content">
			<header>
				<h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" class="post-title"><?php the_title(); ?></a></h2>
			</header>
			<div class="posts-text">
			<?php 
				if ( has_excerpt() ) { //文章摘要 
					the_excerpt();
				}else{//无文章摘要 
					the_content();
				}
			?>
			</div>
		</div>
</article>

<?php elseif ( has_post_format( 'audio' ) ) : //音频形式 ?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> >
		<header>
			<h2><i class="fa fa-music"></i><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" class="post-title"><?php the_title(); ?></a></h2>
		</header>
		<div class="posts-default-content">
			<div class="posts-text">
			<?php 
			if( !post_password_required() ){
				if ( has_excerpt() ) { //文章摘要 
					the_excerpt();
				}else{//无文章摘要 
					the_content();
				}
			}else{
				if ( has_excerpt() ) { //密码保护文章摘要 
					echo qq_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_excerpt)), 0, 55, '...');
				}
				echo '密码保护文章，暂无摘要！';
			}
			?>
			</div>
		</div>
			
</article>

<?php else: //正常形式 ?>
	
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> >
		<div class="focus">
			<a href="<?php the_permalink() ?>">
			<span class="item"><span class="thumb-span">
				<?php if ( has_post_thumbnail() ) : //特色图片?>
					<?php echo _get_post_thumbnail(); ?>
				<?php else: //无特色图片?>
					<?php if ( $matches[0][1] ) ://文章内有图片 ?>
						<img src="<?php echo $matches [0][1];?>" />
					<?php else : //文章内没有图片?>
						<?php echo _get_post_thumbnail(); ?>
					<?php endif;//文章内有图片结束 ?>
				<?php endif;//特色图片结束 ?>
			</span></span>
			</a>
		</div>
		<div class="note">
			<h2>
				<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" class="post-title"><?php the_title(); ?></a>
				<small class="text-muted" title="<?php echo get_post_images_number().'张图片' ?>"><span class="fa fa-photo"></span><?php echo get_post_images_number(); ?></small>
			</h2>
			<div class="posts-text">
			<?php 
			if( !post_password_required() ){
				if ( has_excerpt() ) { //文章摘要 
					the_excerpt();
				}else{//无文章摘要 
					echo qq_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 55, '...');
				}
			}else{
				if ( has_excerpt() ) { //密码保护文章摘要 
					echo qq_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_excerpt)), 0, 55, '...');
				}
				echo '密码保护文章，暂无摘要！';
			}
			?>
			</div>
			<ul class="post-muted">
				<li class="post-author"><div class="avatar"><?php echo get_avatar( get_the_author_meta('email'), '' ); ?></div><a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ) ?>" target="_blank"><?php echo get_the_author() ?></a>  <?php the_time('Y/m/d'); ?></li>
				<li class="post-views"><i class="fa fa-eye"></i><?php echo qq_get_post_views(get_the_ID()); ?></li>
				<li class="post-comments"><i class="fa fa-comments-o"></i><?php comments_number( '0', '1', '%' ); ?></li>
			</ul>
		</div>
</article>

<?php endif;//图片形式结束 ?>