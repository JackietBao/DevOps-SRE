<form class="form-inline" id="search" method="post" action="<?php bloginfo('url');?>/" role="search">
	<div class="input-group">
		<input type="text" placeholder="搜索" class="form-control" name="s">
		<span class="input-group-btn">
			<button class="btn btn-primary" id="search-btn" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
		</span>
	</div><!-- /input-group -->
</form>