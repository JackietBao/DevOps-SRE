function do_comment_js(){
	var $commentform = $('#commentform'),
	$comments = $('#comments-title'),
	$cancel = $('#cancel-comment-reply-link'),
	cancel_text = "取消回复";
	$('#comment').after('<div id="comment_message" style="display:none;"></div>');
	$(document).on("submit", "#commentform",
	function() {
		$('#comment_message').slideDown().html("<p>评论提交中....</p>");
		$('#submit').addClass("disabled").val("发表评论").attr("disabled","disabled");
		$.ajax({
			url: qq.ajaxurl,
			data: $(this).serialize() + "&action=ajax_comment",
			type: $(this).attr('method'),
			error: function(request) {
				$('#comment_message').addClass('comt-error').html(request.responseText);
				setTimeout("$('#submit').removeClass('disabled').val('发表评论').attr('disabled',false)", 2000);
				setTimeout("$('#comment_message').slideUp()", 2000);
				setTimeout("$('#comment_message').removeClass('comt-error')", 3000);
			},
			success: function(data) {
				$('textarea').each(function() {
					this.value = ''
				});
				var t = addComment,
				cancel = t.I('cancel-comment-reply-link'),
				temp = t.I('wp-temp-form-div'),
				respond = t.I(t.respondId),
				post = t.I('comment_post_ID').value,
				parent = t.I('comment_parent').value;
				if (parent != '0') {
					$('#respond').before('<ul class="children">' + data + '</ul>');
				} else if ( $('.commentlist').length != '0') {
					$('.comment-list').prepend(data);
					//$('#respond').before('<ol class="comment-list">' + data + '</ol>');//comment-list is your comments wrapper,check your container ul or ol
				} else {
					$('.comment-list').prepend(data);// your comments wrapper
				}

				$('#comment_message').html("<p>评论提交成功</p>");
				setTimeout("$('#submit').removeClass('disabled').val('发表评论').attr('disabled',false)", 2000);
				setTimeout("$('#comment_message').slideUp()", 2000);
				cancel.style.display = 'none';
				cancel.onclick = null;
				t.I('comment_parent').value = '0';
				if (temp && respond) {
					temp.parentNode.insertBefore(respond, temp);
					temp.parentNode.removeChild(temp)
				}
				//回复可见
				get_post_content();
			}
		});
		return false;
	});
	addComment = {
		moveForm: function(commId, parentId, respondId) {
			var t = this,
			div,
			comm = t.I(commId),
			respond = t.I(respondId),
			cancel = t.I('cancel-comment-reply-link'),
			parent = t.I('comment_parent'),
			post = t.I('comment_post_ID');
			$cancel.text(cancel_text);
			t.respondId = respondId;
			if (!t.I('wp-temp-form-div')) {
				div = document.createElement('div');
				div.id = 'wp-temp-form-div';
				div.style.display = 'none';
				respond.parentNode.insertBefore(div, respond)
			} ! comm ? (temp = t.I('wp-temp-form-div'), t.I('comment_parent').value = '0', temp.parentNode.insertBefore(respond, temp), temp.parentNode.removeChild(temp)) : comm.parentNode.insertBefore(respond, comm.nextSibling);
			$("body").animate({
				scrollTop: $('#respond').offset().top - 180
			},
			400);
			parent.value = parentId;
			cancel.style.display = '';
			cancel.onclick = function() {
				var t = addComment,
				temp = t.I('wp-temp-form-div'),
				respond = t.I(t.respondId);
				t.I('comment_parent').value = '0';
				if (temp && respond) {
					temp.parentNode.insertBefore(respond, temp);
					temp.parentNode.removeChild(temp);
				}
				this.style.display = 'none';
				this.onclick = null;
				return false;
			};
			try {
				t.I('comment').focus();
			}
			 catch(e) {}
			return false;
		},
		I: function(e) {
			return document.getElementById(e);
		}
	};
}

//ajax评论翻页
function comment_page_ajax(){
	$('.comment-navi a').click(function(){
		var wpurl=$(this).attr("href").split(/(\?|&)action=AjaxCommentsPage.*$/)[0];
		var commentPage = 1;
		if (/comment-page-/i.test(wpurl)) {
			commentPage = wpurl.split(/comment-page-/i)[1].split(/(\/|#|&).*$/)[0];
		} else if (/cpage=/i.test(wpurl)) {
			commentPage = wpurl.split(/cpage=/)[1].split(/(\/|#|&).*$/)[0];
		};
		var loading = '<div class="commnav_loding"><i class="fa fa-spinner fa-spin"></i>正在努力读取中......</div>';
		var postId = qq.postid;
		$.ajax({
			url:qq.ajaxurl,
			type:'POST',
			data:{action:'AjaxCommentsPage', post:postId, page:commentPage},
			dataType:'html',
			beforeSend: function() {
				var top = $( '#comments' ).offset().top;
				if ( $( '#wpadminbar' )[0] ){
					top -= $( '#wpadminbar' ).height();//登录过后减去adminbar的高度;
				}
				$( 'html,body' ).animate({scrollTop:top},0);
				$( '.comment-list' ).empty().html(loading);
			},
			error: function(request) {
					alert(request.responseText);
				},
			success:function(data){
				var responses=data.split('<!--winysky-AJAX-COMMENT-PAGE-->');
				$('.comment-list').empty().html(responses[0]).stop().css({'margin-top':'80px','opacity':0}).animate({'margin-top':'40px','opacity':1},600);
				$('.comment-navi').empty().html(responses[1]);
				
				comment_page_ajax();//自身重载一次
			}//返回评论列表顶部
		});
		
		return false;
	});
}

$(document).ready(function () {
	comment_page_ajax();
	do_comment_js();
});
