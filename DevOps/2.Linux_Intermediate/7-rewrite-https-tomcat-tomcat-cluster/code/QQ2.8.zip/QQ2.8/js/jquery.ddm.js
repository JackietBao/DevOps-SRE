(function($) {
 	$.fn.extend({
 		insertContent: function(myValue, t) {
 			var $t = $(this)[0];
 			if (document.selection) { // ie
 				this.focus();
 				var sel = document.selection.createRange();
 				sel.text = myValue;
 				this.focus();
 				sel.moveStart('character', -l);
 				var wee = sel.text.length;
 				if (arguments.length == 2) {
 					var l = $t.value.length;
 					sel.moveEnd("character", wee + t);
 					t <= 0 ? sel.moveStart("character", wee - 2 * t - myValue.length) : sel.moveStart("character", wee - t - myValue.length);
 					sel.select();
 				}
 			} else if ($t.selectionStart || $t.selectionStart == '0') {
 				var startPos = $t.selectionStart;
 				var endPos = $t.selectionEnd;
 				var scrollTop = $t.scrollTop;
 				$t.value = $t.value.substring(0, startPos) + myValue + $t.value.substring(endPos, $t.value.length);
 				this.focus();
 				$t.selectionStart = startPos + myValue.length;
 				$t.selectionEnd = startPos + myValue.length;
 				$t.scrollTop = scrollTop;
 				if (arguments.length == 2) {
 					$t.setSelectionRange(startPos - t, $t.selectionEnd + t);
 					this.focus();
 				}
 			} else {
 				this.value += myValue;
 				this.focus();
 			}
 		}
 	})
 })(jQuery);
jQuery(document).ready(function($){
	var arrs = [
		'短代码',
		'[reply][/reply]',
		'[mp3 name="" img=""][/mp3]',
		'[mp3 name="" img="" id=""][/mp3][lrc id=""][/lrc]',
		'[mp3 name="" img="" id=""][/mp3][lrc2 id=""][/lrc2]',
		'[link aurl="" email=""][/link]',
		'[s][p][/p]',
		'[mima id="" title=""][/mima]',
		'[y auto=""][/y]',
	];
	$('#ddm-button').click(function(e){
		e.preventDefault();
		$('#ddm-lay,#ddm-box').fadeIn();
		return false;
	});
	$('#ddm-close').click(function(e){
		e.preventDefault();
		$('#ddm-lay,#ddm-box').hide();
		return false;
	});
	$('#ddm-cate li a').click(function(e){
		e.preventDefault();
		if($(this).hasClass('current')) return false;
		var _this = $(this),
			_n = $('#ddm-cate li a').index(_this),
			_cateACurrrent = $('#ddm-cate li a.current'),
			_ddmCurrent = $('#ddm-ddm li.current'),
			_ddmNext = $('#ddm-ddm li').eq(_n);
		_cateACurrrent.removeClass('current');
		_ddmCurrent.removeClass('current');
		_this.addClass('current');
		_ddmNext.addClass('current');
		return false;
	});
	$('#ddm-ddm li a').click(function(e){
		e.preventDefault();
		var _this = $(this),
			_n = _this.attr('href'),
			_ddm = arrs[_n];
		if( $('#content').is(":visible") ){
			var _t = $('#content').val();
			$('#content').insertContent( _ddm );
		}else{
			var _ele = $('#content_ifr').contents().find("#tinymce"),
				_t = _ele.html();
			_ele.html(_t + _ddm).focus();
		}
		$('#ddm-close').click();
		return false;
	});
});