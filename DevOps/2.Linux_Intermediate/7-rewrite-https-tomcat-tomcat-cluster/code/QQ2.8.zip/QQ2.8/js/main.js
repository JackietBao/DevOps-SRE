var home_logo_switch = 0;//用以判断顶部是否缩上去
var popbanded = 0;//前进后退按钮只绑定一次

function loading_show(){
	if ( !$( '#loading-wrap .loading' )[0] ){
		$('#loading-wrap').append(_loading);
	}
	$( '#loading-wrap' ).css({'height':$(window).height()}).addClass('show');
	$( '#loading-wrap .loading' ).show().css({'margin-top':( $(window).height() - 120 ) / 2});
}
function loading_hide(){
	$( '#loading-wrap' ).removeClass('show');
	setTimeout(function(){//等待css animation动画缓冲完
		$( '#loading-wrap' ).css({'height':0});
		$( '#loading-wrap .loading' ).css({'margin-top':0}).hide();
	},800);
}

//js重载
function reload_js(){
	//qq音乐js重载
	if( window.qqmusic !== undefined ){qqmusic();}
	//评论js重载
	if( window.do_comment_js !== undefined ){do_comment_js();}

	//评论分页js重载
	if( window.comment_page_ajax !== undefined ){comment_page_ajax();}
	
	//文章内一些js重载
	if( window.article_js !== undefined ){article_js();}

	//触发图片延迟加载一些js
	if( window.chufa_js !== undefined ){chufa_js();}
	
	//手机侧边栏js重载
	if( window.fssilde !== undefined ){fssilde();}
	
	//按钮播放器
	if( window.audio_ready !== undefined ){audio_ready();}

	//hermit
	if( window.hermitjs !== undefined ){
		hermitjs.reload();
	}
	
	//um
	if( window.fum !== undefined ){
		fum();
	}

	ajax_post_bind();//重新绑定文章标题
	
}
//ajax文章
function ajax_get_post(title,href,push_switch){
	$.ajax({
		url:href,
		type:'POST',
		data:'action=ajax_post',
		dataType:'html',
		beforeSend:function(){
			$( '#m-container' ).fadeTo('normal',1);
			loading_show();
		},
		error:function(){
			$( '#m-container' ).html('Ajax Error!').fadeTo('normal',1);
		},
		success:function(data){
			loading_hide();
			$('html,body').animate({scrollTop:0},0);
			$( '#m-container' ).html(data).fadeTo('normal',1);
			if ( href != qq.url && !href.match(qq.url+'page')) {//非首页执行代码
				reload_js();//js重载
				home_logo_switch = 0;
			}else{//首页执行代码
				if ( home_logo_switch== 0 ){
						reload_js();//首页当顶部动画过后再重载js
					home_logo_switch = 1;
				}else{
					reload_js();
				}
			}
			window.document.title = title;
			if ( push_switch == 1 ) {
				var state = {
					title: title,
					url: href
				}
				window.history.pushState(state, title, href);
			}
			if ( popbanded == 0 ){
				window.addEventListener('popstate',function(e){
					if ( history.state ){
						ajax_get_post(history.state.title,history.state.url,0);
					}else{
						ajax_get_post(qq.ajax_site_title,window.location.href,0);
					}
					//主菜单
					$( '.current-menu-item' ).removeClass('current-menu-item');
					$( '.current-menu-parent' ).removeClass('current-menu-parent');
					$( '.current-menu-ancestor' ).removeClass('current-menu-ancestor');
				},false);
				popbanded = 1;
			}
		}
	});
}

//获取文章前的一些处理
function ajax_start(_this){
	var title = ( _this.attr("title")?_this.attr("title"):_this.text() ) + " - " + qq.ajax_site_title,
		href = _this.attr("href"),
		this_href = window.location.href;
		i = href.replace(this_href,'');
	//if ( href == this_href ) return false;
	if ( i == '#' ) return false;
	if ( !href.match(qq.url ) ) return 0;
	ajax_get_post(title,href,1);
	
	//主菜单
	$( '.current-menu-item' ).removeClass('current-menu-item');
	$( '.current-menu-parent' ).removeClass('current-menu-parent');
	$( '.current-menu-ancestor' ).removeClass('current-menu-ancestor');
	return false;
	//return 1;
}
	
function ajax_menu(_this){
	var i = ajax_start(_this);
	if ( i == 1 ){
		//主菜单
		$( '.current-menu-item' ).removeClass('current-menu-item');
		$( '.current-menu-parent' ).removeClass('current-menu-parent');
		$( '.current-menu-ancestor' ).removeClass('current-menu-ancestor');
		return false;
	}
	return i;
}

function ajax_post_bind(){
	$( 'a.hidden-sm' ).on('click',function(){//logo
		var i = ajax_start($(this));
		return i;
	});
	$( '.article a' ).on('click',function(){//顶置文章
		var i = ajax_start($(this));
		return i;
	});
	$( 'a.post-title' ).on('click',function(){//文章标题
		var i = ajax_start($(this));
		return i;
	});
	$( '.format-image a' ).on('click',function(){//图像文章首页图片
		var i = ajax_start($(this));
		return i;
	});
	
	$( '.single-paging a' ).on('click',function(){//文章内分页
		var i = ajax_start($(this));
		return i;
	});
	$( '.paging a' ).on('click',function(){//文章分页
		var i = ajax_start($(this));
		return i;
	});
	$( '.tab-content li a' ).on('click',function(){//侧边栏qq
		var i = ajax_start($(this));
		return i;
	});
	$( '.widget li a' ).on('click',function(){//侧边栏小工具
		var i = ajax_start($(this));
		return i;
	});
	$( '.tags-list a' ).on('click',function(){//侧边栏面板分类
		var i = ajax_start($(this));
		return i;
	});
	$('#search-form').on('submit', function(){//搜索框
		var s = $(this).find( '#s' ).val();
		if( s == "" ){
			return false;
		}
		var href = $(this).attr('action') + '?s=' + encodeURIComponent(s),
			title = s + ' - 搜索结果';
		ajax_get_post(title,href,1);
		
		return false;
	});
}

$(document).ready(function(){
	//页面刷新，判断是否为首页
	if ( window.location.href != qq.url && !window.location.href.match(qq.url+'page') ) {
	}else{
		home_logo_switch = 1;
	}
	//依次绑定
	ajax_post_bind();
	
	//只需要绑定一次
	//主菜单
	$( '.nav-menu a,.nav a' ).on('click',function(){
		var i = ajax_start($(this));
		if ( i == 1 ){
			//主菜单
			$( '.current-menu-item' ).removeClass('current-menu-item');
			$( '.current-menu-parent' ).removeClass('current-menu-parent');
			$( '.current-menu-ancestor' ).removeClass('current-menu-ancestor');
			$(this).parent().addClass('current-menu-item');
			return false;
		}
		return i;
	});

	
});