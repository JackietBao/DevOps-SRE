$(function(){
	$("#login h1 a").attr("href",""+homeurl+"");
	$("#login h1 a").attr("title","返回主页"); 
})