<?php
/* 
 * options
 * ====================================================
*/
define( 'HOME_URI', home_url() );
define( 'HOME_DIR', rtrim(WP_CONTENT_DIR, "/wp-content") );
define( 'THEME_FILES', get_stylesheet_directory() );
define( 'THEME_URI', get_stylesheet_directory_uri() );
define( 'MOD_URI'        , THEME_FILES.'/function' );

if ( ! function_exists( '_hui' ) ) {
    function _hui( $name, $default = false ) {
        $config = get_option( 'opshui' );

        if ( ! isset( $config['id'] ) ) {
            return $default;
        }

        $options = get_option( $config['id'] );

        if ( isset( $options[$name] ) ) {
            return $options[$name];
        }

        return $default;
    }
}
include('function/socials.php');
include('function/weibo.php');
include('function/qq-slider.php');
include('function/post-meta.php');
include('function/ajax-comment.php');
include('function/short-code.php');
include('function/register.php');
include('function/music.php');
include('functions.admin.php');
include('function/slider-category.php');;
if( _hui('no_player') ){
	include('radio/inc/template.php');
	add_action( 'wp_footer', 'np_footer');
}

add_editor_style('editor-style.css');

add_action( 'after_setup_theme', 'f_setup' );
function f_setup(){
	//去除头部冗余代码
	remove_action( 'wp_head',   'feed_links_extra', 3 ); 
	remove_action( 'wp_head',   'rsd_link' ); 
	remove_action( 'wp_head',   'wlwmanifest_link' ); 
	remove_action( 'wp_head',   'index_rel_link' ); 
	remove_action( 'wp_head',   'start_post_rel_link', 10, 0 ); 
	remove_action( 'wp_head',   'wp_generator' ); 
}

function shoppingbox_theme_support() {
return "您的主题已经支持购物盒子插件，您可以直接使用";
}

function _the_menu($location = "nav")
{
	echo str_replace("</ul></div>", "", preg_replace("/<div[^>]*><ul[^>]*>/", "", wp_nav_menu(array("theme_location" => $location, "echo" => false))));
}


//隐藏admin Bar
function hide_admin_bar($flag) {
return false;
}
add_filter('show_admin_bar','hide_admin_bar');

//侧栏，摘要支持短代码
add_filter('the_excerpt','do_shortcode');
add_filter('widget_text', 'do_shortcode');

/*文件引用*/
function hui_moloader($name = '', $apply = true) {
    if (!function_exists($name)) {
        include MOD_URI . '/' . $name . '.php';
    }

    if ($apply && function_exists($name)) {
        $name();
    }
}

function hui_moloader2($name = '', $apply = true) {
    if (!function_exists($name)) {
        include THEME_FILES . '/' . $name . '.php';
    }

    if ($apply && function_exists($name)) {
        $name();
    }
}

//禁用p br
function disable_autop() {
    global $post;
    $disable_autop_var = get_post_meta($post->ID, 'disable_autop', TRUE);
        if ( !empty( $disable_autop_var ) ) {
        remove_filter('the_content', 'wpautop');
        }
    }
add_action ('loop_start', 'disable_autop');

// 非管理员不允许进入后台
if (_hui('no_admin')) {
	if ( is_admin() && ( !defined( 'DOING_AJAX' ) || !DOING_AJAX ) ) {
	  $current_user = wp_get_current_user();
	  if($current_user->roles[0] == get_option('default_role')) {
		  if(_hui('user_url')){
			  wp_safe_redirect( get_permalink( _hui('user_url') ) );
		  }else{
			  wp_safe_redirect( home_url() );
		  }
	    exit();
	  }
	}
}

//自定义截断函数
function qq_strimwidth($str ,$start , $width ,$trimmarker ){
$output = preg_replace('/^(?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){0,'.$start.'}((?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){0,'.$width.'}).*/s','\1',$str);
return $output.$trimmarker;
}

//主题设置跳转
if (is_admin() && $_GET['activated'] == 'true') {
    header("Location: themes.php?page=options-ui");
}

// 用户文章
function num_of_author_posts($authorID=''){
    if ($authorID) {
        $author_query = new WP_Query( 'posts_per_page=-1&author='.$authorID );
        $i=0;
        while ($author_query->have_posts()) : $author_query->the_post(); ++$i; endwhile; wp_reset_postdata();
        return $i;
    }
    return false;
}

/*新窗口打开*/
function hui_target_blank(){
    return 'target="_blank"';
}

/* 
 * custom code
 * ====================================================
*/
add_action('wp_head', 'hui_wp_head');
function hui_wp_head() { 
    if( _hui('site_keywords_description_s') ){
        hui_keywords();
        hui_description();
    }
    if( _hui('headcode') ) echo "<!--ADD_CODE_HEADER_START-->\n"._hui('headcode')."\n<!--ADD_CODE_HEADER_END-->\n";
}

add_action('wp_footer', 'hui_wp_footer');
function hui_wp_footer() { 
    if( _hui('footcode') ) echo "<!--ADD_CODE_FOOTER_START-->\n"._hui('footcode')."\n<!--ADD_CODE_FOOTER_END-->\n";
}

if (function_exists('register_nav_menus')){
		register_nav_menus( array(
			'nav' => __('网站导航'),
			'pagemenu' => __('页面导航')
		));
}

/* 
 * keywords
 * ====================================================
*/
function hui_keywords() {
  global $s, $post;
  $keywords = '';
  if ( is_single() ) {
    if ( get_the_tags( $post->ID ) ) {
      foreach ( get_the_tags( $post->ID ) as $tag ) $keywords .= $tag->name . ', ';
    }
    foreach ( get_the_category( $post->ID ) as $category ) $keywords .= $category->cat_name . ', ';
    if( _hui('post_keywords_description_s') ) {
        $the = trim(get_post_meta($post->ID, 'keywords', true));
        if( $the ) $keywords = $the;
    }else{
        $keywords = substr_replace( $keywords , '' , -2);
    }
    
  } elseif ( is_home () )    { $keywords = _hui('keywords');
  } elseif ( is_tag() )      { $keywords = single_tag_title('', false);
  } elseif ( is_category() ) { $keywords = single_cat_title('', false);
  } elseif ( is_search() )   { $keywords = esc_html( $s, 1 );
  } else { $keywords = trim( wp_title('', false) );
  }
  if ( $keywords ) {
    echo "<meta name=\"keywords\" content=\"$keywords\">\n";
  }
}


/* 
 * description
 * ====================================================
*/
function hui_description() {
  global $s, $post;
  $description = '';
  $blog_name = get_bloginfo('name');
  if ( is_singular() ) {
    if( !empty( $post->post_excerpt ) ) {
      $text = $post->post_excerpt;
    } else {
      $text = $post->post_content;
    }
    $description = trim( str_replace( array( "\r\n", "\r", "\n", "　", " "), " ", str_replace( "\"", "'", strip_tags( $text ) ) ) );
    if ( !( $description ) ) $description = $blog_name . "-" . trim( wp_title('', false) );
    if( _hui('post_keywords_description_s') ) {
        $the = trim(get_post_meta($post->ID, 'description', true));
        if( $the ) $description = $the;
    }
  } elseif ( is_home () )    { $description = _hui('description');
  } elseif ( is_tag() )      { $description = $blog_name . "'" . single_tag_title('', false) . "'";
  } elseif ( is_category() ) { $description = trim(strip_tags(category_description()));
  } elseif ( is_archive() )  { $description = $blog_name . "'" . trim( wp_title('', false) ) . "'";
  } elseif ( is_search() )   { $description = $blog_name . ": '" . esc_html( $s, 1 ) . "' ".__('的搜索結果', 'haoui');
  } else { $description = $blog_name . "'" . trim( wp_title('', false) ) . "'";
  }
  $description = mb_substr( $description, 0, 80, 'utf-8' );
  echo "<meta name=\"description\" content=\"$description\">\n";
}


add_theme_support( 'post-formats', array( 'aside', 'image', 'audio', 'gallery', 'link' ) );

function rename_post_formats( $safe_text ) {
if ( $safe_text == '日志' )
return '无图样式';
if ( $safe_text == '图像' )
return '多图样式';
if ( $safe_text == '音频' )
return '音频样式';
if ( $safe_text == '相册' )
return '幻灯样式';
if ( $safe_text == '链接' )
return '心情样式';
return $safe_text;
}
add_filter( 'esc_html', 'rename_post_formats' );

/*特色图像*/
add_theme_support( 'post-thumbnails' );

// 精简 wp_head & 去除无用函数 & 半角转全角
remove_action('wp_head','feed_links',2);
remove_action('wp_head','feed_links_extra',3);
remove_action('wp_head','rsd_link' );
remove_action('wp_head','wlwmanifest_link' );
remove_action('wp_head','adjacent_posts_rel_link_wp_head',10,0);
remove_action('wp_head','wp_generator');
remove_action('wp_head', 'wp_shortlink_wp_head',10,0 );
remove_filter('the_content','capital_P_dangit',11);
remove_filter('the_title','capital_P_dangit',11);
remove_filter('wp_title','capital_P_dangit',11);
remove_filter('comment_text','capital_P_dangit',31);
remove_filter('the_content', 'wptexturize');

//禁止加载WP自带的jquery.js
if ( !is_admin() ) { // 后台不禁止
function my_init_method() {
wp_deregister_script( 'jquery' ); // 取消原有的 jquery 定义
}
add_action('init', 'my_init_method'); 
}
wp_deregister_script( 'l10n' );

function qq_scripts_styles() {
	wp_enqueue_style( 'bcss', get_template_directory_uri() . '/css/b.css', array(), '3.3.0', 'screen' );
	wp_enqueue_style( 'qq-style', get_template_directory_uri() . '/style.css', array(), '4.1', 'all' );
	if ( !is_admin() ) {
	wp_enqueue_script( 'jquerymin', get_template_directory_uri() . '/js/jquery.min.js', array(), '2.0.0', false);
	}
	wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/js/bootstrap.min.js', array(), '3.3.0', false);
	wp_enqueue_script( 'lazyload' , get_template_directory_uri() . '/js/lazyload.min.js', array(), '1.9.0', true);
	if( _hui('qq_ajax_q') ){
	wp_enqueue_script( 'ajax', get_template_directory_uri() . '/js/main.js', array(), '1.0', true);
	}
	wp_enqueue_script( 'mousewheel', get_template_directory_uri() . '/js/mousewheel.js', array(), '1.0.0', true);
	wp_enqueue_script( 'scrollbar', get_template_directory_uri() . '/js/scrollbar.js', array(), '1.0.0', true);
	wp_enqueue_script( 'player', get_template_directory_uri() . '/js/player.js', array(), '1.0.0', true);
	wp_enqueue_script( 'index', get_template_directory_uri() . '/js/index.js', array(), '1.0.0', true);
	wp_enqueue_script( 'base', get_template_directory_uri() . '/js/ajax-comment.js', array(), '1.0.0', true);
	
	$url = home_url("/");
	$ajaxurl= admin_url("admin-ajax.php");
	$title = get_bloginfo('name');
	global $post;
	$postid = $post->ID;
	if ( wp_is_mobile() ){
		wp_localize_script( 'index', 'qq' ,array("is_mobile" => 1, "ajaxurl" => $ajaxurl,"url" => $url,"ajax_site_title" => $title,"postid" => $postid ));
	}else{
		wp_localize_script( 'index', 'qq' ,array("is_mobile" => 0, "ajaxurl" => $ajaxurl,"url" => $url,"ajax_site_title" => $title,"postid" => $postid ));
	}
	
	$object = array();
	$object['redirecturl'] = tin_get_current_page_url();
	$object['ajaxurl'] = admin_url( '/admin-ajax.php' );
	$object['loadingmessage'] = '正在请求中，请稍等...';
	wp_localize_script( 'index', 'ajax_sign_object' ,$object);
}
add_action( 'wp_enqueue_scripts', 'qq_scripts_styles' );

add_action('wp_head', 'qq_wp_head');
function qq_wp_head() { 
    hui_head_css();
}

/** widgets */
if (function_exists('register_sidebar')){
	register_sidebar(array(
		'name'          => '全站侧栏',
		'id'            => 'widget_sitesidebar',
		'before_widget' => '<section class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget_tit">',
		'after_title'   => '</h3>'
	));
	register_sidebar(array(
		'name'          => '文章页侧栏',
		'id'            => 'widget_postsidebar',
		'before_widget' => '<section class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget_tit">',
		'after_title'   => '</h3>'
	));
	register_sidebar(array(
		'name'          => '页面侧栏',
		'id'            => 'widget_pagesidebar',
		'before_widget' => '<section class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget_tit">',
		'after_title'   => '</h3>'
	));
}

/*update checker*/
require 'theme-updates/theme-update-checker.php';
$example_update_checker = new ThemeUpdateChecker(
	'QQ',
	''.base64_decode('aHR0cDovL2F6ZmFzaGFvLmNvbS91cGRhdGUvcXEuanNvbg==').''
);

function password_protected_change( $content ) {
    global $post;
	$label = 'pwbox-'.( empty( $post->ID ) ? rand() : $post->ID);
    if ( ! empty( $post->post_password ) && stripslashes( $_COOKIE['wp-postpass_'.COOKIEHASH] ) != $post->post_password ) {
        $output = '
 
        <form action="' . get_option('siteurl') . '/wp-login.php?action=postpass" method="post" class="form-inline" style="text-align: center;">
            <p>'.__( "这是一篇受密码保护的文章，您需要提供访问密码：" ).'</p>
			<div class="input-group">
				<input id="'.$label.'" class="form-control" name="post_password" type="password" size="20" placeholder="密码" />
				<span class="input-group-btn">
					<button class="btn btn-primary" id="search-btn" type="submit" name="Submit"><i class="fa fa-check" aria-hidden="true"></i></button>
				</span>
			</div>
        </form>
 
        ';
        return $output;
    } else {
        return $content;
    }
}
add_filter( 'the_password_form','password_protected_change' );

//登录界面
function diy_login_page() {
	echo '<link rel="stylesheet" href="'.get_template_directory_uri().'/css/login.css" type="text/css" media="all" />' . "\n";
	echo '<script src="'.get_template_directory_uri().'/js/jquery.min.js"></script>' . "\n";
	echo '<script type="text/javascript">var themeurl="'.get_bloginfo('template_directory').'"; homeurl="'.get_bloginfo('url').'";</script>';
	echo '<script src="'.get_template_directory_uri().'/js/login.js"></script>' . "\n";
 }
add_action( 'login_enqueue_scripts', 'diy_login_page' );

function logo_url(){
	if(_hui('blog_logo')){
		echo '<style>.login h1 a{background-image: url('. _hui('blog_logo') .');}</style>';
	}else{
		echo '<style>.login h1 a{background-image: url('. get_template_directory_uri() .'/images/logo.jpg);}</style>';
	}
}
add_action( 'login_head', 'logo_url' );

/* 获取当前页面url
/* ---------------- */
function tin_get_current_page_url(){
	global $wp;
	return get_option( 'permalink_structure' ) == '' ? add_query_arg( $wp->query_string, '', home_url( $wp->request ) ) : home_url( add_query_arg( array(), $wp->request ) );
}

function tin_get_current_page_url2(){
$ssl = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') ? true:false;
$sp = strtolower($_SERVER['SERVER_PROTOCOL']);
$protocol = substr($sp, 0, strpos($sp, '/')) . (($ssl) ? 's' : '');
$port = $_SERVER['SERVER_PORT'];
$port = ((!$ssl && $port=='80') || ($ssl && $port=='443')) ? '' : ':'.$port;
$host = isset($_SERVER['HTTP_X_FORWARDED_HOST']) ? $_SERVER['HTTP_X_FORWARDED_HOST'] : isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : $_SERVER['SERVER_NAME'];
 return $protocol . '://' . $host . $port . $_SERVER['REQUEST_URI'];
}

/* AJAX登录验证
/* ------------- */
function tin_ajax_login(){
	$result	= array('loggedin'=>0,'message'=>'');
	if(isset($_POST['security']) /*&& wp_verify_nonce( $_POST['security'], 'security_nonce' )*/ ){
		$creds = array();
		$creds['user_login'] = $_POST['username'];
		$creds['user_password'] = $_POST['password'];
		$creds['remember'] = ( isset( $_POST['remember'] ) ) ? $_POST['remember'] : false;
		$login = wp_signon($creds, false);
		if ( ! is_wp_error( $login ) ){
			$result['loggedin']	= 1;
			$result['message'] = '<span style="color:#00c3b6">登录成功！即将为你刷新</span>';
		}else{
			$result['message']	= ( $login->errors ) ? strip_tags( $login->get_error_message() ) : '<strong>ERROR</strong>: ' . esc_html__( '请输入正确用户名和密码以登录', 'tinection' );
		}
	}else{
		$result['message'] = __('安全认证失败，请重试！','tinection');
	}
	header( 'content-type: application/json; charset=utf-8' );
	echo json_encode( $result );
	exit;
	
}
add_action( 'wp_ajax_ajaxlogin', 'tin_ajax_login' );
add_action( 'wp_ajax_nopriv_ajaxlogin', 'tin_ajax_login' );

/* AJAX注册验证
/* ------------- */
function tin_ajax_register()
{
    $result = array();
    if (isset($_POST['security']) && wp_verify_nonce($_POST['security'], 'user_security_nonce')) {
        $user_login = sanitize_user($_POST['username']);
        $user_pass = $_POST['password'];
        $user_email = apply_filters('user_registration_email', $_POST['email']);
        $errors = new WP_Error();
        if (!validate_username($user_login)) {
            $errors->add('invalid_username', __('请输入一个有效用户名', 'tinection'));
        } elseif (username_exists($user_login)) {
            $errors->add('username_exists', __('此用户名已被注册', 'tinection'));
        } elseif (email_exists($user_email)) {
            $errors->add('email_exists', __('此邮箱已被注册', 'tinection'));
        }
        do_action('register_post', $user_login, $user_email, $errors);
        $errors = apply_filters('registration_errors', $errors, $user_login, $user_email);
        if ($errors->get_error_code()) {
            $result['success'] = 0;
            $result['message'] = $errors->get_error_message();
        } else {
            $user_id = wp_create_user($user_login, $user_pass, $user_email);
            if (!$user_id) {
                $errors->add('registerfail', sprintf(__('无法注册，请联系管理员', 'tinection'), get_option('admin_email')));
                $result['success'] = 0;
                $result['message'] = $errors->get_error_message();
            } else {
                update_user_option($user_id, 'default_password_nag', true, true);
                //Set up the Password change nag.
                wp_new_user_notification($user_id, $user_pass);
                $result['success'] = 1;
                $result['message'] = esc_html__('注册成功', 'tinection');
                //自动登录
                wp_set_current_user($user_id);
                wp_set_auth_cookie($user_id);
                $result['loggedin'] = 1;
            }
        }
    } else {
        $result['message'] = __('安全认证失败，请重试！', 'tinection');
    }
    header('content-type: application/json; charset=utf-8');
    echo json_encode($result);
    die;
}
add_action( 'wp_ajax_ajaxregister', 'tin_ajax_register' );
add_action( 'wp_ajax_nopriv_ajaxregister', 'tin_ajax_register' );

/* 新用户注册提醒
/* --------------- */
function tin_new_user_notification($user_id, $plaintext_pass = '') {
	$user = get_userdata( $user_id );
	$blogname = wp_specialchars_decode(get_option('blogname'), ENT_QUOTES);
	$message  = sprintf(__('您的站点「%s」有新用户注册 :'), $blogname) . "<br></br>";
	$message .= sprintf(__('用户名: %s'), $user->user_login) . "<br>";
	$message .= sprintf(__('E-mail: %s'), $user->user_email) . "<br>";
	@tin_basic_mail('',get_option('admin_email'),sprintf(__('[%s] 有新用户注册'), $blogname),$message);
	if ( empty($plaintext_pass) )
		return;
	$message  = sprintf(__('用户名: %s'), $user->user_login) . "<br>";
	$message .= sprintf(__('密码: %s'), $plaintext_pass) . "<br>";
	$message .= tin_get_user_url('profile',$user->ID) . "<br>";
	@tin_basic_mail('',$user->user_email,sprintf(__('[%s] 您的注册用户名和密码'), $blogname),$message);
}

/*热门文章*/
function latest_article($post_num = 10){
	$args = array( 
		'post_password' => '', 
		'post_status' => 'publish', // 只选公开的文章. 
		'post__not_in' => array($post->ID),//排除当前文章 
		'caller_get_posts' => 1, // 排除置顶文章. 
		'orderby' => 'comment_count', // 依评论数排序. 
		'posts_per_page' => $post_num 
	); 
	$query_posts = new WP_Query(); 
	$query_posts->query($args);
	while( $query_posts->have_posts() ) { $query_posts->the_post();
		echo'<li id="accordion"><a href="'.get_the_permalink().'" title="'.get_the_title().'"><i class="fa fa-caret-right"></i>'.get_the_title().'</a></li>';
	} wp_reset_query();
}

/*最新评论*/
function recent_comments($limit_number=10){
	$limit = $limit_number;
	$my_email = get_bloginfo( 'admin_email' );
	$rc_comms = get_comments( array('status' => 'approve') );
	$output = '';
	$output = $pre_HTML;
	$output = '<ul>';
	foreach ($rc_comms as $rc_comm){
		$id = $rc_comm -> comment_ID;
		$name = $rc_comm ->comment_author;
		$email = $rc_comm -> comment_author_email;
		$content = $rc_comm -> comment_content;
		$date = $rc_comm -> comment_date;
		$avatar = str_replace(" src=", " data-src=", get_avatar($email, $size = "40"));
		if( $email != $my_email ){
			$output .='
				<li>
					<a href="' .esc_url( get_comment_link($id) ). '" title="' .$name. '在' .get_the_title($rc_comm->comment_post_ID) . '发表的评论">'.$avatar . '<span class="muted">'.$name.'</span><br />'.$rc_comm->comment_content.'</a>
				</li>
			';
			$limit -= 1;
		}
		if ( $limit <= 0 ) break;
	}
	$output .= $post_HTML;
	$output .= '</ul>';
	echo $output;
}

/* 
 * post copyright
 * ====================================================
*/
if( _hui('post_copyright_s') ){
    add_filter('the_content','hui_copyright');
}    
function hui_copyright($content) {
    // $content .= '<p>'.(_hui('post_from_s')?hui_get_post_from():'').'</p>'; 
    if( is_single() ){
        $content.= '<div class="single-copyright"><i class="fa fa-warning"></i>'._hui('post_copyright').'：<a href="'.get_bloginfo('url').'">'.get_bloginfo('name').'</a> &raquo; <a href="'.get_permalink().'">'.get_the_title().'</a></div>';
    }
    return $content;
}


/*热门标签*/
function fs_widget_tag($count = null)
	{
		echo "<div class=\"items\">";
		$tags_list = get_tags("orderby=count&order=DESC&number=" . $count . "");

		if ($tags_list) {
			foreach ($tags_list as $tag ) {
				$tagname = $tag->name;
				echo '<div class="tags-list">';
				echo '<div class="tags-icon pull-left">'.ucfirst(mb_substr($tagname, 0, 1, 'utf-8')).'</div>';
				echo '<div class="tags-con">';
				echo '<h3><a href="' . get_tag_link($tag) . '">' . $tagname . '</a></h3>';
				echo '<p>'. $tag->count .' 篇文章</p>';
				echo '</div>';
				echo '</div>';
			}
		}
		else {
			echo "暂无标签！";
		}

		echo "</div>";
	}
	
add_action('wp_ajax_nopriv_ajax_post_content', 'ajax_post_content');
add_action('wp_ajax_ajax_post_content', 'ajax_post_content');
function ajax_post_content(){
    $args = array(
        'p' => $_POST["id"]
    );
    $the_query = new WP_Query( $args );
    if ( $the_query->have_posts() ) : while ( $the_query->have_posts() ) : $the_query->the_post();
        the_content();
    endwhile;endif;
    die;
}


//分页
if ( !function_exists('pagenavi') ) { 
    function pagenavi( $p = 2 ) { // 取当前页前后各 2 页 
        if ( is_singular() ) return; // 文章与插页不用 
        global $wp_query, $paged; 
        $max_page = $wp_query->max_num_pages; 
        if ( $max_page == 1 ) return; // 只有一页不用 
        if ( empty( $paged ) ) $paged = 1; 
        if ( $paged > $p + 1 ) p_link( 1, '最前页', '«'); 
		if ( $paged > 1 ) p_link( $paged - 1, '上一页', '‹' );/* 如果当前页大于1就显示上一页链接 */ 
        if ( $paged > $p + 2 ) echo '... '; 
        for( $i = $paged - $p; $i <= $paged + $p; $i++ ) { // 中间页 
            if ( $i > 0 && $i <= $max_page ) $i == $paged ? print "<a id='text-indent' class='current'>{$i}</a> " : p_link( $i ); 
        } 
        if ( $paged < $max_page - $p - 1 ) echo '<a id="text-indent">...</a>'; 
        if ( $paged < $max_page ) p_link( $paged + 1,'下一页', '›' );/* 如果当前页不是最后一页显示下一页链接 */ 
        if ( $paged < $max_page - $p ) p_link( $max_page, '最后页', '»' ); 
		} 
    function p_link( $i, $title = '', $linktype = '' ) { 
        if ( $title == '' ) $title = "第 {$i} 页"; 
        if ( $linktype == '' ) { $linktext = $i; } else { $linktext = $linktype; } 
        echo "<a id='text-indent' href='", esc_html( get_pagenum_link( $i ) ), "' title='{$title}'>{$linktext}</a> "; 
    } 
}

//获取gravatar地址
function qq_get_avatar_url($get_avatar){
    preg_match("/src='(.*?)'/i", $get_avatar, $matches);
    return $matches[1];
}

//自定义评论结构
function commentlist($comment, $args, $depth) {
    $GLOBALS['comment'] = $comment;
    global $commentcount,$insertAD;;
    if(!$commentcount) {
        $page = ( !empty($in_comment_loop) ) ? get_query_var('cpage')-1 : get_page_of_comment( $comment->comment_ID, $args )-1;
        $cpp=get_option('comments_per_page');
        $commentcount = $cpp * $page;
    }
?>
    <li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
    <?php if( !$parent_id = $comment->comment_parent){ ?>
        <article id="comment-<?php comment_ID(); ?>" class="comment-body comment-body-parent">
            <div class="comment-author"><?php echo get_avatar ( $comment->comment_author_email, 48 ); ?></div>
            <div class="comment-content">
                <div class="comment-entry">
                    <span class="name author"><?php printf(__('%s'), get_comment_author_link()) ?></span>
					<?php if($comment->user_id == 1) echo "<span class='comment_admin'>官方</span>"; ?>
                    <section><?php comment_text() ?></section>
                    <span class="floor"><?php ++$commentcount;echo "#".$commentcount;++$insertAD;?></span>
                </div>
                <div class="comment-head">
                    <span class="date"><time datetime="<?php comment_date('Y-m-d'); ?>"><?php if(!$parent_id = $comment->comment_parent) {echo timeago( $comment->comment_date_gmt );} ?></time></span>
                    <?php comment_reply_link(array_merge( $args, array('reply_text' => '回复','depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
                </div>
            </div>
        </article>
    <?php } else { ?>
        <article id="comment-<?php comment_ID(); ?>" class="comment-body">
            <div class="comment-author"><?php echo get_avatar ( $comment->comment_author_email, 32 ); ?></div>
            <div class="comment-content">
                <div class="comment-entry">
                    <span class="name author"><?php printf(__('%s'), get_comment_author_link()) ?></span>
					<?php if($comment->user_id == 1) echo "<span class='comment_admin'>官方</span>"; ?>
					<?php comment_reply_link(array_merge( $args, array('reply_text' => '回复','depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
                    <div><?php comment_text() ?></div>
                </div>
            </div> 
        </article>
    <?php } ;?>
<?php
}

// @父评论
add_filter('comment_text','comment_add_at_parent');
function comment_add_at_parent($comment_text){
    $comment_ID = get_comment_ID();
    $comment = get_comment($comment_ID);
    if ($comment->comment_parent ) {
        $parent_comment = get_comment($comment->comment_parent);
        $comment_text = '<a href="#comment-' . $comment->comment_parent . '">@'.$parent_comment->comment_author.'</a> ' . $comment_text;
    }
    return $comment_text;
}


//评论贴图片地址自动转化为图片
define('ALLOW_POSTS', '');
function comment_image( $comment ) {
    $post_ID = $comment["comment_post_ID"];
    $allow_posts = ALLOW_POSTS ? explode(',', ALLOW_POSTS) : array();
    if(in_array($post_ID,$allow_posts) || empty($allow_posts) ){
        global $allowedtags;
        $content = $comment["comment_content"];
        $content = preg_replace('/(https?:\/\/\S+\.(?:jpg|png|jpeg|gif))+/','$0',$content);
        $allowedtags['img'] = array('src' => array (), 'alt' => array ());
        $comment["comment_content"] = $content;
    }
    return $comment;
}
add_filter('preprocess_comment', 'comment_image');

//按顺序输出表情
function fs_output_smilies() {
	echo'<ul class="inline-ul">';
	for ($x=1; $x<=50; $x++) {
		echo '<li class="inline-li"><a href="javascript:;" class="smilie smilie-f'.$x.'" data-surl="'.get_bloginfo('template_directory').'/images/smilies/f'.$x.'.png"><img src="'.get_bloginfo('template_directory').'/images/smilies/f'.$x.'.png"></a></li>';
	}
	echo'</ul>';
}


//让文章内容和评论支持emoji并去除emoji加载的乱七八糟的脚本
function reset_emojis() {
	remove_action('wp_head', 'print_emoji_detection_script', 7);
	remove_action('admin_print_scripts', 'print_emoji_detection_script');
	remove_action('wp_print_styles', 'print_emoji_styles');
	remove_action('admin_print_styles', 'print_emoji_styles');
}
add_action('init', 'reset_emojis');

// 评论链接跳转&新窗口打开
function add_redirect_comment_link($text = ''){
    $text = preg_replace('/<a (.+?)>/i', "<a $1 target='_blank'>", $text);
    return $text;
}
function redirect_comment_link(){
    $redirect = $_GET['r'];
    if($redirect){
        if(strpos($_SERVER['HTTP_REFERER'],get_option('home')) !== false){
            header("Location: $redirect");
            exit;
        }
        else {
            header("Location: ".bloginfo('url')."/");
            exit;
        }
    }
}
add_action('init', 'redirect_comment_link');
add_filter('get_comment_author_link', 'add_redirect_comment_link', 5);


/*浏览量统计*/
function qq_set_post_views($postID) {
    $the_ID = "arc".$postID;
    if(isset($_SESSION[$the_ID]) || $_SESSION[$the_ID] == 1)
    return;
    $_SESSION[$the_ID] = 1;
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '1');
    }else{
        //administrator的浏览量不统计
        if(!current_user_can("administrator")){
            $count++;
            update_post_meta($postID, $count_key, $count);
        }
    }
}
function qq_get_post_views($postID){
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return "0";
    }
    return $count;
}

function lo_all_view()
{
    global $wpdb;
    $count = 0;
    $views = $wpdb->get_results("SELECT * FROM {$wpdb->postmeta} WHERE meta_key='post_views_count'");
    foreach ($views as $key => $value) {
        $meta_value = $value->meta_value;
        if ($meta_value != ' ') {
            $count += (int) $meta_value;
        }
    }
    return $count;
}

//邮件通知
function comment_mail_notify($comment_id)
{
    $comment = get_comment($comment_id);
    $parent_id = $comment->comment_parent ? $comment->comment_parent : '';
    $spam_confirmed = $comment->comment_approved;
    $message = convert_smilies($message);
    if ($parent_id != '' && $spam_confirmed != 'spam') {
        $wp_email = 'notice@' . preg_replace('#^www\\.#', '', strtolower($_SERVER['SERVER_NAME']));
        //e-mail 發出點, no-reply 可改為可用的 e-mail.
        $to = trim(get_comment($parent_id)->comment_author_email);
        $subject = '你在 [' . get_option('blogname') . '] 的留言有了新回复';
        $message = '
					<div style="background:#f8f8f8;color: #666;font-size:12px;">
						<div style="width: 570px;margin:0 auto;background:#fff;padding:25px 70px;border-top: 5px solid #299982;">
							<div style="text-align:center;margin-bottom: 40px;line-height: 1.8em;">
								<h1 style="color:#333;">' . get_option('blogname') . '</h1>
								<p style="text-indent: 1.3em;">没有任何事情比你更重要 </p>
							</div>
						<p style="font-size:18px;color: #333;">你好 ' . trim(get_comment($parent_id)->comment_author) . '</p>
						<p>您曾在 [' . get_option('blogname') . '] 的文章
						《' . get_the_title($comment->comment_post_ID) . '》 上发表评论:
						<p style="border: 1px solid #eee;padding: 20px;margin: 15px 0;">' . nl2br(get_comment($parent_id)->comment_content) . '</p>
						<p>' . trim($comment->comment_author) . ' 给您的回复如下:
						<p style="border: 1px solid #eee;padding: 20px;margin: 15px 0;">' . nl2br($comment->comment_content) . '</p>
						<p class="footer" style="text-align:center;border-top: 1px solid #DDDDDD; padding-top:6px; margin-top:15px; color:#838383;">你可以点击此链接 <a href="' . htmlspecialchars(get_comment_link($parent_id)) . '">查看完整内容</a> | 欢迎再次来访<a href="' . home_url() . '">' . get_option('blogname') . '</a></p>

						<p style="font-size:18px;color:#333;text-align:center;margin-top:40px;">阳光很好，爱在发烧</p>
						<p style="text-align:center;"><img style="text-align:center;" src="http://url.cn/Vo8oiy" /></p>

						<a style="display:block;width:560px;height:40px;background: #299982;margin: 25px auto 40px;font-size:16px;line-height:40px;letter-spacing:3px;color:#ffffff;text-align:center;text-decoration:none;" href="' . get_option('home') . '" target="_blank">发现更多精彩»</a>
						<div style="height:118px;text-align:center;color:#999;border-top: 1px solid #ddd;padding-top: 15px;">
						<div style="float:left;height:115px;width:279px;border-right:1px solid #ddd;">
						<p style="margin:0 0 18px;line-height:14px;">关于博主</p>
						<p style="margin:0 auto;width:200px;text-align:left;">
							他喜欢抽烟，这不是装酷，这仅是一种习惯。他喜欢折腾，不仅仅是博客。</p>
						</div>
						<div style="float:left;width:280px;">
						<p style="margin:0 0 18px;line-height:14px;">关于本站</p>
						<p style="margin:0 auto;text-align: left;width:200px;">
							简单的博客，简单的人，分享音乐，分享心情，分享主题，分享爱~
						</p>
						</div>
						</div>

						<p style="text-align: center;color: #bbb;margin-top: 40px;">请不要回复该邮件。你收到它，是因为你曾经在' . get_option('blogname') . '留言过，这是博主送给你的鲜花。</p>
						</div>
					</div>';
        $message = convert_smilies($message);
        $from = 'From: "' . get_option('blogname') . "\" <{$wp_email}>";
        $headers = "{$from}\nContent-Type: text/html; charset=" . get_option('blog_charset') . '
';
        wp_mail($to, $subject, $message, $headers);
    }
}
add_action('comment_post', 'comment_mail_notify');

//修改默认发信地址
add_filter('wp_mail_from', 'qq_res_from_email');
function qq_res_from_email($email) {
	$wp_from_email = get_option('admin_email');
	return $wp_from_email;
}
add_filter('wp_mail_from_name', 'qq_res_from_name');
function qq_res_from_name($email){
	$wp_from_name = get_option('blogname');
	return $wp_from_name;
}

/*检查头像*/
function qq_get_cavatar() {
$email = get_option('admin_email');// 博主邮箱 
$hash = md5(strtolower(trim($email)));   
$uri = 'http://cn.gravatar.com/avatar/' . $hash . '?d=404';   
$headers = @get_headers($uri);   
if (!preg_match("|200|", $headers[0])) {   
	echo '<img src="'.get_bloginfo('template_directory').'/images/logo.jpg" >';
}else {
	echo get_avatar($email, 80);//数字代表头像尺寸
}  
}

add_filter('e_avatar','qq_get_cavatar');

/* 获取文章中的图片个数 （使用在文章列表主循环中、或文章页中）*/
if( !function_exists('get_post_images_number') ){
	function get_post_images_number(){
	    global $post;
	    $content = $post->post_content;  
	    preg_match_all('/<img.*?(?: |\\t|\\r|\\n)?src=[\'"]?(.+?)[\'"]?(?:(?: |\\t|\\r|\\n)+.*?)?>/sim', $content, $result, PREG_PATTERN_ORDER);  
	    return count($result[1]);  
	}
}

/*获取文章全部图片 瀑布流*/
function all_img($soContent){
$soImages = '~<img [^\>]*\ />~'; //这段话的意思：获取文章里面的图片
preg_match_all( $soImages, $soContent, $thePics );
$allPics = count($thePics);//通过正则表达式判断是否存在图片
preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i',$soContent, $matches);
$cnt = count($matches[1]);// 获取文章里面的图片数量
if( $allPics > 0 && $cnt > 0){  // 判断2的原因是图片数量小于2的文章，不需要显示缩略图了
foreach($thePics[0] as $v){
if( $count == 200 ){break;}//当count等于xx的时候跳出循环  意思是获取xx张图片 
else {
$pattern ='<img.*?src="(.*?)">';
preg_match($pattern,$v,$matches);// 通过正则表达式获取图片里面的路径
echo '<div class="item"><span class="thumb-span">';
echo '<img src="'.$matches[1].'"/>';
echo '</span></div>';
}
$count++;//循环+1
}}
else {
$pattern ='<img.*?src="(.*?)">';
preg_match($pattern,$v,$matches);// 通过正则表达式获取图片里面的路径
echo '<img src="'.$matches[1].'"/>';
}}


function all_imgt($soContent){
$soImages = '~<img [^\>]*\ />~'; //这段话的意思：获取文章里面的图片
preg_match_all( $soImages, $soContent, $thePics );
$allPics = count($thePics);//通过正则表达式判断是否存在图片
preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i',$soContent, $matches);
$cnt = count($matches[1]);// 获取文章里面的图片数量
if( $allPics > 0 && $cnt > 0){  // 判断2的原因是图片数量小于2的文章，不需要显示缩略图了
$count=1;//赋予1的值
foreach($thePics[0] as $v){
if( $count == 7 ){break;}//当count等于12的时候跳出循环  意思是获取12张图片 
else {
$pattern ='<img.*?src="(.*?)">';
preg_match($pattern,$v,$matches);// 通过正则表达式获取图片里面的路径
echo '<div>';
echo '<img src="'.$matches[1].'"/>';
echo '</div>';
}
$count++;//循环+1
}}
else {
$pattern ='<img.*?src="(.*?)">';
preg_match($pattern,$v,$matches);// 通过正则表达式获取图片里面的路径
echo '<img src="'.$matches[1].'"/>';
}}

function post_thumbnail_src(){
    global $post;
	$custom = get_post_custom($post->ID);
	$post_url = $custom['post_url'][0];
    if( $post_url ) {   //输出自定义域图片地址
        $post_thumbnail_src = $post_url;
    } elseif( has_post_thumbnail() ){    //如果有特色缩略图，则输出缩略图地址
        $thumbnail_src = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
        $post_thumbnail_src = $thumbnail_src [0];
    } else {
        $post_thumbnail_src = '';
        ob_start();
        ob_end_clean();
        $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
        if(!empty($matches[1][0])){
            $post_thumbnail_src = $matches[1][0];   //获取该图片 src
        }elseif( _hui('qq_post_thumbnail') ){
            $post_thumbnail_src = _hui('qq_post_thumbnail');
        }else{  
            //如果日志中没有图片，则显示随机图片
            //$random = mt_rand(1, 5);
            //$post_thumbnail_src = get_template_directory_uri().'/img/random/'.$random.'.jpg';
            //如果日志中没有图片，则显示默认图片
            $post_thumbnail_src = get_template_directory_uri().'/images/tum.jpg';
        }
    }
    return $post_thumbnail_src;
} 

function _get_post_thumbnail($size = "thumbnail", $class = "thumb") {
	
    global $post;
	$custom = get_post_custom($post->ID);
	$post_url = $custom['post_url'][0];
	
	$html = "";
	
	if (has_post_thumbnail()) {
		$domsxe = get_the_post_thumbnail();
		preg_match_all("/<img.*?(?: |\\t|\\r|\\n)?src=['\"]?(.+?)['\"]?(?:(?: |\\t|\\r|\\n)+.*?)?>/sim", $domsxe, $strResult, PREG_PATTERN_ORDER);
		$images = $strResult[1];

		foreach ($images as $src ) {
			$html = sprintf("<img data-src=\"%s\" class=\"thumb\">", $src);
			break;
		}
	}elseif( $post_url ){
		$html = sprintf("<img data-src=\"%s\" class=\"%s\">", $post_url, $class);
	}
	else {
		$html = sprintf("<img data-src=\"%s\" class=\"%s\">", "http://url.cn/Tfhpen?.jpg", $class);
	}

	return $html;
}

function qq_get_thumbnail() {  
    global $post;
    $html = '';

    $content = $post->post_content;  
    preg_match_all('/<img.*?(?: |\\t|\\r|\\n)?src=[\'"]?(.+?)[\'"]?(?:(?: |\\t|\\r|\\n)+.*?)?>/sim', $content, $strResult, PREG_PATTERN_ORDER);  
    $images = $strResult[1];

    $counter = count($strResult[1]);

    if( !$counter ){
        return '<li>
                    <div class="image-item">
                        <a href="'.get_permalink(get_the_ID()).'">
                            <div class="overlay"></div>
                            <img src="'.post_thumbnail_src().'" alt="'.get_the_title().'">
                        </a>
                    </div>
                </li>
                <li>
                    <div class="image-item">
                        <a href="'.get_permalink(get_the_ID()).'">
                            <div class="overlay"></div>
                            <img src="'.post_thumbnail_src().'" alt="'.get_the_title().'">
                        </a>
                    </div>
                </li>
                <li>
                    <div class="image-item">
                        <a href="'.get_permalink(get_the_ID()).'">
                            <div class="overlay"></div>
                            <img src="'.post_thumbnail_src().'" alt="'.get_the_title().'">
                        </a>
                    </div>
                </li>';
    }
    $full_image_url = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'full');
    $ts_thum = $full_image_url[0];
    if($ts_thum){
        $num = 2;
        $html .= '<li>
                    <div class="image-item">
                        <a href="'.get_permalink(get_the_ID()).'">
                            <div class="overlay"></div>
                            <img src="'.$ts_thum.'" alt="'.get_the_title().'">
                        </a>
                    </div>
                </li>';
    }
    else{
        $num = 3;
    }

    $i = 0;
    foreach($images as $key=>$src){
        $i++;
        $src2 = wp_get_attachment_image_src(qq_get_attachment_id_from_src($src), 'full');
        $src2 = $src2[0];
        if( !$src2 && true ){
            $src = $src;
        }else{
            $src = $src2;
        }
        $item = '<img src="'.$src.'" alt="'.get_the_title().'">';
        $html .= '<li>
                    <div class="image-item">
                        <a href="'.get_permalink(get_the_ID()).'">
                            <div class="overlay"></div>
                            '.$item.'
                        </a>
                    </div>
                </li>';
        if( $counter >= $num && $i >= $num )
        {
            break; 
        }
    }

    if(count($images) < 3 && $ts_thum ){
        $j = 3 - count($images) - 1;
        for ($k=0; $k < $j ; $k++) { 
        $html .= '<li>
                    <div class="image-item">
                        <a href="'.get_permalink(get_the_ID()).'">
                            <div class="overlay"></div>
                            <img src="'.get_template_directory_uri().'/img/default_thumb.png" alt="'.get_the_title().'">
                        </a>
                    </div>
             </li>';
        }
    }
    if(count($images) < 3 && !$ts_thum ){
        $j = 3 - count($images);
         for ($k=0; $k < $j ; $k++) { 
        $html .= '<li>
                    <div class="image-item">
                        <a href="'.get_permalink(get_the_ID()).'">
                            <div class="overlay"></div>
                            <img src="'.get_template_directory_uri().'/img/default_thumb.png" alt="'.get_the_title().'">
                        </a>
                    </div>
                </li>';
        }
    }

    

    return $html;
}
function qq_get_attachment_id_from_src ($link) {
    global $wpdb;
    $link = preg_replace('/-\d+x\d+(?=\.(jpg|jpeg|png|gif)$)/i', '', $link);
    return $wpdb->get_var("SELECT ID FROM {$wpdb->posts} WHERE guid='$link'");
}

/* 
 * import style
 * ====================================================
*/
function hui_head_css() {

    $styles = '';

    $site_width = _hui('site_width');
    if( $site_width && $site_width !== '1280' ){
        $styles .= ".container{max-width:{$site_width}px}";
    }

    if( _hui('site_gray') ){
        $styles .= "html{overflow-y:scroll;filter:progid:DXImageTransform.Microsoft.BasicImage(grayscale=1);-webkit-filter: grayscale(100%);}";
    }

    if( _hui('theme_skin_custom') ){
        $skin_option = _hui('theme_skin_custom');
        $skc = $skin_option;
    }else{
        $skin_option = _hui('theme_skin');
        $skc = '#'.$skin_option;
    }
    
    if( $skin_option && $skin_option !== '159b76' ){
        $styles .= "a:hover,.hidden-sm:hover,.login-panel a:hover,.tabsa:hover i,.active a i,.active a i,.qq_lrc .current,.slick-dots li button:before,.paging a,article.post h2 a:hover,.edit:hover i,.edit:hover a,.post-related-title a,.list-current,#logo-music-name,.teamnewslist li:hover b,.close-comment,.reply-to-read a,#sign .switch i,#wenkmPlayer .player .control .loop:hover, #wenkmPlayer .player .control .next:hover, #wenkmPlayer .player .control .prev:hover,#wenkmPlayer .player .control .pause:hover,#wenkmPlayer .player .control .play:hover,#wenkmPlayer .player .musicbottom .switch-down .fa:hover,#wenkmPlayer .player .musicbottom .switch-playlist:hover,#wenkmPlayer.showAlbumList .switch-playlist,#wenkmPlayer .player .control i.current,#wenkmPlayer .player .control .random:hover,#wenkmPlayer .player .musicbottom .switch-ksclrc:hover,#cancel-comment-reply-link{color: {$skc};}
		#back-to-top #point-up path{fill: {$skc};}
		.teamnewslist li:hover b::after,#sign form input:focus,.comment-topnav a,.comment-topnav span{border-color: {$skc};}
		.form-wrapper button:before{border-color: transparent {$skc};}
		.m-header,.post-head,.p-header,.s-header,.main-nav .current-menu-item a, .current-menu-parent a, .current-menu-ancestor a,.paging a:hover,.paging .current,.widget_calendar table tbody td a,.c-header,.btn-theme,.list-wrap span:hover,.list-pause,.list-play,::selection,.lrcplay,.btnn-inverse-primary,.container1>div,.container2>div,.container3>div,#wenkmPlayer .switch-player,#wenkmPlayer .player .musicbottom .volume .progress .volume-on,.slider .pace,.navbar-collapse .sub-menu,.form-wrapper .pbutton,#sign form .submit,#wenkmPlayer .playlist .list li.current,#top-slide-three .slider-content .slider-content-box .slider-content-item .post-categories a,.comment-navi .page-numbers:hover{background-color: {$skc}!important;}
		";
    }

    $styles .= _hui('csscode');

    if( $styles ) echo '<style>'.$styles.'</style>';
}

/*link*/
function get_the_link_items($id = null){
    $bookmarks = get_bookmarks('orderby=date&category=' .$id );
    $output = '';
    if ( !empty($bookmarks) ) {
        $output .= '<ul class="link-items fontSmooth">';
        foreach ($bookmarks as $bookmark) {
            $output .=  '<li class="link-item"><a class="link-item-inner effect-apollo" href="' . $bookmark->link_url . '" title="' . $bookmark->link_description . '" target="_blank" ><img class="avatar" src="'. $bookmark->link_image .'" /><span class="sitename">'. $bookmark->link_name .'</span></a></li>';
        }
        $output .= '</ul>';
    }
    return $output;
}

function get_link_items(){
    $linkcats = get_terms( 'link_category' );
    if ( !empty($linkcats) ) {
        foreach( $linkcats as $linkcat){            
            $result .=  '<blockquote>'.$linkcat->name.'</blockquote>';
            if( $linkcat->description ) $result .= '<div class="link-description">' . $linkcat->description . '</div>';
            $result .=  get_the_link_items($linkcat->term_id);
        }
    } else {
        $result = get_the_link_items();
    }
    return $result;
}

function shortcode_link(){
    return get_link_items();
}
add_shortcode('qqlink', 'shortcode_link');
add_filter( 'pre_option_link_manager_enabled', '__return_true' );

/* 404*/
function qq_404(){
    echo '<div class="e404"><img src="'.get_template_directory_uri().'/images/404.png"><h1>404 . Not Found</h1><p>'.__('抱歉！沒有找到你要的内容！', 'haoui').'</p></div>';
}

//时间显示方式'xx以前'
function timeago( $ptime ) {
    $ptime = strtotime($ptime);
    $etime = time() - $ptime;
    if ($etime < 1) return '刚刚';
    $interval = array (
        12 * 30 * 24 * 60 * 60  =>  '年前 ('.date('Y-m-d', $ptime).')',
        30 * 24 * 60 * 60       =>  '个月前 ('.date('m-d', $ptime).')',
        7 * 24 * 60 * 60        =>  '周前 ('.date('m-d', $ptime).')',
        24 * 60 * 60            =>  '天前',
        60 * 60                 =>  '小时前',
        60                      =>  '分钟前',
        1                       =>  '秒前'
    );
    foreach ($interval as $secs => $str) {
        $d = $etime / $secs;
        if ($d >= 1) {
            $r = round($d);
            return $r . $str;
        }
    };
}

//文章摘要
function qq_excerpt($text) {
	$text = preg_replace('/\<img.+?src="(.+?)".*?\/>/','',$text);
    return $text;
}
add_filter('the_excerpt', 'qq_excerpt');

//禁用Googlefont
if (!function_exists('remove_wp_open_sans')) :
    function remove_wp_open_sans() {
        wp_deregister_style( 'open-sans' );
        wp_register_style( 'open-sans', false );
    }
    add_action('wp_enqueue_scripts', 'remove_wp_open_sans');
 
    // Uncomment below to remove from admin
    // add_action('admin_enqueue_scripts', 'remove_wp_open_sans');
endif;

function remove_open_sans() {    
    wp_deregister_style( 'open-sans' );    
    wp_register_style( 'open-sans', false );    
    wp_enqueue_style('open-sans','');    
}    
add_action( 'init', 'remove_open_sans' );

function theme_get_avatar($avatar) {
    $avatar = str_replace(array("http://www.gravatar.com","http://0.gravatar.com","http://1.gravatar.com","http://2.gravatar.com"),"https://cn.gravatar.com",$avatar);
    return $avatar;
}
add_filter( 'get_avatar', 'theme_get_avatar', 10, 3);


/**
 * Display tags width hot tag.
 */
function get_hot_tag_list($count = null)
	{
		echo "<div class=\"items\">";
		$tags_list = get_tags("orderby=count&order=DESC&number=" . $count . "");

		if ($tags_list) {
			foreach ($tags_list as $tag ) {
				$tagname = $tag->name;
				echo '<div class="tags-list">';
				echo '<div class="tags-icon pull-left">'.ucfirst(mb_substr($tagname, 0, 1, 'utf-8')).'</div>';
				echo '<div class="tags-con">';
				echo '<h3><a href="' . get_tag_link($tag) . '">' . $tagname . '</a></h3>';
				echo '<p>'. $tag->count .' 篇文章</p>';
				echo '</div>';
				echo '</div>';
			}
		}
		else {
			echo "暂无标签！";
		}

		echo "</div>";
	}

/*cat*/
function get_hot_cat_list(){
	echo '<ul class="tagslist">';
		global $post;
			$tags_list = get_categories(array('type' => 'post', 'orderby' => 'name', 'order' => 'ASC'));
			if ($tags_list) { 
				foreach($tags_list as $tag) {
					echo '<li><a class="tagname" href="'.get_tag_link($tag).'">'. $tag->name .'</a><strong>x '. $tag->count .'</strong><br>'; 
					$posts = get_posts( "numberposts=1&category=". $tag->term_id );
					if( $posts ){
						foreach( $posts as $post ) {
							setup_postdata( $post );
							echo '<span class="muted">'.get_the_time('Y-m-d').'</span class="muted"><br><a href="'.get_permalink().'">'.get_the_title().'</a><br>';
						}
					}
					echo '</li>';
				} 
			}  
	echo '</ul>';
}

/*archive*/
function the_archives(){
	$the_query = new WP_Query( array( 'posts_per_page' => -1, 'ignore_sticky_posts ' => 1) );
	$year = 0;
	$month = 0;
	$day = 0;
	$date = array();
	echo '<div class="archives-fixed"><div id="archives">';
	//The Loop
	if ( $the_query->have_posts() ) {
		while ( $the_query->have_posts() ) {
			$the_query->the_post();
			$year_temp = get_the_time('Y');
			$month_temp = get_the_time('n');
			if ( $month != $month_temp && $month > 0 ) echo '</ul></div>';
			if ( $year != $year_temp ) {
				$year = $year_temp;
				$date[$year] =array();
			}
			if ( $month != $month_temp) {
				$month = $month_temp;
				array_push( $date[$year], $month );
				echo '<div class="archive-content" id="archive-'.$year.'-'.$month.'"><h4 class="h4 archive-month">' .get_the_time('Y年 m月'). '</h4><ul>';
			}
			echo '<li><span>' .get_the_time("d日"). '</span><a href="' .get_permalink(). '" >' .get_the_title(). '</a><span class="msg">&#40;' ; echo qq_get_post_views(get_the_ID()); echo' 阅读量&#41;</span></li>';
		}
	}else{
		echo '<div>none data.</div>';
	}
	wp_reset_postdata();
	echo '</ul></div></div>';
	
	//echo date-nav
	$output = '<div id="archive-nav"><div class="archive-nav"><span><i class="fa fa-calendar"></i>归档</span><ul>';
	$year_now = date("Y");
	foreach( $date as $key => $value ){
		$output .='<li class="one-year" id="'.$key.'"><ul><li class="year" id="year-'.$key.'">' .$key. '年</li>';
		foreach( $value as $item => $m ){
			$output .='<li class="month" id="m-'.$key.'-'.$m.'">' .$m. '月</li>';
		}
		$output .='</ul></li>';
	}
	$output .= '</ul></div></div></div>';
	
	echo $output; 
}

function show_category() {
    global $wpdb;
    $request = "SELECT $wpdb->terms.term_id, name FROM $wpdb->terms ";
    $request .= " LEFT JOIN $wpdb->term_taxonomy ON $wpdb->term_taxonomy.term_id = $wpdb->terms.term_id ";
    $request .= " WHERE $wpdb->term_taxonomy.taxonomy = 'category' ";
    $request .= " ORDER BY term_id asc";
    $categorys = $wpdb->get_results($request);
    echo '<div class="uk-panel uk-panel-box" style="margin-bottom: 20px;"><h3 style="margin-top: 0; margin-bottom: 15px; font-size: 18px; line-height: 24px; font-weight: 400; text-transform: none; color: #666;">可能会用到的分类ID</h3>';
    echo "<ul>";
    foreach ($categorys as $category) { 
        echo  '<li style="margin-right: 10px;float:left;">'.$category->name."（<code>".$category->term_id.'</code>）</li>';
    }
    echo "</ul></div>";
}
add_action('optionsframework_after','show_category', 100);

//end 到此结束，如果下方出现多余代码，说明你的wordpress已经被黑！

?>