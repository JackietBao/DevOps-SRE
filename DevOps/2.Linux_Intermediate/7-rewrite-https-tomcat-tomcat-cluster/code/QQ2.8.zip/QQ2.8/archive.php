<?php if ( $_POST['action'] != 'ajax_post' ) : ?>
<?php get_header(); ?>
<div id="m-container">
<?php endif; ?>
	<?php index_slider(); ?>
	<?php if( _hui('focus_s') ) hui_moloader('jiaodian'); ?>
	<div class="container containerall">
	<div class="main">
		<div id="content" class="index-single">
			<?php if( _hui('fengge') == 'jingdian_off' ) { ?>
				<?php if(_hui('qq_fengge')){ ?>
					<?php include(TEMPLATEPATH . '/function/post_header.php'); ?>
				<?php } ?>
				<div class="qqfengget">
					<?php global $query_string; ?>
					<?php query_posts( $query_string . '&ignore_sticky_posts=1' ); ?>
					<?php if ( have_posts() ) : ?>
					<?php while ( have_posts() ) : the_post(); ?>
					<?php get_template_part('qq_content', get_post_format()); ?>
					<?php endwhile; ?>
					<?php endif; ?>
				</div>
			<?php }else{ ?>
				<ul class="articles">
					<?php global $query_string; ?>
					<?php query_posts( $query_string . '&ignore_sticky_posts=1' ); ?>
					<?php if ( have_posts() ) : ?>
					<?php while ( have_posts() ) : the_post(); ?>
					<?php get_template_part('content', get_post_format()); ?>
					<?php endwhile; ?>
					<?php endif; ?>
				</ul>
			<?php } ?>
		</div>
		<div class="paging">
			<?php pagenavi(); ?>
		</div>
	</div>
	<?php get_sidebar(); ?>
	</div>
<?php if ( $_POST['action'] != 'ajax_post' ) : ?>
</div>
<?php get_footer(); ?>
<?php endif; ?>
