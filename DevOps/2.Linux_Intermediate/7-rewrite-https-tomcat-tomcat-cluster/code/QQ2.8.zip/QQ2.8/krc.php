<?php
header("Content-type: text/html; charset=utf-8");
error_reporting(0);//禁用错误
$hash = $_GET['hash'];
$name = $_GET['name'];
$name = str_replace(' ','%20',$name);
$url = 'http://mobilecdn.kugou.com/new/app/i/krc.php?keyword='.$name.'&timelength=1&type=0&cmd=200&hash='.$hash .'';
$content = @file_get_contents($url);
echo $content;
?>
