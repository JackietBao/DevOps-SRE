<!DOCTYPE html>
<html lang="zh-CN">

	<head>
		<meta charset="UTF-8" />
		<meta property="qc:admins" content="5340606616130176375" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<?php if ( is_home() ) { ?><title><?php bloginfo('name'); ?> - <?php bloginfo('description'); ?></title><?php } ?>
		<?php if ( is_search() ) { ?><title><?php _e('搜索 &#34;');the_search_query();echo "&#34;";?> - <?php bloginfo('name'); ?></title><?php } ?>
		<?php if ( is_single() ) { ?><title><?php echo trim(wp_title('',0)); ?> - <?php bloginfo('name'); ?></title><?php } ?>
		<?php if ( is_author() ) { ?><title><?php wp_title(""); ?> - <?php bloginfo('name'); ?></title><?php } ?>	
		<?php if ( is_archive() ) { ?><title><?php single_cat_title(); ?> - <?php bloginfo('name'); ?></title><?php } ?>
		<?php if ( is_year() ) { ?><title><?php the_time('Y'); ?> - <?php bloginfo('name'); ?></title><?php } ?>
		<?php if ( is_month() ) { ?><title><?php the_time('F'); ?> - <?php bloginfo('name'); ?></title><?php } ?>
		<?php if ( is_page() ) { ?><title><?php echo trim(wp_title('',0)); ?> - <?php bloginfo('name'); ?></title><?php } ?>
		<?php if ( is_404() ) { ?><title>404 - <?php bloginfo('name'); ?></title><?php } ?>
		<?php if(_hui('blog_icon')){?>
			<link rel="icon" href="<?php echo _hui('blog_icon'); ?>">
		<?php }else{ ?>
			<link rel="icon" href="<?php bloginfo('template_directory'); ?>/images/favicon.ico">
		<?php } ?>
		<?php wp_head(); ?>
		<script "text/javascript">var themeurl="<?php bloginfo('template_directory'); ?>",homeurl="<?php bloginfo('url'); ?>";</script>
		<!--[if lt IE 9]><script src="<?php bloginfo('template_url'); ?>/js/html5.js"></script><![endif]-->
		
	</head>

	<body>
<div id="m-nav" class="m-nav">
	<div class="m-nav-all">
		<div class="m-logo-url">
			<img src="<?php if($options['logourl']){echo $options["logourl"];}else{echo''.get_bloginfo('template_directory').'/images/logo.jpg';} ?>">
			<h3><?php bloginfo('name');?></h3>
			<span data-sign="0" class="user-login btn btn-danger"><i class="fa fa-user"></i>登录</span>&nbsp;<span data-sign="1" class="user-reg btn btn-success"><i class="fa fa-user-plus"></i>注册</span>
		</div>
		<ul class="nav">
			<?php echo _the_menu("nav"); ?>
		</ul>
	</div>
</div>
<div class="navbar">
  <div class="container">
	<div class="navbar-header-logo">
		<?php if(_hui('blog_logo')){?>
			<img src="<?php echo _hui('blog_logo'); ?>">
		<?php }else{ ?>
			<img src="<?php bloginfo('template_directory'); ?>/images/logo.jpg">
		<?php } ?>
	</div>
    <div class="navbar-header">
      <a class="navbar-brand hidden-sm"><?php bloginfo('name') ?></a>
    </div>
	<?php if ( is_user_logged_in() ) { ?>
		<div class="navbar-header-login">
			<ul>
				<li style="float:right;padding:10px;">
					<?php if(_hui('user_url')){ ?>
						<a href="<?php echo get_permalink( _hui('user_url') ); ?>" title="我的前端个人中心" class="btip" data-placement="left">
					<?php }else{ ?>
						<a href="<?php global $current_user; echo get_author_posts_url( $current_user->ID); ?>" title="我的前端个人中心" class="btip" data-placement="left">
					<?php } ?>
						<?php 
							global $current_user;
							$user_id = $current_user->id;
							$user_email = $current_user->user_email;
							$user_name = $current_user->display_name;
							$avtar = get_user_meta($user_id,'qquserimg',1);
							$avtars = get_user_meta($user_id,'sinauserimg',1);
						
							if( $avtar ) : 
						?>
							<img class="qq-login" src="<?php echo $avtar; ?>" />
							<span class="qq-login-name">个人中心</span>
						<?php elseif( $avtars ) : ?>
							<img class="qq-login" src="<?php echo $avtars; ?>" />
							<span class="qq-login-name">个人中心</span>
						<?php else : ?>
							<?php echo get_avatar($user_email, '40'); ?>
							<span class="qq-login-name">个人中心</span>
						<?php endif; ?>
					</a>
					<a href="<?php echo admin_url(); ?>">
						<span class="qq-logout">后台</span>
					</a>
					<a href="<?php echo wp_logout_url(get_bloginfo('url')); ?>">
						<span class="qq-logout">退出</span>
					</a>
				</li>
			</ul>
		</div>
	<?php } elseif ( _hui('nav_login') ) { ?>
		<div class="navbar-header-login">
			<ul>
				<li style="float:right; padding: 20px 15px;">
					<a href="javascript:" class="user-login"><i class="fa fa-user"></i>登录</a>
				</li>
			</ul>
		</div>
	<?php } ?>
    <div class="navbar-collapse collapse" role="navigation">
      <ul class="main-nav navbar-qq nav-menu">
		<?php echo _the_menu("nav"); ?>
	  </ul>
    </div>
  </div>
</div>
<form role="search" method="get" class="m-search" id="search-form" action="<?php echo home_url( '/' ); ?>">
    <div class="search-form">
    	<span id="search-form-close">&times;</span>
        <input placeholder="Search for" type="text" value="" name="s" id="search-input-s" />
        <input type="submit" class="webFont" id="searchsubmit" value="搜索" />
    </div>
</form>
<div id="m-header" class="m-header">
	<div id="showLeftPush" class="left m-header-button"></div>
	<h1><a href="<?php bloginfo('url'); ?>"><?php bloginfo('name');?></a></h1>
	<div id="search-trigger" style="font-size: 18px;" class="right m-header-search"></div>
</div>