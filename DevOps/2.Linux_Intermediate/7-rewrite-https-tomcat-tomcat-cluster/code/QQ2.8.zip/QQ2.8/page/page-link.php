<?php 
/*
 * Template Name: 友情链接
*/
?>
<?php if ( $_POST['action'] != 'ajax_post' ) : ?>
<?php get_header(); ?>
<div id="m-container">
<?php endif; ?>
	<div class="container containerall">
	<div class="main">
	<div id="content" class="post-single">
		<div id="singular-content">
			<?php /* The loop */ ?>
			<?php while ( have_posts() ) : the_post(); ?>
			<div id="post-<?php the_ID(); ?>">
				<header class="single-header">
					<h2>
						<?php the_title(); ?><p class="edit"><?php edit_post_link(); ?></p>
					</h2>
				</header>
				<div class="single-content">
					<?php the_content(); ?>
					<?php echo get_link_items(); ?>
				</div>
				<div class="clear">
				</div>
			</div><!--post-->
			<?php endwhile; ?>
		</div>
	</div><!--content-->
	<?php comments_template(); ?>
	</div>
	<?php get_sidebar(); ?>
	</div>
<?php if ( $_POST['action'] != 'ajax_post' ) : ?>
</div>
<?php get_footer(); ?>
<?php endif; ?>