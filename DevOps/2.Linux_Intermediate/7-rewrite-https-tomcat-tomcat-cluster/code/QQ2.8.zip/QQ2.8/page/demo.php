<?php 
/*
  Template Name: DEMO展示
*/
?>
<!doctype html>
<html>
<head>
<meta name="author" content="" />
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, initial-scale=no" />
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="apple-mobile-web-app-status-bar-style" content="black"/>
<meta name="format-detection" content="telephone=no"/>
<title><?php bloginfo('name'); ?> - DEMO展示</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<style>
.piframe{
	position:absolute;
	left:0;
	top:50px;
	right:0;
	bottom:0;
	width:100%;
	height:100%;
	border:none;
}
.iframeHeader{
	position:absolute;
	left:0;
	top:0;
	right:0;
	z-index:9;
	height:38px;
	line-height:38px;
	padding:5px 20px;
	background:#f4f4f4;
	text-align:left;
	font-size:14px;
	overflow:hidden;
}
.backToArticle{
	float:left;
	margin-right:20px;
	width:120px;
	height:38px;
	border:1px solid #0079c5;
	border-radius:4px;
	line-height:38px;
	text-align:center;
	font-size:16px;
	display:inline-block;
	text-decoration:none;
	color:#FFF;
	background:#61b3e6;
}
@media only screen and (max-width:640px){
	.iframeHeader{
		padding:5px;
	}
	.backToArticle{
		width:100px;
		margin-right:10px;
	}
}
</style>
</head>
<body>
<?php 
	$p = $_GET['p'];
	$a = $_GET['a'];
	$title = get_post($a)->post_title;
	$url = get_permalink($a);
	echo $title;
?>
	<div class="iframeHeader"><a href="<?php echo $url; ?>" class="backToArticle">下载源码</a><?php echo $title; ?></div>
	<iframe class="piframe" src="<?php echo $p; ?>"></iframe>

</body>
</html>