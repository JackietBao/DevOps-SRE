<?php 
/*
  Template Name: 首页样式二
*/
?>
<?php if ( $_POST['action'] != 'ajax_post' ) : ?>
<?php get_header(); ?>
<div id="m-container">
<?php endif; ?>
	<?php if( _hui('focus_s')&&_hui('focus_ss') ) {index_slider();} ?>
	<?php if( _hui('focus_s') ) hui_moloader('jiaodian'); ?>
	<div class="container containerall">
	<div class="main">
		<div id="content">
			<ul class="articles">
				<?php
					$args = array('post_type' => 'post');
					$wp_query = new WP_Query($args);
					while ($wp_query->have_posts()) {
						$wp_query->the_post(); 
				?>
					<?php get_template_part('content', get_post_format()); ?>
				<?php } ?>
			</ul>
		</div>
	</div>
	</div>
<?php if ( $_POST['action'] != 'ajax_post' ) : ?>
</div>
<?php get_footer(); ?>
<?php endif; ?>

