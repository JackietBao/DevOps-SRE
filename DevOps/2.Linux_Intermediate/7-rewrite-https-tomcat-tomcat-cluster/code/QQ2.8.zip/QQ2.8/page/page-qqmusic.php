<?php
/*
Template Name: QQ音乐
*/
?>
<?php if ( $_POST['action'] != 'ajax_post' ) : ?>
<?php get_header(); ?>
<div id="m-container">
<?php endif; ?>
<div class="container containerall">
<div class="main">
<div class="navbar navbar-default navbar-fixed-top" role="navigation">
    <div class="container" style="text-align:center;width: 110px;">
        <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
				<li><a class="navbar-brand" href="">QQ音乐API</a></li>
            </ul>
        </div><!--/.nav-collapse -->
    </div>
</div>
<div class="container" style="margin-top:10px;">
	<div class="single-music-so">
		<div class="form-wrapper cf">
			<input type="text" id="somusic">
			<input id="qqsobutton" class="pbutton" type="button" value="搜一下"></input>
		</div>
		<section id="cards" class="container">
		</section>
	</div>
	<div class="clear"></div>
</div>
</div><!--content-->
<style>.sidebar{display:none;}#comments{margin:20px 0}.main{padding: 10px;background: #fff;}.main .container{width: 1160px;}.main .navbar-collapse.collapse{float:none;}</style>
	<div class="clear"></div>
	<?php comments_template(); ?>
	</div>
	<?php get_sidebar(); ?>
	</div>
<?php if ( $_POST['action'] != 'ajax_post' ) : ?>
</div>
<?php get_footer(); ?>
<?php endif; ?>