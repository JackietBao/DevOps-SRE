<?php 
/*
  Template Name: 首页样式三
*/
?>
<?php if ( $_POST['action'] != 'ajax_post' ) : ?>
<?php get_header(); ?>
<div id="m-container">
<?php endif; ?>
	<div class="container containerall">
	<div class="main">
		<div id="content" class="index-single">
		<?php include(TEMPLATEPATH . '/function/post_header.php'); ?>
			<div class="qqfengget">
				<?php
					$args = array('post_type' => 'post');
					$wp_query = new WP_Query($args);
					while ($wp_query->have_posts()) {
						$wp_query->the_post(); 
				?>
					<?php get_template_part('qq_content', get_post_format()); ?>
				<?php } ?>
			</div>
		</div>
	</div>
	<?php hui_moloader('qsidebar'); ?>
	</div>
<?php if ( $_POST['action'] != 'ajax_post' ) : ?>
</div>
<?php get_footer(); ?>
<?php endif; ?>

