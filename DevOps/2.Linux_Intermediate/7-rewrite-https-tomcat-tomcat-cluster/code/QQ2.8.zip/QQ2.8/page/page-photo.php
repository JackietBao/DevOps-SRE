<?php
/*
Template Name: 相册
*/
?>
<?php if ( $_POST['action'] != 'ajax_post' ) : ?>
<?php get_header(); ?>
<div id="m-container">
<?php endif; ?>
<div class="container containerall">
<div class="main">
<?php while ( have_posts() ) : the_post(); ?>
<div class="navbar navbar-default navbar-fixed-top" role="navigation">
    <div class="container" style="text-align:center;width: 110px;">
        <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
				<li><a class="navbar-brand"><?php the_title(); ?></a></li>
            </ul>
        </div><!--/.nav-collapse -->
    </div>
</div>
<div class="container" style="margin-top:10px;">
	<div class="cimage-img">
		<?php all_img($post->post_content);?>
	</div>
	<div class="clear"></div>
</div>
<?php endwhile; ?>
</div><!--content-->
<style>.sidebar{display:none;}#comments{margin:20px 0}.main{padding: 10px;background: #fff;}.main .container{width: 1160px;}.main .navbar-collapse.collapse{float:none;}</style>
	<div class="clear"></div>
	<?php comments_template(); ?>
	</div>
	<?php get_sidebar(); ?>
	</div>
<?php if ( $_POST['action'] != 'ajax_post' ) : ?>
</div>
<?php get_footer(); ?>
<?php endif; ?>