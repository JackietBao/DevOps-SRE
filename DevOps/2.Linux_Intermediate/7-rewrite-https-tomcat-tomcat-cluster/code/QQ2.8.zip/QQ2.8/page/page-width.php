<?php
/*
Template Name: 无侧边栏模版
*/
?>
<?php if ( $_POST['action'] != 'ajax_post' ) : ?>
<?php get_header(); ?>
<div id="m-container">
<?php endif; ?>
<div class="container containerall">
<div class="main">
	<div id="singular-content">
		<?php /* The loop */ ?>
		<?php while ( have_posts() ) : the_post(); ?>
		<div id="post-<?php the_ID(); ?>">
			<header class="single-header">
				<h2>
					<?php the_title(); ?><p class="edit"><?php edit_post_link(); ?></p>
				</h2>
			</header>
			<div class="single-content">
				<?php the_content(); ?>
			</div>
			<div class="clear"></div>
		</div><!--post-->
		<?php endwhile; ?>
	</div>
</div><!--content-->
<style>.sidebar{display:none;}#comments{margin:20px 0}.main{padding: 10px;background: #fff;}</style>
	<div class="clear"></div>
	<?php comments_template(); ?>
	<?php get_sidebar(); ?>
</div>
<?php if ( $_POST['action'] != 'ajax_post' ) : ?>
</div>
<?php get_footer(); ?>
<?php endif; ?>