<?php
/*
Template Name: 用户中心
*/
?>
<?php if(is_user_logged_in()){?>
<?php if ( $_POST['action'] != 'ajax_post' ) : ?>
<?php get_header(); ?>
<div id="m-container">
<?php endif; ?>
	<div class="container containera
	<div class="main">
 <div id="personal">
    <ul>
         <h3>我的个人中心</h3>
    	<div class="m-personal">
			<?php global $current_user;	get_currentuserinfo();
				echo get_avatar( $current_user->user_email, 64); 
				echo '' . $current_user->display_name . "\n";
			?><br/>
			<a href="<?php echo wp_logout_url( home_url() ); ?>" title="">退出</a>
		</div>
        <li class="m-article"><i class="fa fa-file-text-o"></i> 我的文章</li>
        <li class="m-article"><i class="fa fa-comment-o"></i> 我的评论</li>
		<?php if(_hui('tou_url')){ ?>
			<li class="m-article"><i class="fa fa-pencil-square-o"></i> 我要投稿</li>
		<?php } ?>
        <li class="m-article"><i class="fa fa-cog"></i> 个人资料</li>
    </ul>

	<div>
		<h4>我的文章<span class="m-number">（<?php $userinfo=get_userdata(get_current_user_id()); $authorID= $userinfo->id; echo num_of_author_posts($authorID); ?>篇）<span></h4>
		
		<?php get_template_part( 'function/user/my-post' ); ?>
	</div>
	<div>
		<h4>我的评论</h4>
		<?php get_template_part( 'function/user/my-comment' ); ?>
	</div>
	<?php if(_hui('tou_url')){ ?>
		<div>
			<h4>我的稿文</h4>
			<?php get_template_part( 'function/user/my-tougao' ); ?>
		</div>
	<?php } ?>
	<div>
		<h4>个人设置</h4>
		<?php get_template_part( 'function/user/my-data' ); ?>
	</div>
</div>
</div>
</div>
<?php if ( $_POST['action'] != 'ajax_post' ) : ?>
</div>
<?php get_footer(); ?>
<?php endif; ?>
<?php }else{
 wp_redirect( home_url() );
 exit;
}?>