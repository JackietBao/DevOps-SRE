<?php
/*
Template Name: 读者墙
*/
?>
<?php if ( $_POST['action'] != 'ajax_post' ) : ?>
<?php get_header(); ?>
<div id="m-container">
<?php endif; ?>
	<div class="container containerall">
	<div class="main">
	<div id="content" class="post-single">
		<div id="singular-content">
			<?php /* The loop */ ?>
			<div id="post-<?php the_ID(); ?>">
				<div class="single-content">
					<?php include (get_stylesheet_directory() . "/function/readers.php"); ?>
				</div>
				<div class="clear">
				</div>
			</div><!--post-->
		</div>
	</div><!--content-->
	<?php comments_template(); ?>
	</div>
	<?php get_sidebar(); ?>
	</div>
<?php if ( $_POST['action'] != 'ajax_post' ) : ?>
</div>
<?php get_footer(); ?>
<?php endif; ?>