<?php qq_set_post_views(get_the_ID()); ?>
<div id="post-<?php the_ID(); ?>" class="post">

	<header class="single-header">
		<h2><?php the_title(); ?><p class="edit"><?php edit_post_link('<i class="fa fa-pencil-square-o"></i>编辑','','');?></p></h2>
	</header>
	
	<div class="single-meta">
		<span class="item"><?php the_time('Y-m-d'); ?></span>
		<span class="item">分类：<?php the_category(', ');?></span>
		<span class="item post-views">阅读(<?php echo qq_get_post_views(get_the_ID()); ?>)</span>
		<span class="item">评论(<?php comments_number( '0', '1', '%' ); ?>)</span>
	</div>
	
	<div class="single-content">
		<?php the_content(); ?>
	</div>

	<?php wp_link_pages('link_before=<span>&link_after=</span>&before=<div class="single-paging">&after=</div>&next_or_number=number'); ?>

	<?php if(get_the_tags()): ?>
		<div class="single-tag"><i class="fa fa-paper-plane"></i>标签:
			<?php the_tags( '', ',', ''); ?>
		</div>
	<?php endif; ?>
	
	<?php if( _hui('post_share') ) hui_moloader('qq-share'); ?>
	
	<?php if( _hui('post_guess') ) hui_moloader('qq-guess'); ?>
	
	<div class="clear"></div>

</div> <!--post-->