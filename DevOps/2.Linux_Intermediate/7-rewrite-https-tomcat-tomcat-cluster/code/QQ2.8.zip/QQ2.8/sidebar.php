<div class="sidebar">
	<?php if(_hui('qq_fengge')){ ?>
		<?php include(TEMPLATEPATH . '/function/qq-sidebar.php'); ?>
	<?php } ?>
	<section class="widget widget_ui_posts"><h3 class="widget_tit">最新发布</h3>
	  <ul class="nopic">
		<?php
			$limit = 6;
			$args = array(
				'order'            => DESC,
				'cat'              => $cat,
				'orderby'          => $orderby,
				'showposts'        => $limit,
				'caller_get_posts' => 1
			);
			query_posts($args);
			while (have_posts()) : the_post(); 
		?>
		<?php preg_match_all( '/\<img.+?src="(.+?)".*?\/>/',$post->post_content,$matches ,PREG_SET_ORDER); ?>
		<li>
			<a href="<?php the_permalink(); ?>" class="thumbnails">
				<?php if ( has_post_thumbnail() ) : //特色图片?>
					<?php the_post_thumbnail(); ?>
				<?php else: //无特色图片?>
					<?php if ( $matches[0][1] ) ://文章内有图片 ?>
						<img src="<?php echo $matches [0][1];?>" />
					<?php else : //文章内没有图片?>
						<img src="<?php bloginfo("template_url"); ?>/images/thumbnail.png" />
					<?php endif;//文章内有图片结束 ?>
				<?php endif;//特色图片结束 ?>
			</a>
			<h3>
				<a href="<?php the_permalink(); ?>">
					<?php the_title(); ?>
				</a>
			</h3>
		</li>
		<?php endwhile; wp_reset_query();?>
	  </ul>
	</section>
	<section class="widget widget_ui_posts"><h3 class="widget_tit">最新评论</h3>
		<div class="cbl-comment">
			<?php recent_comments($count="8"); ?>
		</div>
	</section>
	<?php
	if (function_exists('dynamic_sidebar') && dynamic_sidebar('widget_sitesidebar')) :
	endif;
	?>
	<?php
	if (is_single()) {
		if (function_exists('dynamic_sidebar') && dynamic_sidebar('widget_postsidebar')) :
		endif;
	}
	?>
	<?php
	if (is_page()) {
		if (function_exists('dynamic_sidebar') && dynamic_sidebar('widget_pagesidebar')) :
		endif;
	}
	?>
</div>