<?php 
/**
 * QQ登录类
 * @author 发烧 
 * @version  1.1 2014-9-1
 * @copyright 未经许可请勿自行使用、转载、修改、复制、发行、出售、发表或以其它方式利用本作者之内容
 */
new QQOQ_qq($appid,$appkey,$role,$scope);
	class QQOQ_qq
	{
		private $appid;
		private $appkey;
		private $role;
		private $scope;

		function __construct($appid,$appkey,$role,$scope){
			$this->appid = $appid;
			$this->appkey = $appkey;
			$this->role = $role;
			$this->scope = $scope;
			add_action('init', array($this, 'qqoq_init'), 1);
		}
		//QQ登录
		//$type 登陆类型
		function login($type) {
			$_SESSION['rurl'] = $_REQUEST["r"];
			$_SESSION['state'] = md5 ( uniqid ( rand (), true ) ); //CSRF protection
			$login_url = "https://graph.qq.com/oauth2.0/authorize?response_type=code&client_id=" . $this->appid . "&redirect_uri=" . urlencode ( home_url('/')."?callback=qqcallback&logintype=".$type ) . "&state=" . $_SESSION ['state'] . "&scope=" . $this->scope;
			header ( "Location:$login_url" );
			exit;
		}
		//登录成功回调函数 目的就是获取访问令牌
		//$type 登陆类型
		function callback($type) {
			if (!empty($_REQUEST['state']) && $_REQUEST['state'] == $_SESSION['state']) {
				$token_url = "https://graph.qq.com/oauth2.0/token?grant_type=authorization_code&" . "client_id=" . $this->appid . "&redirect_uri=" . urlencode ( home_url('/')."?callback=qqcallback&logintype=".$type ) . "&client_secret=" . $this->appkey . "&code=" . $_REQUEST ["code"];
				
				$response = QQOQ_get_url_contents ( $token_url );
				if (strpos ( $response, "callback" ) !== false) {
					$lpos = strpos ( $response, "(" );
					$rpos = strrpos ( $response, ")" );
					$response = substr ( $response, $lpos + 1, $rpos - $lpos - 1 );
					$msg = json_decode ( $response );
					if (isset ( $msg->error )) {
						exit('ErrorCode:'.$msg->error.'<br/>ErrorMessage:'.$msg->error_description.'<br/>Contact QQ:<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=570047973&site=qq&menu=yes">570047973</a>');
					}
				}
				
				$params = array ();
				parse_str ( $response, $params );
				$_SESSION['access_token'] = $params["access_token"];
				$this->get_openid($params["access_token"]);
			} else {
				exit('ErrorCode:QQOQ0001<br/>ErrorMessage:The state does not match. You may be a victim of CSRF.<br/>Contact QQ:<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=570047973&site=qq&menu=yes">570047973</a>');
			}
		}
		//获取该QQ用户的openid
		function get_openid($token) {
			$graph_url = "https://graph.qq.com/oauth2.0/me?access_token=" . $token;
			
			$str = QQOQ_get_url_contents ( $graph_url );
			if (strpos ( $str, "callback" ) !== false) {
				$lpos = strpos ( $str, "(" );
				$rpos = strrpos ( $str, ")" );
				$str = substr ( $str, $lpos + 1, $rpos - $lpos - 1 );
			}
			
			$user = json_decode ( $str );
			if (isset ( $user->error )) {
				exit('ErrorCode:'.$user->error.'<br/>ErrorMessage:'.$user->error_description.'<br/>Contact QQ:<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=570047973&site=qq&menu=yes">570047973</a>');
			}
			$_SESSION['openid'] = $user->openid;
		}
		
		//获取用户信息
		function get_user_info() {
			$get_user_info = "https://graph.qq.com/user/get_user_info?" . "access_token=" . $_SESSION['access_token'] . "&oauth_consumer_key=" . $this->appid . "&openid=" . $_SESSION['openid'] . "&format=json";		
			return QQOQ_get_url_contents ( $get_user_info );
		}

		//登录后数据处理
		function qq_cb(){
			global $wpdb;
			if(empty($_SESSION['openid'])){
				exit('ErrorCode:QQOQ0003<br/>ErrorMessage:openid is empty.<br/>Contact QQ:<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=570047973&site=qq&menu=yes">570047973</a>');
			}
            $query = "SELECT ID FROM `{$wpdb->users}` where openid='{$_SESSION["openid"]}'";
			$openid_db = $wpdb->get_var($query);
		    if (is_numeric($openid_db)) {
		        $user_ID = $openid_db;
                $user = get_user_by( 'id', $user_ID );
                wp_set_current_user($user_ID,$user->user_login);
		        wp_set_auth_cookie($user_ID);
                do_action('wp_login', $user->user_login);
		        wp_redirect($_SESSION['rurl']);
		    }else{
		        $login_name = wp_create_nonce($_SESSION['openid']);
		        $pass = wp_create_nonce(microtime());
		        $uinfo = json_decode($this->get_user_info());
		        $username = $uinfo->nickname;
		        $http = is_ssl()?"https://":"http://";
		        $userdata=array(
		          'user_login' => $login_name,
		          'display_name' => $username,
		          'user_pass' => $pass,
		          'role' => $this->role,
		          'nickname' => $username,
		          'first_name' => $username,
		          'qquserimg' => $uinfo->figureurl_qq_2,
		          'user_email' => $login_name."@".str_replace($http,"",home_url())
		        );
		        $user_id = wp_insert_user( $userdata );
		        if ( is_wp_error( $user_id ) ) {
		        	exit('ErrorCode:QQOQ0005<br/>ErrorMessage:'.$user_id->get_error_message().'<a href="'.$_SESSION['rurl'].'">Click to return</a><br/>Contact QQ:<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=570047973&site=qq&menu=yes">570047973</a>');
		        }else{
		            $ff = $wpdb->query("UPDATE `{$wpdb->users}` SET openid = '$_SESSION[openid]' WHERE ID = '$user_id'");
		            if ($ff) {
                        wp_set_current_user($user_id);
		                wp_set_auth_cookie($user_id,true,false);
		                wp_redirect($_SESSION['rurl']);
		            }          
		        }
		        exit();
		    }
		}
		//QQ绑定
		function qq_bd(){
			if(!is_user_logged_in())
				exit('ErrorCode:QQOQ0002<br/>ErrorMessage:Please login to continue.<br/>Contact QQ:<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=570047973&site=qq&menu=yes">570047973</a>');
			global $wpdb;
			$session_uid = $_SESSION['openid'];
			$openid_db = $wpdb->get_var("SELECT openid FROM `{$wpdb->users}` where openid='{$session_uid}'");
			if(empty($_SESSION['openid'])){
				exit('ErrorCode:QQOQ0003<br/>ErrorMessage:openid is empty.<br/>Contact QQ:<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=570047973&site=qq&menu=yes">570047973</a>');
			}elseif ($openid_db) {
		        exit('ErrorCode:QQOQ0004<br/>ErrorMessage:The account has been!<a href="'.$_SESSION['rurl'].'">Click to return</a><br/>Contact QQ:<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=570047973&site=qq&menu=yes">570047973</a>');
		    }else{
				$userid = get_current_user_id();
				$wpdb->query("UPDATE `{$wpdb->users}` SET openid = '{$_SESSION["openid"]}' WHERE ID = '{$userid}'");
			    $uinfo = json_decode($this->get_user_info());
			    $qqimg = $uinfo->figureurl_qq_2;
			    $data = update_user_meta($userid,'qquserimg',$qqimg);
		        wp_redirect($_SESSION['rurl']);
		        exit();
			}
		}
		//QQ解绑
		function jb(){
			if(!is_user_logged_in())
				exit('ErrorCode:QQOQ0002<br/>ErrorMessage:Please login to continue.<br/>Contact QQ:<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=570047973&site=qq&menu=yes">570047973</a>');
			global $wpdb;
			$userid = get_current_user_id();
			$wpdb->query("UPDATE `{$wpdb->users}` SET openid = '' WHERE ID = '{$userid}'");
			delete_user_meta($userid,'qquserimg');
		}
		function qqoq_init(){	
			if ($_GET['qqoq_connect'] == 'qq') {
				$this->login('qq');
			}elseif($_GET['qqoq_connect'] == 'qqbd'){
				if(!is_user_logged_in()){
					wp_safe_redirect( home_url() );
					exit;
				}
				$this->login('qqbd');
			}elseif($_GET['callback'] == 'qqcallback'){	
				$logintype = $_GET['logintype'];
				$this->callback($logintype);
				if($logintype == 'qqbd'){
					$this->qq_bd();
				}else{	
					$this->qq_cb();
				}
			}elseif($_GET['qqoq_connect'] == 'qqjb'){
				$this->jb();
			}
		}
	}
?>