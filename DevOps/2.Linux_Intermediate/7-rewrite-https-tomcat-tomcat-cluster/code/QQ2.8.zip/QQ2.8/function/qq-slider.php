<?php
	// 注册自定义文章类型——Work（资讯幻灯片）
	function register_qq_works_post_type() {
		$labels = array(
			'name' => '资讯幻灯片',
			'singular_name' => '资讯幻灯片',
			'add_new' => '添加',
			'add_new_item' => '添加资讯幻灯片',
			'edit_item' => '编辑资讯幻灯片',
			'new_item' => '新资讯幻灯片',
			'view_item' => '查看资讯幻灯片',
			'search_items' => '搜索资讯幻灯片',
			'not_found' =>  '未找到资讯幻灯片',
			'not_found_in_trash' => '回收站中未找到资讯幻灯片'
		);
		$args = array(
			'labels' => $labels,
			'public' => true,
			'hierarchical' => false,
			'capability_type' => 'post',
			'show_in_nav_menus' => false,
			'menu_position' => 5,
			'has_archive' => false,
			'menu_icon' => 'dashicons-images-alt',
			'rewrite' => array('slug' => 'works'),
			'supports' => array('title', 'excerpt'),
		);
		register_post_type('qq_work', $args);
	}
	add_action('init', 'register_qq_works_post_type', 1);
	
	// 资讯幻灯片Meta信息
	add_action("add_meta_boxes", "add_work_meta_box");
	add_action('save_post', 'update_work_meta_box');
	
	function add_work_meta_box(){
		add_meta_box("work_meta_box_details", '资讯幻灯片设置', "work_meta_box_options", "qq_work", "normal", "low");
	}
	
	function work_meta_box_options() {
		global $post;
		$custom = get_post_custom($post->ID);
		$work_img_url = $custom["work_img_url"][0];
		$work_link_url = $custom["work_link_url"][0];
		$work_external_url = $custom["work_external_url"][0];
?>
		<div id="work-options">
			<p>
				<label for="work_img_url">文章标志性资讯幻灯片图片：</label>
				<input name="work_img_url" id="work_img_url" value="<?php echo $work_img_url?>" style="width:98%;"/>
			</p>
			<p>
				<label for="work_link_url">连接到资讯幻灯片的文章地址：</label>
				<input name="work_link_url" id="work_link_url" value="<?php echo $work_link_url?>" style="width:98%;"/>
			</p>
			<p>
				<label for="work_external_url">外部链接网址：</label>
				<input name="work_external_url" id="work_external_url" value="<?php echo $work_external_url?>" style="width:98%;"/>
			</p>
		</div>
<?php
	}
	function update_work_meta_box() {
		global $post;
		if ($post) {
			update_post_meta($post->ID, "work_img_url", $_POST["work_img_url"]);
			update_post_meta($post->ID, "work_external_url", $_POST["work_external_url"]);
			update_post_meta($post->ID, "work_link_url", $_POST["work_link_url"]);
		}
	}
?>