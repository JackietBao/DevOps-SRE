<?php
/**
 * 新浪微博登录类
 * @author 发烧 
 * @version  1.1 2014-9-1
 * @copyright 未经许可请勿自行使用、转载、修改、复制、发行、出售、发表或以其它方式利用本作者之内容
 */
new QQOQ_sina($sinaappid,$sinaappkey,$role,$sinascope);
	class QQOQ_sina
	{
		private $appid;
		private $appkey;
		private $role;
		private $scope;

		function __construct($appid,$appkey,$role,$scope){
			$this->appid = $appid;
			$this->appkey = $appkey;
			$this->role = $role;
			$this->scope = $scope;
			add_action('init', array($this, 'qqoq_init'), 1);
		}

		//新浪微博登录
		function login($type) {
			$_SESSION['rurl'] = $_REQUEST ["r"];
			$_SESSION ['state'] = md5 ( uniqid ( rand (), true ) ); //CSRF protection
			$login_url = "https://api.weibo.com/oauth2/authorize?client_id=".$this->appid."&response_type=code&redirect_uri=".urlencode (home_url('/')."?callback=sinacallback&logintype=".$type)."&state=".$_SESSION['state'];
			header ( "Location:$login_url" );
			exit;
		}
		//登录成功回调函数 获取Access Token和UID
		function callback($type){
			if ($_REQUEST ['state'] == $_SESSION ['state']) {
				$url = "https://api.weibo.com/oauth2/access_token";
				$data = "client_id=".$this->appid."&client_secret=".$this->appkey."&grant_type=authorization_code&redirect_uri=".urlencode (home_url('/')."?callback=sinacallback&logintype=".$type)."&code=".$_REQUEST ["code"];
				$output = json_decode(do_post($url,$data));
				$_SESSION['access_token'] = $output->access_token;
				$_SESSION['uid'] = $output->uid;
			}else{
				exit('ErrorCode:QQOQ0001<br/>ErrorMessage:The state does not match. You may be a victim of CSRF.<br/>Contact QQ:<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=570047973&site=qq&menu=yes">570047973</a>');
			}
		}
		//发送微博
		function send_weibo($content){
			$url = 'https://api.weibo.com/2/statuses/update.json';
			$data = "access_token=".$_SESSION['access_token']."&status=".$content;
			$output = json_decode(do_post($url,$data));
			return $output;
		}
		//获取用户信息
		function get_user_info() {
			$get_user_info = "https://api.weibo.com/2/users/show.json?uid=".$_SESSION['uid']."&access_token=".$_SESSION['access_token'];
			return QQOQ_get_url_contents ( $get_user_info );
		}
		//登录成功后数据处理
		function sina_cb(){
			global $wpdb;
			if(empty($_SESSION['uid'])){
				exit('ErrorCode:QQOQ0003<br/>ErrorMessage:uid is empty.<br/>Contact QQ:<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=570047973&site=qq&menu=yes">570047973</a>');
			}
			$query = "SELECT ID FROM `{$wpdb->users}` where uid='{$_SESSION["uid"]}'";
			$uid_db = $wpdb->get_var($query);
			if (is_numeric($uid_db)) {
				$user_ID = $uid_db;
                $user = get_user_by( 'id', $user_ID );
                wp_set_current_user($user_ID,$user->user_login);
		        wp_set_auth_cookie($user_ID);
		        do_action('wp_login', $user->user_login);
		        wp_redirect($_SESSION['rurl']);
		        exit();
		    }else{
		        $login_name = wp_create_nonce($_SESSION['uid']);
		        $pass = wp_create_nonce(microtime());
		        $str = json_decode($this->get_user_info());
				$username = $str->screen_name;
				$userimg = $str->avatar_large;
				$http = is_ssl()?"https://":"http://";
		        $userdata=array(
		          'user_login' => $login_name,
		          'display_name' => $username,
		          'user_pass' => $pass,
		          'role' => $this->role,
		          'nickname' => $username,
		          'first_name' => $username,
		          'sinauserimg' => $userimg,
		          'user_email' => $login_name."@".str_replace($http,"",home_url())
		        );
		        $user_id = wp_insert_user( $userdata );
		        if ( is_wp_error( $user_id ) ) {
		            exit('ErrorCode:QQOQ0005<br/>ErrorMessage:'.$user_id->get_error_message().'<a href="'.$_SESSION['rurl'].'">Click to return</a><br/>Contact QQ:<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=570047973&site=qq&menu=yes">570047973</a>');
		        }else{
		            $ff = $wpdb->query("UPDATE `{$wpdb->users}` SET uid = '{$_SESSION["uid"]}' WHERE ID = '{$user_id}'");
		            if ($ff) {
		                wp_set_current_user($user_id);
		                wp_set_auth_cookie($user_id,true,false);
		                wp_redirect($_SESSION['rurl']);
		            }          
		        }
		        exit();
		    }
		}
		//新浪微博绑定
		function sina_bd(){
			if(!is_user_logged_in())
				exit('ErrorCode:QQOQ0002<br/>ErrorMessage:Please login to continue.<br/>Contact QQ:<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=570047973&site=qq&menu=yes">570047973</a>');
			global $wpdb;
			$session_uid = $_SESSION['uid'];
			$openid_db = $wpdb->get_var("SELECT uid FROM `{$wpdb->users}` where uid='{$session_uid}'");
			
			if(empty($session_uid)){
				exit('ErrorCode:QQOQ0003<br/>ErrorMessage:uid is empty.<br/>Contact QQ:<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=570047973&site=qq&menu=yes">570047973</a>');
			}elseif($openid_db){	
				exit('ErrorCode:QQOQ0004<br/>ErrorMessage:The account has been!<a href="'.$_SESSION['rurl'].'">Click to return</a><br/>Contact QQ:<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=570047973&site=qq&menu=yes">570047973</a>');
			}else{
				$userid = get_current_user_id();
				$return = $wpdb->query("UPDATE `{$wpdb->users}` SET uid = '{$session_uid}' WHERE ID = '{$userid}'");
			    $str = json_decode($this->get_user_info());
			    $sinaimg = $str->avatar_large;
			    $data = update_user_meta($userid,'sinauserimg',$sinaimg);		
			    wp_redirect($_SESSION['rurl']);
			    exit();			    
			}
		}
		//新浪解绑
		function jb(){
			if(!is_user_logged_in())
				exit('ErrorCode:QQOQ0002<br/>ErrorMessage:Please login to continue.<br/>Contact QQ:<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=570047973&site=qq&menu=yes">570047973</a>');
			global $wpdb;
			$userid = get_current_user_id();
			$wpdb->query("UPDATE `{$wpdb->users}` SET uid = '' WHERE ID = '{$userid}'");
			delete_user_meta($userid,'sinauserimg');
		}
		function qqoq_init(){	
			if ($_GET['qqoq_connect'] == 'sina') {
				$this->login('sina');
			}elseif($_GET['qqoq_connect'] == 'sinabd'){
				if(!is_user_logged_in()){
					wp_safe_redirect( home_url() );
					exit;
				}
				$this->login('sinabd');
			}elseif($_GET['callback'] == 'sinacallback'){	
				$logintype = $_GET['logintype'];
				$this->callback($logintype);
				if($logintype == 'sinabd'){
					$this->sina_bd();
				}else{	
					$this->sina_cb();
				}
			}elseif($_GET['qqoq_connect'] == 'sinajb'){
				$this->jb();
			}
		}
	}
?>