<?php

function readers_wall($outer = "1", $timer = "3", $limit = "100")
{
	global $wpdb;
	$counts = $wpdb->get_results("SELECT count(comment_author) AS cnt, comment_author, comment_author_url, comment_author_email FROM $wpdb->comments WHERE comment_date > date_sub( now(), interval $timer month ) AND user_id!='1' AND comment_author_email != 'azfashao@qq.com' AND comment_author!=$outer AND comment_approved='1' AND comment_type='' GROUP BY comment_author ORDER BY cnt DESC LIMIT $limit");
	$i = 0;

	foreach ($counts as $count ) {
		$i++;
		$c_url = $count->comment_author_url;

		if (!$c_url) {
			$c_url = "居高临下";
		}

		$tt = $i;

		if ($i == 1) {
			$tt = "金牌读者";
		}
		else if ($i == 2) {
			$tt = "银牌读者";
		}
		else if ($i == 3) {
			$tt = "铜牌读者";
		}
		else {
			$tt = "第" . $i . "名";
		}

		if ($i < 4) {
			$type .= "<a class=\"item-top item-" . $i . "\"><h4>【" . $tt . "】<small>评论：" . $count->cnt . "</small></h4>" . str_replace(" src=", " data-src=", get_avatar($count->comment_author_email, $size = "36")) . "<strong>" . $count->comment_author . "</strong>居高临下</a>";
		}
		else {
			$type .= "<a title=\"【" . $tt . "】评论：" . $count->cnt . "\">" . str_replace(" src=", " data-src=", get_avatar($count->comment_author_email, $size = "36")) . $count->comment_author . "</a>";
		}
	}

	echo $type;
}

while (have_posts()) {
	the_post();
	echo "\t\t<header class=\"single-header\">\r\n\t\t\t<h2>梁山好汉一百单八将";
	echo "<p class=\"edit\">";
	edit_post_link();
	echo "</p></h2>\r\n\t\t</header>\r\n\t\t<div class=\"center\">\r\n\t\t\t";
	the_content();
	echo "\t\t</div>\r\n\t\t";
}

echo "\r\n\t\t<div class=\"readers\">\r\n\t\t\t";
echo "\t\t\t";
readers_wall(1, _hui("readwall_limit_time"), _hui("readwall_limit_number"));
echo "\t\t</div>\r\n\r\n\t\t";

?>
