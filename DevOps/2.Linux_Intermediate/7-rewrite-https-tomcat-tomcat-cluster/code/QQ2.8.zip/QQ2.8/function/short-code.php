<?php

add_action('admin_footer', 'media_upload_for_upyun');function media_upload_for_upyun(){ ?>
	<div id="ddm-lay"></div>
	<div id="ddm-box">
		<div id="ddm-content" class="cfx">
			<ul id="ddm-cate">
				<li><a href="#" class="current">短代码</a></li>
				<li>WordPress短代码自版本2.5引入以来，就被证明是最有用的功能之一。通过短代码，普通的编辑用户不需要专业的编程能力就可以发布动态的内容。</li>
			</ul>
			<ul id="ddm-ddm">
				<li class="cfx current"><a href="1" class="button">内容评论可见</a><a href="2" class="button">音乐播放器</a><a href="3" class="button">歌词播放器</a><a href="4" class="button">DIY歌词播放器</a><a href="5" class="button">友链</a><a href="6" class="button">文字折叠</a><a href="7" class="button">密码内容</a><a href="8" class="button">按钮音乐播放器</a></li>
			</ul>
			<a id="ddm-close" href="#"><span class="dashicons dashicons-no-alt"></span></a></div>
	</div>
		<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/ie7.css" type="text/css" media="all">
	<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.ddm.js"></script>
	<?php }
	add_action('media_buttons_context',  'add_my_custom_button');
	function add_my_custom_button($context) {
	$context .='<a href="#" id="ddm-button" title="短代码" class="thickbox button"><span class="dashicons dashicons-editor-code"></span>短代码</a>';
	return $context;}

/*回复可见*/
function reply_to_read($atts, $content=null) {
    global $post;
    extract(shortcode_atts(array("name"=>'',), $atts));
    $email = null;
    $user_ID = (int) wp_get_current_user()->ID;
	$contents = '<div class="dashed"><p><i class="fa fa-eye"></i>隐藏的内容</p>'.$content.'</div>';
	$notice = '<div class="reply-to-read"><div style="padding: 10px 0;"><span><i class="fa fa-lock"></i>'.$name.' - 评论回复可见</span><p>此处内容需要您<a href="#respond" title="评论本文">评论本文</a>过后才能查看。如有不便还请谅解。为了作者的辛勤劳动，评论请留下您的真实信息。</p></div></div>';
    if ($user_ID > 0) {
        $email = get_userdata($user_ID)->user_email;
        if ($email == get_the_author_meta( 'user_email' )) {
            return $contents;
        }
    } else if (isset($_COOKIE['comment_author_email_' . COOKIEHASH])) {
        $email = str_replace('%40', '@', $_COOKIE['comment_author_email_' . COOKIEHASH]);
    } else {
        return $notice;
    }
    if (empty($email)) {
        return $notice;
    }
    $args = array(
        'post_id' => get_the_ID()
    );
    $array_email = array();
    $comments = get_comments($args);
    foreach($comments as $comment) {
        $comment_author_email = $comment->comment_author_email;
        array_push($array_email,$comment_author_email);
    }
    if (in_array($email,$array_email)) {
        return $contents;
    } else {
        return $notice;
    }
}
add_shortcode('reply', 'reply_to_read');

//歌词
function playerlrc($atts, $content=null){   
extract(shortcode_atts(array("id"=>''),$atts));
return "<div class='qq_lrc_box'><ul id='".$id."_lrc' class='qq_lrc'><li style='display: none;'></li><li style='display: none;'></li><li></li></ul></div>
<div><p><span><script>var may_$id = load_qq_lrc('$id');
may_$id.loadurl('$content');</script></span></p></div>";   
}   
add_shortcode('lrc','playerlrc');

function playerlrc2($atts, $content=null){   
extract(shortcode_atts(array("id"=>''),$atts));
return "<div class='qq_lrc_box'><ul id='".$id."_lrc' class='qq_lrc'><li style='display: none;'></li><li style='display: none;'></li><li></li></ul></div>
<div><p><span><script>var may_$id = load_qq_lrc('$id');
may_$id.loadurl('".get_template_directory_uri()."/get_lrc.php?id=$content');</script></span></p></div>";   
}   
add_shortcode('lrc2','playerlrc2');


//歌词播放器
function mp3player3($atts, $content=null){
	extract(shortcode_atts(array("id"=>'',"img"=>'',"name"=>''),$atts));
	return '<div class="lrcplay"><div class="musicplayerslogo"><div class="musicplayersavatar"><a><img alt="" src="'.$img.'"></a></div><div class="statusinfo"><span id="lrcicon-play" class="lrcicon-play"></span>'.$name.'</div></div><audio id="'.$id.'" src="'.$content.'" name="playerd" class="playerd"></audio></div>';  
}
add_shortcode('mp3','mp3player3');

//友情链接
function friends($atts, $content=null) {
	extract(shortcode_atts(array(
	"aurl" => '',
	"email" => ''
	), $atts));
	$output = '<span><a rel="link" href="'.$aurl.'" title="'.$content.'" target="_blank">'.get_avatar($email, 36).'<span class="sitename">'.$content.'</span></a></span>'; 
	return $output;
}
add_shortcode('link','friends');

//文字隐藏
function show_more($atts, $content = null) {
	return '<span class="showmore" title="显示隐藏"><span><i class="fa fa-caret-down"></i></span></span>';
}
add_shortcode("s", "show_more");

function section_content($atts, $content = null) {
	$content = wpautop(trim($content));
	return '<div class="section-content">'.do_shortcode( $content ).'</div>';
}
add_shortcode("p", "section_content");

//密码保护文字
function mimawenzi($atts, $content=null){
	extract(shortcode_atts(array("id"=>'',"title"=>''),$atts));
	$_COOKISE['m_password'] = $_POST['m_password'];
	if ( isset($_COOKISE['m_password']) && $_POST['m_password'] == $id) {
		$output = '<div class="dashed"><span><i class="fa fa-unlock"></i>加密的内容</span><p>'.do_shortcode( $content ).'</p></div>';
		return $output;
    } else {
		$output = '
		<div class="mima-main">
			<div class=""><i class="fa fa-key"></i>'.$title.'</div>
			<form action="'.get_the_permalink().'" method="post" class="post-mima">
				<input name="m_password" class="mima-input" type="password" size="20" />
				<button id="mima_submit" type="submit" class="mima-submit">提交</button>
			</form>
		</div>
        ';
		return $output;
    }
}
add_shortcode("mima", "mimawenzi");

//player
function yuyin($atts, $content=null){
	extract(shortcode_atts(array("auto"=>'0'),$atts));
	return '
	<span id="jp_container" class="jp-audio">
		<span rel="' .$content. '" class="play-switch jplay"  title="play"><i></i></span>
		<span class="play-switch stop"  title="stop" style="display: none;"><i></i></span>
		<span rel="'.$auto.'"class="auto" ></span>
	</span>';
}
add_shortcode('y','yuyin');
?>