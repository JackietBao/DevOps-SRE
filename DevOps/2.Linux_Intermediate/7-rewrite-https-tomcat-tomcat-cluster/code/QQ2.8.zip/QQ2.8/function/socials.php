<?php
@session_start();
if(!function_exists('wp_get_current_user')) {
    include(ABSPATH . "wp-includes/pluggable.php"); 
}
//QQ
$appid = _hui('qq_key');
$appkey = _hui('qq_secret');
$role = get_option('default_role');
$scope = 'get_user_info,add_share,list_album,add_album,upload_pic,add_topic,add_one_blog,add_weibo';
//SINA
$sinaappid = _hui('sina_key');
$sinaappkey = _hui('sina_secret');
$sinascope = 'get_user_info,add_share,list_album,add_album,upload_pic,add_topic,add_one_blog,add_weibo';
include_once('qq.php');
include_once('sina.php');
add_filter('get_avatar','qqoq_avatar', 1,5);
function qqoq_avatar($avatar,$id_or_email, $size, $default, $alt){
    if($id_or_email != ''){
        if(is_numeric($id_or_email)){
            $id = (int)$id_or_email;
            $username = get_user_meta( $id, 'nickname', 1 ); 
        }elseif ( is_object($id_or_email) ){
            if ( ! empty( $id_or_email->comment_type ) && ! in_array( $id_or_email->comment_type, (array) $allowed_comment_types ) )
            return false;
            if ( ! empty( $id_or_email->user_id ) ) {
                $id = (int) $id_or_email->user_id;
            }
            $username = get_user_meta( $id, 'nickname', 1 ); 
        }else{
            $email = $id_or_email;
            $user = get_user_by('email',$email);
            $id = $user->ID;
            $username = $user->user_nicename;
        }
        $qquserimg = get_user_meta($id, 'qquserimg', true);
        $sinauserimg = get_user_meta($id, 'sinauserimg', true);
        if($alt == ''){
            $alt = $username;
        }
        if($qquserimg == '' && $sinauserimg == ''){
            return $avatar;
        }elseif($qquserimg != ''){
            $avatar = '<img width="'.$size.'" height="'.$size.'" class="avatar" src="'.$qquserimg.'" alt="'.$alt.'">';
            return $avatar;
        }elseif($sinauserimg != ''){
            $avatar = '<img width="'.$size.'" height="'.$size.'" class="avatar" src="'.$sinauserimg.'" alt="'.$alt.'">';
            return $avatar;
        }
    }
    return $avatar;
}
/**
 * CURL POST请求
 * @author 发烧
 * @param string $url 请求url地址
 * @param string $data 请求数据
 * @version  1.0
 */
if(!function_exists('do_post')){
	function do_post($url, $data) {
		$ch = curl_init ();
		curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, TRUE );
		curl_setopt ( $ch, CURLOPT_POST, TRUE );
		curl_setopt ( $ch, CURLOPT_POSTFIELDS, $data );
		curl_setopt ( $ch, CURLOPT_URL, $url );
		curl_setopt ( $ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		$ret = curl_exec ( $ch );
		curl_close ( $ch );
		return $ret;
	}
}
/**
 * CURL GET请求
 * @author 发烧
 * @param string $url 请求url地址
 * @version  1.0
 */
if(!function_exists('QQOQ_get_url_contents')){
	function QQOQ_get_url_contents($url) {
		$ch = curl_init ();
		curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, TRUE );
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt ( $ch, CURLOPT_URL, $url );
		$result = curl_exec ( $ch );
		curl_close ( $ch );
		return $result;
	}
}
/**
 * 创建数据库字段，在user表中增加一个`openid`和 `uid`两个字段
 * openid字段用于记录QQ返回的用户openid
 * uid用于记录新浪微博返回的用户uid
 * @author 发烧
 * @version  1.0
 */
if(!function_exists('qqoq_plugin_activation')){
	function qqoq_plugin_activation() {   
	    global $wpdb;
        // 创建openid字段(QQ)
        $var = $wpdb->query("SELECT openid FROM $wpdb->users");
        if(!$var){
            $wpdb->query("ALTER TABLE $wpdb->users ADD openid varchar(50)");
        }
        // 创建uid字段(新浪)
        $var1 = $wpdb->query("SELECT uid FROM $wpdb->users");
        if(!$var1){
         	$wpdb->query("ALTER TABLE $wpdb->users ADD uid varchar(50)");
        }
	}
}
add_action( 'activated_plugin', 'qqoq_plugin_activation' );
/**
 * 构造登录链接
 * @author 发烧
 * @version  1.0
 * @param string $type 登录链接类型，接受四个固定参数，登陆参数为:'qq'和'sina'. 绑定参数为:'qqbd'和'sinabd'
 * @param string $rurl 登录后返回的url地址，默认为当前页面地址，url必须为完整链接，例：http://www.qqoq.net
 * @param boole $echo 结果是否直接输出，1（默认）输出值，0返回值
 * @return string (url)
 */
if(!function_exists('qqoq_login_url')){
	function qqoq_login_url($type,$rurl="",$echo=1){
		global $wp;
		if (empty($rurl)) {
			$url = add_query_arg( $wp->query_string, '', home_url( $wp->request ) );
		}else{	
			$url = $rurl;
		}
		$login_url = home_url("/").'?qqoq_connect='.$type.'&r='.$url;
		if ($echo == 1)
			echo $login_url;
		else
			return $login_url;
	}
}

//增加用户信息字段
function modify_user_contact_methods( $user_contact ){
    $user_contact['qquserimg'] = 'QQ头像';
    $user_contact['sinauserimg'] = '新浪头像';
    return $user_contact;
}
add_filter('user_contactmethods', 'modify_user_contact_methods');

/**
 * 判断是否绑定
 * @author 发烧
 * @version  1.0
 * @param string $type 需要检查的类型，只接受两个固定参数，即:'qq'和'sina'.
 * @return boole/string 存在返回值，不存在返回false
 */
function is_QQOQ_bd($type){
    global $wpdb;
    if($type == 'qq'){
        $field = 'openid';
    }elseif ($type == 'sina'){
        $field = 'uid';
    }
    $user_ID = get_current_user_id();
    $query = "SELECT {$field} FROM `{$wpdb->users}` where ID='{$user_ID}'";
    $openid_db = $wpdb->get_var($query);
    if($openid_db)
        return $openid_db;
    else
        return false;
}
//绑定
add_action('show_user_profile','QQOQ_bd');
function QQOQ_bd() { 
?>
    <table class="form-table"><tr>
        <th scope="row"><label>QQOQ登陆绑定</label></th>
        <td>
            <?php 
                if(is_QQOQ_bd('qq')){ 
                    $qq_jburl = add_query_arg('qqoq_connect','qqjb',get_edit_user_link());
                    echo '<a title="QQ解绑" style="margin-right:10px;" href="'.$qq_jburl.'"><img src="'.get_template_directory_uri().'/images/qjb.png" alt="QQ解绑" /></a>';
                }else{ ?>
                <a href="<?php qqoq_login_url('qqbd',get_edit_user_link()) ?>" title="QQ登录绑定"><img src="<?php echo get_template_directory_uri().'/images/qtn.png'; ?>" alt="QQ登录绑定" /></a>
            <?php }if(is_QQOQ_bd('sina')){
                $sina_jburl = add_query_arg('qqoq_connect','sinajb',get_edit_user_link());
                    echo '<a title="新浪微博解绑" href="'.$sina_jburl.'"><img src="'.get_template_directory_uri().'/images/sinajb.png" alt="新浪微博解绑" /></a>';
                }else{
            ?>
            <a href="<?php qqoq_login_url('sinabd',get_edit_user_link()) ?>" title="新浪微博登录绑定"><img src="<?php echo get_template_directory_uri().'/images/sinatn.png';?>" alt="新浪微博登录绑定" /></a>
            <?php }?>
        </td>
    </tr></table>
<?php 
}
?>