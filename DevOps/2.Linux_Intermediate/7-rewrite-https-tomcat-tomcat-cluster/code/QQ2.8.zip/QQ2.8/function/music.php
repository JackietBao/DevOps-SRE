<?php

/*短链*/
function xlUrlAPI($type, $url){
    $key = '3893919640';
    if ($type) {
        $baseurl = 'http://api.t.sina.com.cn/short_url/shorten.json?source=' . $key . '&url_long=' . $url;
    } else {
        $baseurl = 'http://api.t.sina.com.cn/short_url/expand.json?source=' . $key . '&url_short=' . $url;
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $baseurl);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $strRes = curl_exec($ch);
    curl_close($ch);
    $arrResponse = json_decode($strRes, true);
    if (isset($arrResponse->error) || !isset($arrResponse[0]['url_long']) || $arrResponse[0]['url_long'] == '') {
        return 0;
    }
    if ($type) {
        return $arrResponse[0]['url_short'];
    } else {
        return $arrResponse[0]['url_long'];
    }
}
/*QQ音乐API*/
function qqmusic(){
	$name = $_POST['name'];
    $data = array();
	$get_user_info  = 'http://c.y.qq.com/soso/fcgi-bin/search_cp?w='.$name.'&format=json&p=1&n=100';
	$data = json_decode(file_get_contents ( $get_user_info ) , true);
	$qqs = $data['data']['song'];
		if(!empty($qqs)){
			foreach ($qqs['list'] as $qq){
				foreach ($qq['singer'] as $q){
					$qqurl = 'http://ws.stream.qqmusic.qq.com/'.$qq['songid'].'.m4a?fromtag=66';
					$surl = xlUrlAPI(1,$qqurl).'?.mp3';
					$text .= '<div class="col-sm-4">
								<a class="card">
									<img src="http://azfashao.com/wp-content/themes/QQ/images/qqmusic.png" />
									<div class="count">'.$q['name'].'</div>
									<div class="description">
										<h2>'.$qq['songname'].'</h2>              
									</div>
									<div class="qqmusicurl">    
										<p>'.$surl.'</p>       
									</div>
									<div class="qqmusicid">
										<p>歌曲id: '.$qq['songid'] . do_shortcode('[y auto="1"]'.$surl.'[/y]').'</p>
									</div>
								</a>
							  </div>';
				}
			}
        }
	echo $text;
	exit;
}
add_action('wp_ajax_nopriv_qqmusic', 'qqmusic');
add_action('wp_ajax_qqmusic', 'qqmusic');