<?php
	/*文章外链图片*/
	add_action("add_meta_boxes", "qq_add_work_meta_box");
	add_action('save_post', 'qq_update_work_meta_box');
	
	function qq_add_work_meta_box(){
		add_meta_box("qq_work_meta_box_details", '文章外链图片设置', "qq_work_meta_box_options", "post", "normal", "high");
	}
	
	function qq_work_meta_box_options() {
		global $post;
		$custom = get_post_custom($post->ID);
		$post_url = $custom["post_url"][0];
?>
		<div id="work-options">
			<p>
				<label for="post_url">文章外链图片：</label>
				<input name="post_url" id="post_url" value="<?php echo $post_url?>" style="width:98%;"/>
			</p>
		</div>
<?php
	}
	function qq_update_work_meta_box() {
		global $post;
		if ($post) {
			update_post_meta($post->ID, "post_url", $_POST["post_url"]);
		}
	}
?>