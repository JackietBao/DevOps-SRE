<?php
	$djd = '<div class="scrollers"><a'.hui_target_blank().' class="jiaodian_a" href="'.home_url("/").'" style="background-image: url('.get_template_directory_uri().'/images/tum.jpg)"><img src="'.get_template_directory_uri().'/images/tum.jpg"><span>'.get_bloginfo('name').'</span></a></div>';
?>
<?php if( _hui('focus_sss') ) { ?>
	<div class="container">
		<?php hui_moloader('slider'); hui_moloader('hui_posts_focus'); ?>
	</div>
<?php } ?>