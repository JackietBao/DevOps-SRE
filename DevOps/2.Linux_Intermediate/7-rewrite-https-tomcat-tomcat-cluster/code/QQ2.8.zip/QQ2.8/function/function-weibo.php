<?php
include('weibo.php');
add_action('admin_menu','wptl_menu');
function wptl_menu() {
	add_theme_page('微博设置', '微博设置', 'edit_themes', basename(__FILE__), 'wptl_page');
	add_action('admin_init','wptl_settings');
}

function wptl_settings() {
	register_setting('wptl-settings-group','wptl_options');
}

function wptl_page(){?>
	<div class="wrap">
		<div id="icon-options-general" class="icon32"><br></div><h2>微博设置</h2><br>
		<form method="post" action="options.php">
			<?php settings_fields( 'wptl-settings-group' ); ?>
			<?php $options = get_option('wptl_options'); ?>
			<h3>食用方法</h3>
			<table class="form-table">
				<tbody>
					<tr valign="top">
						<th scope="row"><label>食用方法</label></th>
						<td>
							<ol>
								<li>填写 App Key、App Secret、Access token、uid 信息</li>
								<li>复制函数 <code>  wp_timeline() </code> 到任意页面</li>
							</ol>
						</td>
					</tr>
				</tbody>
			</table>
			<h3>App Key、App Secret、Access token、uid</h3>
			<table class="form-table">
				<tbody>			
					<tr valign="top">
						<th scope="row"><label>App Key</label></th>
						<td>
							<input type="text" class="regular-text code" name="wptl_options[app_key]" value="<?php echo $options["app_key"];?>" />
						</td>
					</tr>
					<tr valign="top">
						<th scope="row"><label>App Secret</label></th>
						<td>					
							<input type="text" class="regular-text code" name="wptl_options[app_secret]" value="<?php echo $options["app_secret"];?>" />
						</td>
					</tr>					
					<tr valign="top">
						<th scope="row"><label>Access token</label></th>
						<td>
							<input type="text" class="regular-text code" name="wptl_options[access_token]" value="<?php echo $options["access_token"];?>" />					
						</td>
					</tr>
					<tr valign="top">
						<th scope="row"><label>uid</label></th>
						<td>
							<input type="text" class="regular-text code" name="wptl_options[uid]" value="<?php echo $options["uid"];?>" />
						</td>
					</tr>				
				</tbody>
			</table>
			<br />
			<h3>页面显示设置</h3>
			<table class="form-table">
				<tbody>					
					<tr valign="top">
						<th scope="row"><label>微博显示数量</label></th>
						<td>
							<input type="text" class="regular-text code" name="wptl_options[count]" value="<?php echo $options["count"];?>" />
							<p><strong>默认显示 10条 微博。</strong></p>
						</td>
					</tr>					
					<tr valign="top">
						<th scope="row"><label>是否显示图片</label></th>
						<td>
							<fieldset>
								<?php $array = array(
									"0" => "不显示图片", 
									"1" => "显示缩略图",
									"2" => "显示原图"
								);
								foreach($array as $key => $value){?>
									<label><input type="radio" name="wptl_options[image]" value="<?php echo (int) $key;?>" <?php if($options['image']==$key) echo 'checked="checked"'; ?>> <span><?php echo $value;?></span></label><br>
								<?php };?>
								<p><strong>默认 不显示图片。</strong></p>
							</fieldset>	
						</td>
					</tr>
					<tr valign="top">
						<th scope="row"><label>是否显示转发内容</label></th>
						<td>
							<fieldset>
								<?php $array = array(
									"0" => "不显示转发内容", 
									"1" => "显示转发内容"
								);
								foreach($array as $key => $value){?>
									<label><input type="radio" name="wptl_options[retweeted]" value="<?php echo (int) $key;?>" <?php if($options['retweeted']==$key) echo 'checked="checked"'; ?>> <span><?php echo $value;?></span></label><br>
								<?php };?>
								<p><strong>默认 不显示转发内容。</strong></p>
							</fieldset>	
						</td>
					</tr>
					<tr valign="top">
						<th scope="row"><label>CSS 文件</label></th>
						<td>
							<fieldset>
								<?php $array = array("0" => "随着插件载入到顶部", "1" => "自行处理");
								foreach($array as $key => $value){?>
									<label><input type="radio" name="wptl_options[css]" value="<?php echo (int) $key;?>" <?php if($options['css']==$key) echo 'checked="checked"'; ?>> <span><?php echo $value;?></span></label><br>
								<?php };?>
								<p>默认 CSS文件加载到网页头部。</p>
							</fieldset>						
						</td>
					</tr>										
				</tbody>
			</table>
			<div class="wptimeline_submit_form">
				<input type="submit" class="button-primary" name="save" value="<?php _e('Save Changes') ?>"/>
			</div>
		</form>
	</div>
<?php }

// Enqueue style-file.
function wptl_stylesheet() {
	wp_enqueue_style('wp-timeline', get_template_directory_uri(). '/css/wptl.css', array(), '1.0', 'screen');
}

if(!$options["css"]) add_action('wp_enqueue_scripts', 'wptl_stylesheet');
?>