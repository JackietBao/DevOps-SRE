	<div class="single-share">
		<div class="share-text share-one">
			<span class="share-tspan"><i class="fa fa-share-square-o"></i>分享</span>
		</div>
		<div class="share-yuansu share-one">
			<span><a class="share-qq btip" href="http://s.share.baidu.com/?click=1&url=<?php the_permalink(); ?>&uid=0&to=sqq&type=text&pic=&title=<?php the_title(); ?> - <?php bloginfo('name'); ?>" title="分享到QQ聊天" data-placement="top" target="_blank"></a></span>
			<span><a class="share-qzone btip" href="http://s.share.baidu.com/?click=1&url=<?php the_permalink(); ?>&uid=0&to=qzone&type=text&pic=&title=<?php the_title(); ?> - <?php bloginfo('name'); ?>" title="分享到QQ空间" data-placement="top" target="_blank"></a></span>
			<span><a class="share-weixin"><div id = "share-weixin"><img src="http://pan.baidu.com/share/qrcode?w=148&h=148&url=<?php the_permalink(); ?>" /><p style="width: 150px;margin-top: 10px;">打开微信扫一扫，扫面上面二维码分享到微信朋友圈</p></div></a></span>
			<span><a class="share-sina btip" href="http://s.share.baidu.com/?click=1&url=<?php the_permalink(); ?>&uid=0&to=tsina&type=text&pic=&title=<?php the_title(); ?> - <?php bloginfo('name'); ?>" title="分享到新浪微博" data-placement="top" target="_blank"></a></span>
			<span><a class="share-tieba btip" href="http://s.share.baidu.com/?click=1&url=<?php the_permalink(); ?>&uid=0&to=tieba&type=text&pic=&title=<?php the_title(); ?> - <?php bloginfo('name'); ?>" title="分享到百度贴吧" data-placement="top" target="_blank"></a></span>
			<span><a class="share-qqweibo btip" href="http://s.share.baidu.com/?click=1&url=<?php the_permalink(); ?>&uid=0&to=tqq&type=text&pic=&title=<?php the_title(); ?> - <?php bloginfo('name'); ?>" title="分享到腾讯微博" data-placement="top" target="_blank"></a></span>
			<span><a class="share-renren btip" href="http://s.share.baidu.com/?click=1&url=<?php the_permalink(); ?>&uid=0&to=renren&type=text&pic=&title=<?php the_title(); ?> - <?php bloginfo('name'); ?>" title="分享到人人网" data-placement="top" target="_blank"></a></span>
		</div>
	</div>