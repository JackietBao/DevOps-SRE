<?php function index_slider() {
	if( is_home() ){
?>
<div id="top-slide-three" class="owl-carousel">	
	<?php 
				$categories = explode(",",_hui( 'qq_slide_fenlei' ));
				$num = _hui('qq_slide_number');
				$args = array(
					'ignore_sticky_posts'=> 1,
					'paged' => $paged,
					'posts_per_page' =>  $num,
					'cat' => $categories , 
					'tax_query' => array( array( 
						'taxonomy' => 'post_format',
						'field' => 'slug',
						'terms' => array(
							//请根据需要保留要排除的文章形式
							'post-format-aside',
							'post-format-link'
							),
						'operator' => 'NOT IN',
					) ),
				);
			query_posts($args);	
	    	if ( have_posts() ) { while ( have_posts() ) { the_post();?>	
	            <div class="item" style="background: url(<?php echo post_thumbnail_src(); ?>);background-repeat: no-repeat;background-size: cover;background-position: center top;">	
					<div class="slider-content">
						<div class="slider-content-box">
							<div class="slider-content-item">
								<div class="slider-title">
									<h2><?php the_title();?></h2>
					            </div>
							</div>
						</div>
					</div>
					<a class="slider-go" href="<?php the_permalink(); ?>" title="<?php the_title();?>"></a>
				</div>				                
				<?php }
	        }
		wp_reset_query(); 
	?>
</div>
<?php } } ?>