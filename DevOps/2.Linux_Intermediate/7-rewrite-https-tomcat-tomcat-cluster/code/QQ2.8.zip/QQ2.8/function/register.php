<?php

//给注册页面添加输入文本框
add_action( 'register_form', 'wenshuo_register_fields' );
function wenshuo_register_fields(){
?>
    <p>
    <label for="password">密码<br/>
    <input id="password" class="input" type="password" value="" name="password" />
    </label>
    </p>
    <p>
    <label for="repeat_password">确认密码<br/>
    <input id="repeat_password" class="input" type="password" value="" name="repeat_password" />
    </label>
    </p>
<?php }

//检查用户输入
add_action( 'register_post', 'wenshuo_check_register_fields', 10, 3 );
function wenshuo_check_register_fields($login, $email, $errors) {
	$url = tin_get_current_page_url2();
	$judge = home_url().'/wp-login.php?action=register';
	if( $url==$judge ){
		if (!isset($_POST[ 'password' ]) || empty($_POST[ 'password' ])){
			return $errors->add( 'proofempty', '<strong>错误</strong>: 您还没有设定密码。'  );
		}elseif (!isset($_POST[ 'repeat_password' ]) || empty($_POST[ 'repeat_password' ])){
			return $errors->add( 'proofempty', '<strong>错误</strong>: 请再次确认密码。'  );
		}elseif ( $_POST['password'] !== $_POST['repeat_password'] ) {
			$errors->add( 'passwords_not_matched', "<strong>错误</strong>: 两次输入的密码不一致" );
		} 
	}
}

//储存用户提交的密码
add_action( 'user_register', 'ts_register_extra_fields', 100 );
function ts_register_extra_fields( $user_id ){
    $userdata = array();
    $userdata['ID'] = $user_id;
    if ( $_POST['password'] !== '' ) {
        $userdata['user_pass'] = $_POST['password'];
    }
    $new_user_id = wp_update_user( $userdata );
}

//验证码
add_action( 'register_form', 'add_security_question' );
function add_security_question() { ?>
    <p>
    <label>请回答1+1=?<br />
        <input type="text" name="user_proof" id="user_proof" class="input" size="25" tabindex="20" />
	</label>
    </p>
<?php }
      
add_action( 'register_post', 'add_security_question_validate', 10, 3 );
function add_security_question_validate( $sanitized_user_login, $user_email, $errors){
	$url = tin_get_current_page_url2();
	$judge = home_url().'/wp-login.php?action=register';
	if( $url==$judge ){
		if (!isset($_POST[ 'user_proof' ]) || empty($_POST[ 'user_proof' ])){
			return $errors->add( 'proofempty', '<strong>错误</strong>: 您还没有回答问题。'  );
		} elseif ( strtolower( $_POST[ 'user_proof' ] ) != '2' ){
			return $errors->add( 'prooffail', '<strong>错误</strong>: 您的回答不正确。'  );
		}
	}
}

?>
