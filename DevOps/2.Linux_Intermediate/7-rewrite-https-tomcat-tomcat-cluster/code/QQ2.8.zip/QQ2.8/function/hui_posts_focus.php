<?php 
/* 
 * post focus
 * ====================================================
*/
function hui_posts_focus(){
    $html = '';
    $sticky = get_option('sticky_posts'); rsort( $sticky );
    query_posts( array( 'post_type'=> 'qq_work', 'post__in' => $sticky, 'ignore_sticky_posts' => 1, 'showposts' => 5 ) );
    if( have_posts() ) : 
        while (have_posts()) : the_post();
			$custom = get_post_custom($post->ID);
			$work_img_url = $custom['work_img_url'][0];
			$work_link_url = $custom['work_link_url'][0];
			$work_external_url = $custom['work_external_url'][0];
			if( $work_link_url ){
				$html .= '<div class="block article"><a href="'.$work_link_url.'" style="background-image: url('.$work_img_url.')"><span>'.get_the_title().'</span></a></div>';
			}elseif( $work_external_url ){
				$html .= '<div class="block article"><a href="'.$work_external_url.'" '.hui_target_blank().' style="background-image: url('.$work_img_url.')"><span>'.get_the_title().'</span></a></div>';
			}else{
				$html .= '<div class="block article"><a href="#" style="background-image: url('.$work_img_url.')"><span>'.get_the_title().'</span></a></div>';
			}
        endwhile; 
    endif;
    wp_reset_query(); 
    echo '<div class="smaller-images">'.$html.'</div>';
}
?>
