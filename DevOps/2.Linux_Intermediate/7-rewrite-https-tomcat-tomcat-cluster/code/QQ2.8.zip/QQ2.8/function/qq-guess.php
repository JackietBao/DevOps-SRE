	<!-- 相关文章 -->
	<div class="bs-example visible-md visible-lg" id="post-related">
	<p style="margin:10px 0;"><i class="fa fa-heart"></i> 您可能也喜欢:</p>
	<div class="row">
			<?php 
			global $post;
			$cats = wp_get_post_categories( $post->ID );
			if ( $cats ) {
				$args = array(
								'category__in' => array( $cats[0] ),
								'post__not_in' => array( $post->ID ),
								'showposts' => 3,
				);
			query_posts( $args );
	    	if ( have_posts()  ) {
				while ( have_posts() ) {
				the_post(); update_post_caches( $posts ); ?>				            
	            <div class="col-md-4">
	            <div class="thumbnail">
	            <div class="caption clearfix">
					<p class="post-related-title"><a href="<?php the_permalink(); ?>" rel="bookmark" class="post-title" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></p>
					<p class="post-related-content"><?php echo qq_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 150,"..."); ?></p>
					<p class="post-btn-read-more"><a href="<?php the_permalink() ?>"  title="详细阅读 <?php the_title(); ?>">more</a></p>							
				</div>
	            </div>					                
	            </div>
	            <?php
	          }
	        }
			wp_reset_query(); } ?>
	</div>
	</div>