	<header class="s-header">
		<div class="s-logo">
			<a href="<?php bloginfo('url'); ?>">
				<?php qq_get_cavatar(); ?>
			</a>
		</div>
		<div class="s-data">
			<?php if ( _hui('qq_wangming_q') ) : ?>
				<a href="<?php bloginfo('url') ?>" title="<?php echo _hui('qq_wangming'); ?>">
					<?php echo _hui('qq_wangming'); ?>
				</a>
			<?php else : ?>
				<a href="<?php bloginfo('url') ?>" title="<?php bloginfo('name'); ?>">
					<?php bloginfo('name'); ?>
				</a>
			<?php endif; ?>
		</div>
		<div class="s-qianming" contenteditable="true" title="<?php echo _hui('qq_qianming'); ?>">
			<p><?php echo _hui('qq_qianming'); ?></p>
		</div>
		<div class="s-qqicons">
			<a class="s-qqkongjian" href="<?php if ( _hui('qq_zhanghao') ) echo 'http://user.qzone.qq.com/'._hui('qq_zhanghao').''; ?>" title="QQ空间" target="_blank"></a>
			<a class="s-qqyouxiang" href="<?php if ( _hui('qq_zhanghao') ) echo 'http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email='._hui('qq_zhanghao').'@qq.com'; ?>" title="QQ邮箱" target="_blank"></a>
			<a class="s-qqweibo" href="<?php echo _hui('qq_weibo'); ?>" title="QQ微博" target="_blank"></a>
		</div>
		<form role="search" method="get" id="search-form" action="<?php bloginfo('url'); ?>/">
			<input class="searchInput" type="text" value="" name="s" id="s" placeholder="你想搜点什么~" />
			<input class="searchBtn" type="submit" title="搜索" value="搜索">
		</form>
	</header>
	<div class="s-main">
		<div class="s-tabs">
			<div id="tabs">
				<ul class="tab_menu" role="tablist">
					<li class="tabs1 active" role="presentation">
						<a href="#tabs-w" class="tabsa btip" title="热门文章" role="tab" data-placement="top" data-toggle="tab">
							<i class="fa fa-file-text">
							</i>
						</a>
					</li>
					<li class="tabs2" role="presentation">
						<a href="#tabs-l" class="tabsa btip" title="近期评论" role="tab" data-placement="top" data-toggle="tab">
							<i class="fa fa-comments-o">
							</i>
						</a>
					</li>
					<li class="tabs3" role="presentation">
						<a href="#tabs-b" class="tabsa btip" title="分类标签" role="tab" data-placement="top" data-toggle="tab">
							<i class="fa fa-tags">
							</i>
						</a>
					</li>
					<li class="tabs4" role="presentation">
						<a href="#tabs-d" class="tabsa btip" title="博主信息" role="tab" data-placement="top" data-toggle="tab">
							<i class="fa fa-user">
							</i>
						</a>
					</li>
				</ul>
				<div id="tabs_container" class="tab-content">
					<div id="tabs-w" class="tab-pane fade in active" class="tab-pane">
						<ul>
							<?php latest_article(15); ?>
						</ul>
					</div>
					<div id="tabs-l" class="tab-pane fade" role="tabpanel">
						<?php recent_comments(8); ?>
					</div>
					<div id="tabs-b" class="tab-pane fade" role="tabpanel">
						<div class="login_tit">
							<i class="fa fa-quote-left"></i> 热门标签<i class="fa fa-quote-right"></i>
						</div>
								<?php fs_widget_tag(14); ?>
					</div>
					<div id="tabs-d" class="tab-pane fade" role="tabpanel">
						<p><i class="fa fa-quote-left"></i> 网站信息<i class="fa fa-quote-right"></i></p>
						<p>文章总数量：<?php $count_posts = wp_count_posts(); echo $published_posts = $count_posts->publish; ?> 篇</p>
						<p>页面总数量：<?php $count_pages = wp_count_posts('page'); echo $page_posts = $count_pages->publish; ?> 个</p>
						<p>分类总数量：<?php echo $count_categories = wp_count_terms('category'); ?> 个</p>
						<p>标签总数量：<?php echo $count_tags = wp_count_terms('post_tag'); ?> 个</p>
						<p>会员总数量：<?php $users = $wpdb->get_var("SELECT COUNT(ID) FROM $wpdb->users"); echo $users; ?> 个</p>
						<p>链接总数量：<?php $link = $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->links WHERE link_visible = 'Y'"); echo $link; ?> 个</p>
						<p>评论总数量：<?php $total_comments = get_comment_count(); echo $total_comments['approved'];?> 条</p>
						<p>浏览总数量：<?php echo lo_all_view(); ?> 次<br>
						<p>运行总天数：<?php echo floor((time()-strtotime("2010-04-02"))/86400);?> 天</p>
						<p>最近更新期：<?php $last = $wpdb->get_results("SELECT MAX(post_modified) AS MAX_m FROM $wpdb->posts WHERE (post_type = 'post' OR post_type = 'page') AND (post_status = 'publish' OR post_status = 'private')");$last = date('Y年n月j日', strtotime($last[0]->MAX_m));echo $last; ?></p>
					</div>
				</div>
				<!--End tabs container-->
			</div>
			<!--End tabs-->
		</div>
	</div>
	<div class="s-footer">
	</div>