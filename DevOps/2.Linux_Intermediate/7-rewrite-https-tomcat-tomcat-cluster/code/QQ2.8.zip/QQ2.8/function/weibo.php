<?php
include('weiboOAuth.php');

function wptl_topic_link($tweet_msg){
    preg_match_all ( '/#(.*)#/', $tweet_msg, $matches, PREG_SET_ORDER);
    foreach( $matches as $match )
    {
        $url = "http://weibo.com/k/" . rawurlencode($match[1]);
        $tweet_msg = str_replace( '#'.$match[1].'#', "<a href='".$url."' target='_blank'>#".$match[1]."#</a>" , $tweet_msg) ;
    }
    return $tweet_msg;
}

function wptl_url_link($tweet_msg){
    preg_match_all ( '|http://t\.cn/\w+|', $tweet_msg, $matches, PREG_SET_ORDER);
    foreach( $matches as $match )
    {
        $url = $match[0];
        $tweet_msg = str_replace( $match[0], "<a href='".$url."' target='_blank'>".$match[0]."</a>" , $tweet_msg) ;
    }
    return $tweet_msg;
}

function wptl_at_link($tweet_msg){
    preg_match_all ( '/@(.*?)[:\s]/', $tweet_msg, $matches, PREG_SET_ORDER);
    foreach( $matches as $match )
    {
        $url = $match[1];
        $tweet_msg = str_replace( $match[0], "<a href='http://weibo.com/n/".$url."' target='_blank'>@".$match[1]."</a> " , $tweet_msg) ;
    }
    return $tweet_msg;
}

function wptl_at($content){
	$content = wptl_topic_link($content);
	$content = wptl_url_link($content);
	$content = wptl_at_link($content);
	return "<p>" . $content. "</p>";
}

function wptl_image($text, $item){
	$allow_image = _hui('wbpic');

	if($allow_image=='wbspic_off'){
		if(array_key_exists('thumbnail_pic', $item)){
			$text .= '<img src="'.$item['thumbnail_pic'].'" />';
		}
	}else if($allow_image=='wbypic_off'){
		if(array_key_exists('original_pic', $item)){
			$text .= '<img src="'.$item['original_pic'].'" />';
		}
	}
	return $text;
}

function wp_timeline(){
	$token = _hui("access_token");
	$appkey = _hui("app_key");
	$appsecret = _hui("app_secret");
	$uid = _hui("w_uid");
	$number = '5';
	$allow_retweeted = _hui('wbzf');
	if($token){
		$c = new SaeTClientV2( $appkey , $appsecret , $token );
		$ms  = $c->user_timeline_by_id( $uid, 1, $number); // done
		$user = $c->show_user_by_id($uid);
		
		if( is_array( $user ) ){?>
		<?php }
		
		if( is_array( $ms['statuses'] ) ):
			if( !$user['verified_reason'] == "" ){
				echo '<ol class="teamnewslist"><div class="weibo_photo"><a href="http://weibo.com/'.$user['profile_url'].'/" title="我的微博" target="_blank"><img src="'.$user['avatar_large'].'" alt="'.$user['screen_name'].'" class="weibologo"></a><span>'.$user['screen_name'].'</span><span>微博数量：'. $user['statuses_count'].'</span><span>关注人数：'. $user['friends_count'].'</span><span>粉丝人数：'. $user['followers_count'].'</span><a class="icon_bed"><em title="&nbsp;&nbsp;'.$user['verified_reason'].'" class="W_icon icon_pf_approve" suda-uatrack="key=profile_head&amp;value=vuser_host"></em></a></div>';
			}else{
				echo '<ol class="teamnewslist"><div class="weibo_photo"><a href="http://weibo.com/'.$user['profile_url'].'/" title="我的微博" target="_blank"><img src="'.$user['avatar_large'].'" alt="'.$user['screen_name'].'" class="weibologo"></a><span>'.$user['screen_name'].'</span><span>微博数量：'. $user['statuses_count'].'</span><span>关注人数：'. $user['friends_count'].'</span><span>粉丝人数：'. $user['followers_count'].'</span><a class="icon_bed"></a></div>';
			}
			foreach( $ms['statuses'] as $item ):
				$text = wptl_at($item['text']);
				$text = wptl_image($text, $item);
				if( $allow_retweeted && array_key_exists('retweeted_status', $item)){
					$retweeted = '<div class="weibo-retweet"><p>'. $item['retweeted_status']["text"]. '</p>';
					$retweeted = wptl_image($retweeted, $item['retweeted_status']);
					$text .= $retweeted. '</div>';
				}
				?>
					<li class="weibo-item">
						<?php echo'<b>发布于'.date('Y-m-d',strtotime($item['created_at'])) . '</b>';?>
						<span><i class="fa fa-thumbs-o-up"></i><?php echo $item['attitudes_count']; ?></span>
						<span><i class="fa fa-comments-o"></i><?php echo $item['comments_count']; ?></span>
						<?=$text;?>
					</li>
				<?php 
			endforeach;
		endif;
	}else{
		echo '<ol id="weibo-list">请到后台设置.</ol>';
	}
}

?>