<p><iframe src="<?php echo get_permalink( _hui('user_profile') ); ?>" width="100%" height="800" frameborder="0"></iframe></p>
