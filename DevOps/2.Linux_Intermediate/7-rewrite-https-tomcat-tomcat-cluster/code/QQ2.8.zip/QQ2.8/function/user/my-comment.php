<script>	
$(function(){

  $("div.holder").jPages({
    containerID : "itemContainer",
	previous : "«",
	next : "»",
	perPage:15,
  });

});
</script>
<?php
			$curauth = $wp_query->get_queried_object();
			$comments_status = $oneself ? '' : 'approve';
			$all = get_comments( array('status' => '', 'user_id'=>$curauth->ID, 'count' => true) );
			$approve = get_comments( array('status' => '1', 'user_id'=>$curauth->ID, 'count' => true) );
			$comments = get_comments(array('status' => $comments_status,'order' => 'DESC', 'user_id' => $curauth->ID));
		if($comments){
			$item_html = '<li class="tip">' . sprintf(__('共有 %1$s 条评论，其中 %2$s 条已获准， %3$s 条正等待审核。','um'),$all, $approve, $all-$approve) . '</li>';
		foreach( $comments as $comment ){
			$item_html .= ' <li>';
			if($comment->comment_approved!=1) $item_html .= '<small class="text-danger">'.__( '这条评论正在等待审核','um' ).'</small>';
			$item_html .= '<div class="message-content">'.$comment->comment_content . '</div>';
			$item_html .= '<a class="info" href="'.htmlspecialchars( get_comment_link( $comment->comment_ID) ).'">'.sprintf(__('%1$s  发表在  %2$s','um'),$comment->comment_date,get_the_title($comment->comment_post_ID)).'</a>';
			$item_html .= '</li>';
		}
		}
		echo '<ul id="itemContainer" class="user-msg my-comment">'.$item_html.'</ul>';
		echo '<div class="holder"></div>';
?>