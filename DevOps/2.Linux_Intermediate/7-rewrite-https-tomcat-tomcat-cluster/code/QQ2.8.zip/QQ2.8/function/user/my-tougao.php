<p><iframe src="<?php echo get_permalink( _hui('tou_url') ); ?>" width="100%" height="800" frameborder="0"></iframe></p>
