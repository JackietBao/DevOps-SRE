<?php query_posts("post_type=qq_work"); if( have_posts() ) : ?>
	<div class="scrollers">
		<div class="slider faded">
			<?php while ( have_posts() ) : the_post(); ?>
				<?php $custom = get_post_custom($post->ID); $work_img_url = $custom['work_img_url'][0];$work_link_url = $custom['work_link_url'][0];$work_external_url = $custom['work_external_url'][0];?>
				<div id="<?php echo $posts_counter; ?>"><div class="image"><img src="<?php echo $work_img_url; ?>"/><div class="slide-prompt"><p><a <?php echo hui_target_blank(); ?> href="<?php if($work_link_url){echo $work_link_url;}elseif($work_external_url){echo $work_external_url;}else{echo '#';} ?>"><?php the_title(); ?></a></p><?php the_excerpt(); ?></div></div></div>
			<?php endwhile; ?>
		</div>
	</div>
	<!-- 代码end -->
	<?php endif; ?>
<?php wp_reset_query();?>