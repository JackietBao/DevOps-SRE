<?php preg_match_all( '/\<img.+?src="(.+?)".*?\/>/',$post->post_content,$matches ,PREG_SET_ORDER); ?>
	<?php if ( has_post_format( 'gallery' ) ) : //多图形式 ?>

		<li id="post-<?php the_ID(); ?>" <?php post_class(); ?> >
			<?php if ( has_post_thumbnail() ) : //特色图片?>
				<div class="post-image">
					<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark">
						<?php the_post_thumbnail(); ?>
					</a>
				</div>
			<?php else: //无特色图片?>
				<div class="post-image-slide">
					<?php all_imgt($post->post_content);?>
				</div>
				<div class="post-header">
					<h3>
						<a href="<?php the_permalink(); ?>" rel="bookmark" class="post-title" title = "<?php the_title(); ?>">
							<?php the_title(); ?>
						</a>
					</h3>
				</div>
			<?php endif;//特色图片结束 ?>
		</li>
		
	<?php elseif ( has_post_format( 'image' ) ) : //图片形式 ?>

		<li id="post-<?php the_ID(); ?>" <?php post_class(); ?> >
			<?php if ( has_post_thumbnail() ) : //特色图片?>
				<div class="post-image">
					<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark">
						<?php the_post_thumbnail(); ?>
					</a>
				</div>
			<?php else: //无特色图片?>
				<div class="post-image">
					<img src="<?php echo $matches [0][1];?>" />
				</div>
				<div class="post-header">
					<h3>
						<a href="<?php the_permalink(); ?>" rel="bookmark" class="post-title" title = "<?php the_title(); ?>">
							<?php the_title(); ?>
						</a>
					</h3>
				</div>
			<?php endif;//特色图片结束 ?>
		</li>
		
	<?php elseif ( has_post_format( 'aside' ) ) : //日志形式 ?>
		
		<li id="post-<?php the_ID(); ?>" <?php post_class(); ?> >
			<div class="post-header">
				<h3>
					<a href="<?php the_permalink(); ?>" rel="bookmark" class="post-title" title = "<?php the_title(); ?>">
						<?php the_title(); ?>
					</a>
				</h3>
			</div>
			<div class="post-content">
				<?php 
				if( !post_password_required() ){
					if ( has_excerpt() ) { //文章摘要 
						the_excerpt();
					}else{//无文章摘要 
						echo qq_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 350, '...');
					}
				}else{
					if ( has_excerpt() ) { //密码保护文章摘要 
					echo qq_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_excerpt)), 0, 250, '...');
					}
					echo '密码保护文章，暂无摘要！';
				}
				?>
			</div>
			<div class="post-head">
				<p>
                	<span><i class="fa fa-calendar"></i><?php the_time('Y/m/d'); ?></span>
                	<span><i class="fa fa-eye"></i><?php echo qq_get_post_views(get_the_ID()); ?></span>
                	<span><i class="fa fa-comment-o"></i><?php comments_number( '0', '1', '%' ); ?></span>
                	<span><a href="<?php the_permalink(); ?>" class="post-title" target="_blank" title = "<?php the_title(); ?>">more</a></span>
                </p>
			</div>
		</li>

	<?php elseif ( has_post_format( 'audio' ) ) : //音频形式 ?>
		
		<li id="post-<?php the_ID(); ?>" <?php post_class(); ?> >
			<div class="post-header">
				<h3>
					<a href="<?php the_permalink(); ?>" rel="bookmark" class="post-title" title = "<?php the_title(); ?>">
						<?php the_title(); ?>
					</a>
				</h3>
			</div>
			<div class="post-content">
				<?php 
				if( !post_password_required() ){
					if ( has_excerpt() ) { //文章摘要 
						the_excerpt();
					}else{//无文章摘要 
						the_content();
					}
				}else{
					if ( has_excerpt() ) { //密码保护文章摘要 
					echo qq_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_excerpt)), 0, 250, '...');
					}
					echo '密码保护文章，暂无摘要！';
				}
				?>
			</div>
			<div class="post-head">
				<p>
                	<span><i class="fa fa-calendar"></i><?php the_time('Y/m/d'); ?></span>
                	<span><i class="fa fa-eye"></i><?php echo qq_get_post_views(get_the_ID()); ?></span>
                	<span><i class="fa fa-comment-o"></i><?php comments_number( '0', '1', '%' ); ?></span>
                	<span><a href="<?php the_permalink(); ?>" class="post-title" target="_blank" title = "<?php the_title(); ?>">more</a></span>
                </p>
			</div>
		</li>
		
	<?php elseif ( has_post_format( 'link' ) ) : //心情形式 ?>

		<li id="post-<?php the_ID(); ?>" <?php post_class(); ?> >
			<div class="post-img">
				<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark">
					<img src="<?php echo post_thumbnail_src(); ?>" />
				</a>
			</div>
			<div class="post-content">
				<div class="post-avatar">
					<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark">
						<?php echo get_avatar( get_the_author_meta('email'), 80 ); ?>
					</a>
				</div>
				<div class="post-content-text">
				<?php 
				if( !post_password_required() ){
					if ( has_excerpt() ) { //文章摘要 
						echo qq_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_excerpt)), 0, 66, '...');
					}else{//无文章摘要 
						echo qq_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 66, '...');
					}
				}else{
					if ( has_excerpt() ) { //密码保护文章摘要 
					echo qq_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_excerpt)), 0, 66, '...');
					}
					echo '<p style="margin:20px 0;text-align: center;">密码保护文章，暂无摘要！<p>';
				}
				?>
				</div>
			</div>
		</li>
	
	<?php else: //正常形式 ?>
				
		<li id="post-<?php the_ID(); ?>" <?php post_class(); ?> >
			<div class="post-img">
				<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark">
					<img src="<?php echo post_thumbnail_src(); ?>" />
				</a>
			</div>
			<div class="post-header">
				<h3>
					<a href="<?php the_permalink(); ?>" rel="bookmark" class="post-title" title = "<?php the_title(); ?>">
						<?php the_title(); ?>
					</a>
				</h3>
			</div>
			<div class="post-content">
				<?php 
				if( !post_password_required() ){
					if ( has_excerpt() ) { //文章摘要 
						echo qq_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_excerpt)), 0, 100, '...');
					}else{//无文章摘要 
						echo qq_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 100, '...');
					}
				}else{
					if ( has_excerpt() ) { //密码保护文章摘要 
					echo qq_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_excerpt)), 0, 250, '...');
					}
					echo '<p style="margin:20px 0;text-align: center;">密码保护文章，暂无摘要！<p>';
				}
				?>
			</div>
			<div class="post-head">
				<p>
                	<span><i class="fa fa-calendar"></i><?php the_time('Y/m/d'); ?></span>
                	<span><i class="fa fa-eye"></i><?php echo qq_get_post_views(get_the_ID()); ?></span>
                	<span><i class="fa fa-comment-o"></i><?php comments_number( '0', '1', '%' ); ?></span>
                	<span><a href="<?php the_permalink(); ?>" class="post-title" target="_blank" title = "<?php the_title(); ?>">more</a></span>
                </p>
			</div>
		</li>

	<?php endif;//图片形式 ?>