<?php

/**
 * A unique identifier is defined to store the options in the database and reference them from the theme.
 * By default it uses the theme name, in lowercase and without spaces, but this can be changed if needed.
 * If the identifier changes, it'll appear as if the options have been reset.
 */

function opshui_option_name() {

	// This gets the theme name from the stylesheet
	$themename = get_option( 'stylesheet' );
	$themename = preg_replace("/\W/", "_", strtolower($themename) );

	$opshui_settings = get_option( 'opshui' );
	$opshui_settings['id'] = $themename;
	update_option( 'opshui', $opshui_settings );
}

/**
 * Defines an array of options that will be used to generate the settings page and be saved in the database.
 * When creating the 'id' fields, make sure to use all lowercase and no spaces.
 */

function opshui_options() {

	// Multicheck Defaults
	$multicheck_defaults = array(
		'one' => '1',
		'five' => '1'
	);

	// Background Defaults
	$background_defaults = array(
		'color' => '',
		'image' => '',
		'repeat' => 'repeat',
		'position' => 'top center',
		'attachment'=>'scroll' );

	// Typography Defaults
	$typography_defaults = array(
		'face' => 'yahei',
		'style' => 'normal',
		'color' => '#383121' );
		
	$typography_content = array(
		'size' => '13px',
		'face' => 'yahei',
		'style' => 'normal',
		'color' => '#000000' );
		
	// Typography Options
	$typography_options = array(
		'sizes' => false
	);

	// Pull all the categories into an array
	$options_categories = array();
	$options_categories_obj = get_categories();
	foreach ($options_categories_obj as $category) {
		$options_categories[$category->cat_ID] = $category->cat_name;
	}

	// Pull all the pages into an array
	$options_pages = array();
	$options_pages_obj = get_pages('sort_column=post_parent,menu_order');
	$options_pages[''] = '选择页面:';
	foreach ($options_pages_obj as $page) {
		$options_pages[$page->ID] = $page->post_title;
	}


	// If using image radio buttons, define a directory path
	$imagepath =  THEME_URI . '/images/';
	$adsdesc =  __('可添加任意广告联盟代码或自定义代码', 'haoui');

	$options = array();

	/**全站设置**/
	$options[] = array(
		'name' => __('全站设置', 'haoui'),
		'type' => 'heading');

	$options[] = array(
		'name' => __('网站自动添加关键字和描述', 'haoui'),
		'id' => 'site_keywords_description_s',
		'type' => "checkbox",
		'std' => true,
		'desc' => __(' 开启 ', 'haoui').__('（开启后所有页面将自动使用主题配置的关键字和描述，具体规则可以自行查看页面源码得知）', 'haoui'));

	$options[] = array(
		'name' => __('文章关键字和描述自定义', 'haoui'),
		'id' => 'post_keywords_description_s',
		'type' => "checkbox",
		'std' => false,
		'desc' => __(' 开启 ', 'haoui').__('（开启后你需要在编辑文章的时候书写关键字和描述，如果为空，将自动使用主题配置的关键字和描述；开启这个必须开启上面的“网站自动添加关键字和描述”开关）', 'haoui'));

	$options[] = array(
		'name' => __('首页关键字(keywords)', 'haoui'),
		'id' => 'keywords',
		'std' => '123,12345',
		'desc' => __('关键字有利于SEO优化，建议个数在5-10之间，用英文逗号隔开', 'haoui'),
		'settings' => array(
			'rows' => 2
		),
		'type' => 'textarea');

	$options[] = array(
		'name' => __('首页描述(description)', 'haoui'),
		'id' => 'description',
		'std' => __('123 一个高端大气上档次的网站', 'haoui'),
		'desc' => __('描述有利于SEO优化，建议字数在30-70之间', 'haoui'),
		'settings' => array(
			'rows' => 2
		),
		'type' => 'textarea');
		
	$options[] = array(
		'name' => __('网站icon地址', 'haoui'),
		'id' => 'blog_icon',
		'std' => "",
		'desc' => __('网站的选项卡icon图标地址', 'haoui'),
		'settings' => array(
			'rows' => 2
		),
		'type' => 'text');
		
	$options[] = array(
		'name' => __('网站logo地址', 'haoui'),
		'id' => 'blog_logo',
		'std' => "",
		'desc' => __('网站的顶部logo和登录logo', 'haoui'),
		'settings' => array(
			'rows' => 2
		),
		'type' => 'text');

	$options[] = array(
		'name' => __('全站ajax', 'haoui'),
		'id' => 'qq_ajax_q',
		'type' => "checkbox",
		'std' => true,
		'desc' => __(' 开启 ', 'haoui'));

	$options[] = array(
		'name' => __("主题风格", 'haoui'),
		'desc' => __("15种颜色供选择，点击选择你喜欢的颜色，保存后前端展示会有所改变。", 'haoui'),
		'id' => "theme_skin",
		'std' => "159b76",
		'type' => "colorradio",
		'options' => array(
			'159b76' => 1,
			'4b8b8b' => 2,
			'9E508E' => 3,
			'5C7CA5' => 4,
			'A5735C' => 5,
			'8EA55C' => 6,
			'68A55C' => 7,
			'457DB1' => 8,
			'8664AA' => 9,
			'C07A64' => 10,
			'8AC78F' => 11,
			'8A998C' => 12,
			'539C65' => 13,
			'9C5388' => 14,
			'808080' => 15
		)
	);

	$options[] = array(
		'id' => 'theme_skin_custom',
		'std' => "",
		'desc' => __('不喜欢上面提供的颜色，你好可以在这里自定义设置，如果不用自定义颜色清空即可（默认不用自定义）', 'haoui'),
		'type' => "color");

	$options[] = array(
		'name' => __('首页文章布局', 'haoui'),
		'id' => 'fengge',
		'std' => 'jingdian_off',
		'type' => "radio",
		'options' => array(
			'jingdian_off' => __('经典列表', 'haoui'),
			'fangge_off' => __('方格平铺', 'haoui')
		));
		
	$options[] = array(
		'name' => __('网站整体变灰', 'haoui'),
		'id' => 'site_gray',
		'type' => "checkbox",
		'std' => false,
		'desc' => __(' 开启 ', 'haoui').__('（支持IE、Chrome，基本上覆盖了大部分用户，不会降低访问速度）', 'haoui'));

	$options[] = array(
		'name' => __('网站底部信息', 'haoui'),
		'id' => 'footer_seo',
		'std' => "",
		'desc' => __('备案号等底部信息可写于此', 'haoui'),
		'settings' => array(
			'rows' => 2
		),
		'type' => 'textarea');

	/**文章设置**/
	$options[] = array(
		'name' => __('文章设置', 'haoui'),
		'type' => 'heading');
		
	$options[] = array(
		'name' => __('设置文章默认缩略图'),
		'id' => 'qq_post_thumbnail',
		'desc' => __('当文章无图或者没有指定特色图像的时候，默认显示该张图片作为文章缩略图'),
		'std' => '',
		'type' => 'upload');
		
	$options[] = array("name" => __("读者墙", "haoui"), "id" => "readwall_limit_time", "std" => 200, "class" => "mini", "desc" => __("限制在多少月内，单位：月", "haoui"), "type" => "text");

	$options[] = array("id" => "readwall_limit_number", "std" => 200, "class" => "mini", "desc" => __("显示个数", "haoui"), "type" => "text");
	
	$options[] = array(
		'name' => __('文章页尾版权', 'haoui'),
		'id' => 'post_copyright_s',
		'type' => "checkbox",
		'std' => true,
		'desc' => __(' 开启 ', 'haoui'));
		
	$options[] = array(
		'name' => __('文章页尾版权提示字符', 'haoui'),
		'id' => 'post_copyright',
		'std' => __('未经允许不得转载', 'haoui'),
		'type' => 'text');

	$options[] = array(
		'name' => __('文章分享按钮', 'haoui'),
		'id' => 'post_share',
		'type' => "checkbox",
		'std' => true,
		'desc' => __(' 开启 ', 'haoui'));

	$options[] = array(
		'name' => __('文章页尾猜你喜欢', 'haoui'),
		'id' => 'post_guess',
		'type' => "checkbox",
		'std' => true,
		'desc' => __(' 开启 ', 'haoui'));
	
	/**顶部幻灯片**/
	$options[] = array(
		'name' => __('顶部幻灯片', 'haoui'),
		'type' => 'heading');

	$options[] = array(
		'name' => __('幻灯片', 'haoui'),
		'id' => 'focus_s',
		'std' => true,
		'desc' => __(' 在首页开启（开启以后下方功能才可用）', 'haoui'),
		'type' => 'checkbox');
		
	$options[] = array(
		'name' => __('宽屏幻灯片', 'haoui'),
		'id' => 'focus_ss',
		'std' => true,
		'desc' => __('是否开启位于首页的最顶部宽屏幻灯片', 'haoui'),
		'type' => 'checkbox');
		
	$options[] = array(
		'name' => __('宽屏幻灯片显示文章数量'),
		'desc' => __('首页幻灯片显示文章的数量，不要超过6篇，建议6篇'),
		'id' => 'qq_slide_number',
		'std' => '4',
		"class" => "mini",
		'type' => 'text');
		
	$options[] = array(
		'name' => __('宽屏幻灯片显示指定分类的文章'),
		'desc' => __('首页幻灯片轮播指定分类中的文章，填上分类id（数字）即可，多个分类用英文符号“,”隔开（例如：1,2），不可留空。如果需要展示推荐的文章，可以在编辑文章时，下方的【文章拓展】中，勾选【推送至首页幻灯片】。'),
		'id' => 'qq_slide_fenlei',
		"class" => "mini",
		'type' => 'text');
		
	$options[] = array(
		'name' => __('资讯幻灯片', 'haoui'),
		'id' => 'focus_sss',
		'std' => true,
		'desc' => __('是否开启位于首页最顶部宽屏下面的资讯幻灯片', 'haoui'),
		'type' => 'checkbox');

	/**纯QQ风格**/
	$options[] = array(
		'name' => __('纯QQ风格', 'haoui'),
		'type' => 'heading' );

	$options[] = array(
		'name' => __('QQ风格开启', 'haoui'),
		'id' => 'qq_fengge',
		'std' => false,
		'desc' => __(' 开启', 'haoui'),
		'type' => 'checkbox');

	$options[] = array(
		'name' => __('QQ信息', 'haoui'),
		'id' => 'qq_zhanghao',
		'std' => '',
		'desc' => __('qq帐号', 'haoui'),
		'type' => 'text');

	$options[] = array(
		'id' => 'qq_wangming',
		'std' => '',
		'desc' => __('qq网名', 'haoui'),
		'type' => 'text');

	$options[] = array(
		'id' => 'qq_weibo',
		'std' => '',
		'desc' => __('qq微博', 'haoui'),
		'type' => 'text');

	$options[] = array(
		'id' => 'qq_qianming',
		'std' => '做我自己！',
		'desc' => __('qq签名', 'haoui'),
		'type' => 'text');

	/**社会化登录**/
	$options[] = array(
		'name' => __('社会化登录', 'haoui'),
		'type' => 'heading' );

	$options[] = array(
		'name' => __('导航条登录按钮', 'haoui'),
		'id' => 'nav_login',
		'std' => false,
		'desc' => __('开启', 'haoui'),
		'type' => 'checkbox');
		
	$options[] = array(
		'name' => __('腾讯QQ登陆', 'haoui'),
		'id' => 'qq_login_on',
		'std' => true,
		'desc' => __('开启', 'haoui'),
		'type' => "checkbox");
		
	$options[] = array(
		'id' => 'qq_key',
		'std' => '',
		'desc' => __('App Key', 'haoui'),
		'type' => 'text');
		
	$options[] = array(
		'id' => 'qq_secret',
		'std' => '',
		'desc' => __('App Secret', 'haoui'),
		'type' => 'text');

	$options[] = array(
		'name' => __('新浪微博登陆', 'haoui'),
		'id' => 'sina_login_on',
		'std' => true,
		'desc' => __('开启', 'haoui'),
		'type' => "checkbox");

	$options[] = array(
		'id' => 'sina_key',
		'std' => '',
		'desc' => __('App Key', 'haoui'),
		'type' => 'text');
		
	$options[] = array(
		'id' => 'sina_secret',
		'std' => '',
		'desc' => __('App Secret', 'haoui'),
		'type' => 'text');

	/**用户中心**/
	$options[] = array(
		'name' => __('用户中心', 'haoui'),
		'type' => 'heading' );

	$options[] = array(
		'name' => '用户中心',
		'desc' => '选择用户中心页面',
		'id' => 'user_url',
		'type' => 'select',
		'class' => 'mini',
		'options' => $options_pages
	);

	$options[] = array(
		'name' => '用户信息',
		'desc' => '选择用户信息页面',
		'id' => 'user_profile',
		'type' => 'select',
		'class' => 'mini',
		'options' => $options_pages
	);

	$options[] = array(
		'name' => '用户投稿',
		'desc' => '选择投稿页面，否则不显示投稿按钮',
		'id' => 'tou_url',
		'type' => 'select',
		'class' => 'mini',
		'options' => $options_pages
	);

	$options[] = array(
		'name' => '',
		'desc' => '非管理员不允许进入后台',
		'id' => 'no_admin',
		'std' => '0',
		'type' => 'checkbox'
	);

	
	/**侧边栏播放器**/
	$options[] = array(
		'name' => __('侧边栏播放器', 'haoui'),
		'type' => 'heading' );

	$options[] = array(
		'name' => __('播放器开关', 'haoui'),
		'id' => 'no_player',
		'type' => "checkbox",
		'std' => false,
		'desc' => __(' 开启 ', 'haoui'));
		
	$options[] = array(
		'name' => __('网易云音乐ID', 'haoui'),
		'id' => 'wangyiyun_id',
		'std' => '',
		'desc' => __('网易云音乐个人主页的ID,无则填NO', 'haoui'),
		'type' => 'text');	

	$options[] = array(
		'name' => __('播放列表名称', 'haoui'),
		'id' => 'bf_mc',
		'std' => '',
		'type' => 'text');
		
	$options[] = array(
		'name' => __('访客提示内容', 'haoui'),
		'id' => 'fk_ts',
		'std' => '',
		'desc' => __('设置欢迎语，比如：欢迎访问本站。留空则不显示', 'haoui'),
		'type' => 'text');

	$options[] = array(
		'name' => __('是否自动播放', 'haoui'),
		'id' => 'sf_bf',
		'std' => '',
		'desc' => __('YES & NO', 'haoui'),
		'type' => 'text');

	$options[] = array(
		'name' => __('是否随机专辑', 'haoui'),
		'id' => 'sf_zj',
		'std' => '',
		'desc' => __('YES & NO', 'haoui'),
		'type' => 'text');
	
	$options[] = array(
		'name' => __('是否随机歌曲', 'haoui'),
		'id' => 'sf_gq',
		'std' => '',
		'desc' => __('YES & NO', 'haoui'),
		'type' => 'text');
	
	$options[] = array(
		'name' => __('是否开启歌词', 'haoui'),
		'id' => 'sf_gc',
		'std' => '',
		'desc' => __('YES & NO', 'haoui'),
		'type' => 'text');
		
	$options[] = array(
		'name' => __('自动隐藏时间', 'haoui'),
		'id' => 'sf_st',
		'std' => '',
		'desc' => __('YES & NO', 'haoui'),
		'type' => 'text');

	/**微博信息页面**/
	$options[] = array(
		'name' => __('微博信息页面', 'haoui'),
		'type' => 'heading' );
		
	$options[] = array(
		'name' => __('微博API信息', 'haoui'),
		'id' => 'App_Key',
		'std' => '',
		'desc' => __('App Key', 'haoui'),
		'type' => 'text');
		
	$options[] = array(
		'id' => 'App_Secret',
		'std' => '',
		'desc' => __('App Secret', 'haoui'),
		'type' => 'text');
		
	$options[] = array(
		'id' => 'Access_token',
		'std' => '',
		'desc' => __('Access token', 'haoui'),
		'type' => 'text');

	$options[] = array(
		'id' => 'w_uid',
		'std' => '',
		'desc' => __('uid', 'haoui'),
		'type' => 'text');

	$options[] = array(
		'name' => __('是否显示图片', 'haoui'),
		'id' => 'wbpic',
		'std' => 'wbpic_off',
		'type' => "radio",
		'options' => array(
			'wbpic_off' => __('不显示图片', 'haoui'),
			'wbspic_off' => __('显示缩略图', 'haoui'),
			'wbypic_off' => __('显示原图', 'haoui')
		));
		
	$options[] = array(
		'name' => __('是否显示转发内容', 'haoui'),
		'id' => 'wbzf',
		'std' => 'wbzf_off',
		'type' => "radio",
		'options' => array(
			'wbzf_off' => __('不显示转发内容', 'haoui'),
			'wbzf_on' => __('显示转发内容', 'haoui')
		));
	
	/**自定义代码**/
	$options[] = array(
		'name' => __('自定义代码', 'haoui'),
		'type' => 'heading' );
		
	$options[] = array(
		'name' => __('自定义CSS样式', 'haoui'),
		'desc' => __('位于</head>之前，直接写样式代码，不用添加&lt;style&gt;标签', 'haoui'),
		'id' => 'csscode',
		'std' => '',
		'type' => 'textarea');

	$options[] = array(
		'name' => __('自定义头部代码', 'haoui'),
		'desc' => __('位于</head>之前，这部分代码是在主要内容显示之前加载，通常是CSS样式、自定义的<meta>标签、全站头部JS等需要提前加载的代码', 'haoui'),
		'id' => 'headcode',
		'std' => '',
		'type' => 'textarea');

	$options[] = array(
		'name' => __('自定义底部代码', 'haoui'),
		'desc' => __('位于&lt;/body&gt;之前，这部分代码是在主要内容加载完毕加载，通常是JS代码', 'haoui'),
		'id' => 'footcode',
		'std' => '',
		'type' => 'textarea');

	$options[] = array(
		'name' => __('网站统计代码', 'haoui'),
		'desc' => __('位于底部，用于添加第三方流量数据统计代码，如：Google analytics、百度统计、CNZZ、51la，国内站点推荐使用百度统计，国外站点推荐使用Google analytics', 'haoui'),
		'id' => 'trackcode',
		'std' => '',
		'type' => 'textarea');

	return $options;
}



/*
 * This is an example of how to add custom scripts to the options panel.
 * This example shows/hides an option when a checkbox is clicked.
 */

add_action('opshui_custom_scripts', 'opshui_custom_scripts');

function opshui_custom_scripts() { ?>

<script type="text/javascript">
jQuery(document).ready(function($) {

	$('#example_showhidden').click(function() {
  		$('#section-example_text_hidden').fadeToggle(400);
	});
	if ($('#example_showhidden:checked').val() !== undefined) {
		$('#section-example_text_hidden').show();
	}
	
	$('#show_top_teaser').click(function() {
  		$('#section-top_teaser').fadeToggle(400);
	});
	if ($('#show_top_teaser:checked').val() !== undefined) {
		$('#section-top_teaser').show();
	}
	
	$('#show_megamenu').click(function() {
  		$('#section-megamenu, #section-megamenu_title').fadeToggle(400);
	});
	if ($('#show_megamenu:checked').val() !== undefined) {
		$('#section-megamenu, #section-megamenu_title').show();
	}
	
	$('#autoplay').click(function() {
  		$('#section-autoplay_timer').fadeToggle(400);
	});
	if ($('#autoplay:checked').val() !== undefined) {
		$('#section-autoplay_timer').show();
	}

	// Custom Fonts
	$("#heading_typography_face").change(function(){
		if ($(this).val() === 'custom') {
			console.log("hi");
			$('#section-custom_heading_font, #section-custom_heading_font_url').show(400);
		}
		else {
			$('#section-custom_heading_font, #section-custom_heading_font_url').hide(400);
		}
		
	});
	if ($('#heading_typography_face').val() == 'custom') {
		$('#section-custom_heading_font, #section-custom_heading_font_url').show();
	}
	
	$("#content_typography_face").change(function(){
		console.log($(this).val());
		if ($(this).val() === 'custom') {
			console.log("hi");
			$('#section-custom_content_font, #section-custom_content_font_url').show(400);
		}
		else {
			$('#section-custom_content_font, #section-custom_content_font_url').hide(400);
		}
		
	});
	if ($('#content_typography_face').val() == 'custom') {
		$('#section-custom_content_font, #section-custom_content_font_url').show();
	}

});
</script>

<?php
}