### 七、docker-compose 常用命令和指令

#### 1. 概要

默认的模板文件是 `docker-compose.yml`，其中定义的每个服务可以通过 `image` 指令指定镜像或 `build` 指令（需要 Dockerfile）来自动构建。

**注意**如果使用 `build` 指令，在 `Dockerfile` 中设置的选项(例如：`CMD`, `EXPOSE`, `VOLUME`, `ENV` 等) 将会自动被获取，无需在 `docker-compose.yml` 中再次设置。如果设置了会被YML覆盖

#### 2. 常用的docker-compose命令

| 命令                                             | 描述                                                         |
| ------------------------------------------------ | ------------------------------------------------------------ |
| docker-compose up -d                             | 构建建启动容器                                               |
| docker-compose exec  bash                        | 登录到容器中                                                 |
| docker-compose down                              | 删除所有容器,镜像                                            |
| docker-compose ps                                | 显示所有容器                                                 |
| docker-compose restart                           | 重新启动容器                                                 |
| docker-compose run --no-deps --rm php-fpm php -v | 在php-fpm中不启动关联容器，并容器执行php -v 执行完成后删除容器 |
| docker-compose build                             | 构建镜像                                                     |
| docker-compose build --no-cache                  | 不带缓存的构建                                               |
| docker-compose logs                              | 查看的日志                                                   |
| docker-compose logs -f                           | 验证（docker-compose.yml）文件配置，当配置正确时，不输出任何内容，当文件配置错误，输出错误信息 |
| docker-compose pause                             | 暂停容器                                                     |
| docker-compose unpause                           | 恢复容器                                                     |
| docker-compose rm                                | 删除容器（删除前必须关闭容器）                               |
| docker-compose stop                              | 停止容器                                                     |
| docker-compose start                             | 启动容器                                                     |

#### 2.1、image

说明

指定为镜像名称或镜像 ID。如果镜像在本地不存在，`Compose` 将会尝试拉去这个镜像。

栗子

```sh
image: ubuntu
image: mysql:5.7.22
```

#### 2.2、build

说明

指定 `Dockerfile` 所在文件夹的路径。 `Compose` 将会利用它自动构建这个镜像，然后使用这个镜像。

栗子

```
build: ./
build: ./web/
```

#### 2.3、command

说明

覆盖容器启动后默认执行的命令。

栗子

```sh
command:
      --default-authentication-plugin=mysql_native_password
      --character-set-server=utf8mb4
      --collation-server=utf8mb4_general_ci
      --explicit_defaults_for_timestamp=true
      --lower_case_table_names=1
```

#### 2.4、links

说明

链接到其它服务中的容器。使用服务名称（同时作为别名）或服务名称：服务别名 `（SERVICE:ALIAS）` 格式都可以。

栗子

```sh
links:
 - mysql
 - db:database
 - redis
```

使用的别名将会自动在服务容器中的 `/etc/hosts` 里创建。例如：

```sh
172.17.2.111  db
172.17.2.112  database
172.17.2.113  redis
```

#### 2.5、external_links

说明

链接到 docker-compose.yml 外部的容器，甚至 并非 `Compose` 管理的容器。参数格式跟 `links` 类似。

栗子

```
external_links:
 - redis
 - web_db_mysql:mysql
 - web_db_oracle:oracle
 - web_db_oracle:postgre
```

#### 2.6、ports

说明

暴露端口信息。使用宿主：容器 `（HOST:CONTAINER）`格式或者仅仅指定容器的端口（宿主将会随机选择端口）都可以。

栗子

```
ports:
 - "6379"
 - "8000:8000"
 - "46200:22"
 - "127.0.0.1:8080:8080"
```

*注：当使用 HOST:CONTAINER 格式来映射端口时，如果你使用的容器端口小于 60 你可能会得到错误得结果，因为 YAML 将会解析 xx:yy 这种数字格式为 60 进制。所以建议采用字符串格式。*

#### 1.7、expose

说明

暴露端口，但不映射到宿主机，只被连接的服务访问。可以指定内部端口为参数

栗子

```sh
expose:
 - "3307"
 - "6380"
```

#### 1.8、volumes

说明

卷挂载路径设置。可以设置宿主机路径 （`HOST:CONTAINER`） 或加上访问模式 （`HOST:CONTAINER:ro 或者rw`）。

```sh
volumes:
 - ./mysql/data:/var/lib/mysql 
 - ./configs:/etc/configs/:ro
```

#### 1.9、volumes_from

说明

从另一个服务或容器挂载它的所有卷。

栗子

```sh
volumes_from:
 - service_name
 - container_name
```

#### 1.10、environment

说明

设置环境变量。只给定名称的变量会自动获取它在 Compose 主机上的值，可以用来防止泄露不必要的数据。

栗子

```
environment:
	  MYSQL_ROOT_PASSWORD: root
	  TZ: Asia/Shanghai
```

#### 1.11、networks

说明

用于设置指定网络,子标签aliases用于设置服务别名，相同的别名可以在不同的网络中拥有不同的识别别名。

可以在service中使用,也可以在顶级标签中使用

栗子

```
services:
  some-service:
    networks:
      some-network:
        aliases:
         - alias1
         - alias3
      other-network:
        aliases:
         - alias2
# 定义网络         
networks:
   default:
    external:
      name: app
```



### 八、Docker Compose-网络设置

#### 一、概述

随着微服务的事件，应用的越来越多， 经常会碰到需要多个容器共同协作， 这样就需要多个容器之间能够互相访问。Docker提供了映射容器端口到宿主机和容器互联机制来为容器提供网络服务。随着 docker 的快速发展，其网络架构也在不断的演进。

#### 二、容器网络模型(了解)

Docker在 1.9 版本中引入了一整套的 docker network 子命令和跨主机网络支持。允许用户可以根据他们应用的拓扑架构创建虚拟网络并将容器接入其所对应的网络。网络部分代码就已经被抽离并单独成为了 docker 的网络库(libnetwork)。在此之后，容器的网络模式也被抽象变成了统一接口的驱动。
为了标准化网络驱动的开发步骤和支持多种网络驱动，docker 公司在 libnetwork 中使用了 CNM(Container Network Model)。**CNM 定义了构建容器虚拟化网络的模型，同时还提供了可以用于开发多种网络驱动的标准化接口和组件**

CNM的理念是提供可以**跨不同网络基础架构可实现移植的应用**。这个模型平衡了应用的可移植性同时不会损失基础架构原有的各种特性和功能。

![](https://tigerfive.oss-cn-beijing.aliyuncs.com/20201215001802.png)

#### CNM主要有三部分组成

- 沙箱(SandBox)--一个沙箱包含了容器的网络配置。这里包括了容器接口的管理，路由表，和DNS设定。一个沙箱可以包含多个来自不同网络的端点，可以同时连接多个网络。
- 端点(Endpoint)--沙箱通过端点来连接网络。端点结构的存在使到应用与网络的连接实现虚拟化。这样有助于维护应用的可移值性，因此一个服务可以在无须知道如何去连接网络的情况下使用不同类型的网络驱动。
- 网络(Network)--CNM并不是OSI模型中说的网络层。而是由Linux桥接，VLan等来实现。网络收集了所有连接在其上的端点，并实现了这些端点的互连。端点如果不连接到其中一个网络，那么将无法与外界连接。

#### CNM驱动接口

容器连网模型提供了两个可拔插且开放的接口供用户使用，这些接口是用于通讯，利用供应商提供的附加功能，网络可见性，或网络控制等方面。目前存在以下网络驱动：

- 网络驱动(Network Drivers)--Docker网络驱动提供了使网络可以工作的具体实现。他们是可拔插的，所以很易于支持不同的用户使用场景。多个网络驱动可同时用于指定的Docker引擎和群集。有以下两个广泛使用的CNM网络驱动：
  - 内置网络驱动(Native Network Drivers)--内置网络驱动是内置于Docker引擎，并随Docker提供的驱动。有多个驱动可供选择，以支持不同的功能，如overlay网络和local bridge网络。
  - 远程网络驱动(Remote Network Drivers)--远程网络驱动是由社区或其它供应商建立的网络驱动。这些驱动可用于与现有的软件或硬件环境进行集成。用户也可以建立自己的网络驱动以达成各种特殊需求。
- IPAM（IP地址管理）驱动--Docker有一个内置的IP地址管理驱动，在没有特别指定IP的情况下，它会为网络和端点提供了默认的子网或IP地址。IP地址通过网络(docker network create)，容器(docker container create)和服务(docker service create)创建指令来人工分配。远程IPAM驱动也存在和提供了集成到现有IPAM的工具。

#### Docker内置网络驱动

Docker内置网络驱动是Docker引擎的一部份不需要任何额外模块。他们可以被docker network命令所调用。以下是现存的内置网络驱动：

| 驱动        | 描述                                                         |
| :---------- | :----------------------------------------------------------- |
| **Host**    | 没有命名空间隔离，主机上的所有接口都可以直接被容器使用。     |
| **Bridge**  | 受Docker管理的Linux桥接网络。默认在同一个bridge网络的容器都可以相互通迅。 容器的外部访问也可以使用bridge驱动来设置。 |
| **Overlay** | 提供多主机的容器网络互连。同时使用了本地Linux桥接网络和VXLAN技术实现容器之间跨物理网络架构的连接。 |
| **MACVLAN** | 使用MACVLAN桥接模式建立容器接口和主机接口之间的连接。实现为容器提供在物理网络中可路由的IP地址。 此外VLAN可以被中继至macvlan驱动以强制实现容器的2层分段。 |
| **None**    | 容器具有属于自己的网络栈和网络命名空间，但并在容器内添加网络接口。如没有其它的设置，则容器将完全独立于其它网络。 |

  

参考文章

https://success.docker.com/article/networking

https://blog.csdn.net/docerce/article/details/79278568



### 九、Docker Compose-网络设置二

#### 一、概述

默认情况下，Compose 会为我们的应用创建一个网络，服务的每个容器都会加入该网络中。这样，容器就可被该网络中的其他容器访问，不仅如此，**该容器还能以服务名称作为 Hostname 被其他容器访问**。

默认情况下，应用程序的网络名称基于 Compose 的工程名称，而项目名称基于 `docker-compose.yml` 所在目录的名称。如需修改工程名称，可使用 `--project-name` 标识或 `COMPOSE_PORJECT_NAME` 环境变量。

假如一个应用程序在名为 myapp 的目录中，并且 `docker-compose.yml` 如下所示：

```yaml
version: '3'
services:
  web:
    build: .
    ports:
      - "8000:8000"
  db:
    image: mysql
```

当我们运行 `docker-compose up` 时，将会执行以下几步：

- 创建一个名为 **myapp_default** 的网络
- 使用 web 服务的配置创建容器，它以 **web** 这个名称加入网络 myapp_default
- 使用 db 服务的配置创建容器，它以 **db** 这个名称加入网络 myapp_default

容器间可使用服务名称（web 或 db）作为 Hostname 相互访问。例如，web 这个服务可使用 `postgres://db:5432` 访问 db 容器。

当服务的配置发生更改时，可使用 `docker-compose up` 命令更新配置。此时，Compose 会删除旧容器并创建新容器。新容器会以不同的 IP 地址加入网络，名称保持不变。任何指向旧容器的连接都会被关闭，容器会重新找到新容器并连接上去。

#### 二、使用 links

默认情况下，服务之间可使用服务名称相互访问。links 允许我们定义一个别名，从而使用该别名访问其他服务。

```yaml
version: '2'
services:
  web:
    build: .
    links:
      - "db:database"
  db:
    image: postgres
```

#### 三、自定义网络

一些场景下，默认的网络配置满足不了我们的需求，此时我们可使用 networks 命令自定义网络。networks 命令允许我们创建更加复杂的网络拓扑并指定自定义网络驱动和选项。不仅如此，我们还可使用 networks 将服务连接到不是由 Compose 管理的、外部创建的网络。

```yaml
version: '3'
services:
  proxy:
    build: nginx
    networks:
      - front
  app:
    build: ./app
    networks:
      - front
      - back
  db:
    image: postgres
    networks:
      - back

networks:
  front:
    # Use a custom driver
    driver: custom-driver-1
  back:
    # Use a custom driver which takes special options
    driver: custom-driver-2
    driver_opts:
      foo: "1"
      bar: "2"
```

其中，proxy 服务与 db 服务隔离，两者分别使用自己的网络；app 服务可与两者通信。使用 networks 命令，即可方便实现服务间的网络隔离与连接。

#### 四、配置默认网络

```yaml
version: '3'
services:
  web:
    build: .
    ports:
      - "8000:8000"
  db:
    image: postgres

networks:
  default:
    driver: custom-driver-1
```

这样，就可为该应用指定自定义的网络驱动

#### 五、已存在的网络

我们可以预先创建一个名为 myapp 的网络，让 Compose  加入这个新创建的网络，使所有 Compose  可以通信，此时使用 external 选项。

```bash
# 创建网络
docker network create <Network Name>
# 查看已存在的网络
docker network list
```

```yaml
networks:
  default:
    external:
      name: web
```



### 十、Docker 可视化

#### 一、Docker常见的几款web工具：

- portainer(常用)
- docker UI
- shipyard

#### 二、什么是Portainer？

Portainer是Docker的图形化管理工具，提供状态显示面板、应用模板快速部署、容器镜像网络数据卷的基本操作（包括上传下载镜像，创建容器等操作）、事件日志显示、容器控制台操作、Swarm集群和服务等集中管理和操作、登录用户管理和控制等功能。功能十分全面，基本能满足中小型单位对容器管理的全部需求

#### 三、安装

##### 下载镜像

```
docker pull portainer/portainer
```

##### 运行Portainer(单机版)

```
docker  run -d \
 -p 9000:9000 \
 -v /var/run/docker.sock:/var/run/docker.sock \
 portainer/portainer
```

##### 访问 http://localhost:9000/

![](https://tigerfive.oss-cn-beijing.aliyuncs.com/20201215003654.png)

##### 设置管理员密码

![](https://tigerfive.oss-cn-beijing.aliyuncs.com/20201215003651.png)



#### 四、汉化版本

##### 下载

[下载汉化包](https://dl.quchao.net/Soft/Portainer-CN.zip)

##### 创建public目录

##### 解压汉化包

```
unzip -o Portainer-CN.zip
```

##### 创建数据卷

```
docker volume create portainer_data
```

##### 创建并启动容器

```
docker run -d -p 9000:9000 -v /var/run/docker.sock:/var/run/docker.sock -v portainer-data:/portainer-data -v /public:/public portainer/portainer:1.20.2
```

