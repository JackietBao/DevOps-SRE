# 容器化技术Docker

![](https://i.loli.net/2019/06/09/5cfd1e94f1fb169708.jpg)

 **Docker介绍**
官网：
 docker.io
  docker.com
    公司名称：原名dotCloud  14年改名为docker
    容器产品：docker 16年已经被更名为**Moby**

​    docker-hub
​        docker.io

## docker容器历史

和虚拟机一样，容器技术也是一种资源隔离的虚拟化技术。我们追溯它的历史，会发现它的技术雏形早已有之。

**容器简史**

容器概念始于 1979 年提出的 UNIX chroot，它是一个 UNIX 操作系统的系统调用，将一个进程及其子进程的根目录改变到文件系统中的一个新位置，让这些进程只能访问到这个新的位置，从而达到了进程隔离的目的。

2000 年的时候 FreeBSD 开发了一个类似于 chroot 的容器技术 Jails，这是最早期，也是功能最多的容器技术。Jails 英译过来是监狱的意思，这个“监狱”（用沙盒更为准确）包含了文件系统、用户、网络、进程等的隔离。

2001 Linux 也发布自己的容器技术 Linux VServer，2004 Solaris 也发布了 Solaris Containers，两者都将资源进行划分，形成一个个 zones，又叫做虚拟服务器。

2005 年推出 OpenVZ，它通过对 Linux 内核进行补丁来提供虚拟化的支持，每个 OpenVZ 容器完整支持了文件系统、用户及用户组、进程、网络、设备和 IPC 对象的隔离。

2007 年 Google 实现了 Control Groups( cgroups )，并加入到 Linux 内核中，这是划时代的，为后期容器的资源配额提供了技术保障。

2008 年基于 cgroups 和 linux namespace 推出了第一个最为完善的 Linux 容器 LXC。

2013 年推出到现在为止最为流行和使用最广泛的容器 Docker，相比其他早期的容器技术，Docker 引入了一整套容器管理的生态系统，包括分层的镜像模型，容器注册库，友好的 Rest API。

2014 年 CoreOS 也推出了一个类似于 Docker 的容器 Rocket，CoreOS 一个更加轻量级的 Linux 操作系统，在安全性上比 Docker 更严格。

2016 年微软也在 Windows 上提供了容器的支持，Docker 可以以原生方式运行在 Windows 上，而不是需要使用 Linux 虚拟机。

基本上到这个时间节点，容器技术就已经很成熟了，再往后就是容器云的发展，由此也衍生出多种容器云的平台管理技术，其中以 kubernetes 最为出众，有了这样一些细粒度的容器集群管理技术，也为微服务的发展奠定了基石。因此，对于未来来说，应用的微服务化是一个较大的趋势。

**为什么需要容器**

其一，这是技术演进的一种创新结果，其二，这是人们追求高效生产活动的一种工具。

随着软件开发的发展，相比于早期的集中式应用部署方式，现在的应用基本都是采用分布式的部署方式，一个应用可能包含多种服务或多个模块，因此多种服务可能部署在多种环境中，如虚拟服务器、公有云、私有云等，由于多种服务之间存在一些依赖关系，所以可能存在应用在运行过程中的动态迁移问题，那这时如何保证不同服务在不同环境中都能平滑的适配，不需要根据环境的不同而去进行相应的定制，就显得尤为重要。

就像货物的运输问题一样，如何将不同的货物放在不同的运输机器上，减少因货物的不同而频繁进行货物的装载和卸载，浪费大量的人力物力。

为此人们发明了集装箱，将货物根据尺寸形状等的不同，用不同规格的集装箱装载，然后再放到运输机上运输，由于集装箱密封，只有货物到达目的地才需拆封，在运输过程能够再不同运输机上平滑过渡，所以避免了资源的浪费。

因此集装箱被誉为是运输业与世界贸易最重要的发明。

Docker 容器的思想就是采用集装箱思想，为应用提供了一个基于容器的标准化运输系统。Docker 可以将任何应用及其依赖打包成一个轻量级、可移植、自包含的容器。容器可以运行在几乎所有的操作系统上。这样容器就可以跑在任何环境中，因此才有了那句话：

Build Once, Run Anywhere

这种集装箱的思想我们也能从 Docker 的 Logo 中看出来，这不就是一堆集装箱吗？

## Docker对paas的降维打击(了解)

```
IaaS  infrastructure as a service 基础设施及服务
PaaS platform as a service
SaaS software as a service
dSaaS data storage as a service 
CaaS   container as a service

PaaS 项目成功的主要原因
     是它提供了一种名叫"应用托管"的能力。 
     paas之前主流用户的普遍用法是租一批 AWS 或者 OpenStack 的虚拟机，然后像以前管理物理服务器那样，用脚本或者手工的方式在这些机器上部署应用。

     这个部署过程会碰到云端虚拟机和本地环境不一致的问题，所以当时的云计算服务，比的就是谁能更好地模拟本地服务器环境，能带来更好的"上云"体验。而 PaaS 开源项目的出现，就是当时解决这个问题的一个最佳方案。

PaaS 如何部署应用
    虚拟机创建好之后，运维人员只需要在这些机器上部署一个 Cloud Foundry 项目，然后开发者只要执行一条命令就能把本地的应用部署到云上，这条命令就是：
    # cf push " 应用 "

PaaS 项目的核心组件
    像 Cloud Foundry 这样的 PaaS 项目，最核心的组件就是一套应用的打包和分发机制。 Cloud Foundry 为每种主流编程语言都定义了一种打包格式，而"cf push"的作用，基本上等同于用户把应用的可执行文件和启动脚本打进一个压缩包内，上传到云上 Cloud Foundry 的存储中。接着，Cloud Foundry 会通过调度器选择一个可以运行这个应用的虚拟机，然后通知这个机器上的 Agent 把应用压缩包下载下来启动。

    由于需要在一个虚拟机上启动很多个来自不同用户的应用，Cloud Foundry 会调用操作系统的 Cgroups 和 Namespace 机制为每一个应用单独创建一个称作"沙盒"的隔离环境，然后在"沙盒"中启动这些应用进程。这就实现了把多个用户的应用互不干涉地在虚拟机里批量自动地运行起来的目的。
    这正是 PaaS 项目最核心的能力。 而这些 Cloud Foundry 用来运行应用的隔离环境，或者说"沙盒"，就是所谓的"容器"。

注：
    Cloud Foundry是当时非常主流非常火的一个PaaS项目
    
    
    
 Docker 镜像
    Docker 项目确实与 Cloud Foundry 的容器在大部分功能和实现原理上都是一样的，可偏偏就是这剩下的一小部分不一样的功能，成了 Docker 项目接下来"呼风唤雨"的不二法宝。这个功能，就是 Docker 镜像。

    恐怕连 Docker 项目的作者 Solomon Hykes 自己当时都没想到，这个小小的创新，在短短几年内就如此迅速地改变了整个云计算领域的发展历程。

PaaS的问题：
    PaaS 之所以能够帮助用户大规模部署应用到集群里，是因为它提供了一套应用打包的功能。可就是这个打包功能，却成了 PaaS 日后不断遭到用户诟病的一个"软肋"。

    根本原因：
        一旦用上了 PaaS，用户就必须为每种语言、每种框架，甚至每个版本的应用维护一个打好的包。这个打包过程，没有任何章法可循，更麻烦的是，明明在本地运行得好好的应用，却需要做很多修改和配置工作才能在 PaaS 里运行起来。而这些修改和配置，并没有什么经验可以借鉴，基本上得靠不断试错，直到你摸清楚了本地应用和远端 PaaS 匹配的"脾气"才能够搞定。

    最后结局是，"cf push"确实是能一键部署了，但是为了实现这个一键部署，用户为每个应用打包的工作可谓一波三折，费尽心机。

    而Docker 镜像解决的，恰恰就是打包这个根本性的问题。 

Docker 镜像的精髓
    所谓 Docker 镜像，其实就是一个压缩包。但是这个压缩包里的内容，比 PaaS 的应用可执行文件 + 启停脚本的组合就要丰富多了。实际上，大多数 Docker 镜像是直接由一个完整操作系统的所有文件和目录构成的，所以这个压缩包里的内容跟你本地开发和测试环境用的操作系统是完全一样的。

这就有意思了：假设你的应用在本地运行时，能看见的环境是 CentOS 7.2 操作系统的所有文件和目录，那么只要用 CentOS 7.2 的 ISO 做一个压缩包，再把你的应用可执行文件也压缩进去，那么无论在哪里解压这个压缩包，都可以得到与你本地测试时一样的环境。当然，你的应用也在里面！

这就是 Docker 镜像最厉害的地方：只要有这个压缩包在手，你就可以使用某种技术创建一个"沙盒"，在"沙盒"中解压这个压缩包，然后就可以运行你的程序了。

更重要的是，这个压缩包包含了完整的操作系统文件和目录，也就是包含了这个应用运行所需要的所有依赖，所以你可以先用这个压缩包在本地进行开发和测试，完成之后，再把这个压缩包上传到云端运行。

在这个过程中，你完全不需要进行任何配置或者修改，因为这个压缩包赋予了你一种极其宝贵的能力：本地环境和云端环境的高度一致！

这，正是 Docker 镜像的精髓。

那么，有了 Docker 镜像这个利器，PaaS 里最核心的打包系统一下子就没了用武之地，最让用户抓狂的打包过程也随之消失了。相比之下，在当今的互联网里，Docker 镜像需要的操作系统文件和目录，可谓唾手可得。

所以，你只需要提供一个下载好的操作系统文件与目录，然后使用它制作一个压缩包即可，这个命令就是：
# docker build " 镜像 "

镜像制作完成，用户就可以让 Docker 创建一个"沙盒"来解压这个镜像，然后在"沙盒"中运行自己的应用，这个命令就是：
# docker run " 镜像 "

Docker 项目给 PaaS 世界带来的"降维打击"
    其实是提供了一种非常便利的打包机制。这种机制直接打包了应用运行所需要的整个操作系统，从而保证了本地环境和云端环境的高度一致，避免了用户通过"试错"来匹配两种不同运行环境之间差异的痛苦过程。
```

## 容器和虚拟机的区别

```
容器和 VM 的主要区别：
容器提供了基于进程的隔离，而虚拟机提供了资源的完全隔离。虚拟机可能需要一分钟来启动，而容器只需要一秒钟或更短。容器使用宿主操作系统的内核，而虚拟机使用独立的内核。Docker 的局限性之一是，它只能用在 64 位的操作系统上。

Docker对服务器端开发/部署带来的变化：
实现更轻量级的虚拟化，方便快速部署
对于部署来说可以极大的减少部署的时间成本和人力成本
Docker支持将应用打包进一个可以移植的容器中，重新定义了应用开发，测试，部署上线的过程，核心理念就
是 Build once, Run anywhere
1）标准化应用发布，docker容器包含了运行环境和可执行程序，可以跨平台和主机使用；
2）节约时间，快速部署和启动，VM启动一般是分钟级，docker容器启动是秒级；
3）方便构建基于SOA架构或微服务架构的系统，通过服务编排，更好的松耦合；
4）节约成本，以前一个虚拟机至少需要几个G的磁盘空间，docker容器可以减少到MB级；
5）方便持续集成，通过与代码进行关联使持续集成非常方便；
6）可以作为集群系统的轻量主机或节点，在IaaS平台上，已经出现了CaaS，通过容器替代原来的主机。

Docker 优势：
1、交付物标准化
Docker是软件工程领域的"标准化"交付组件，最恰到好处的类比是"集装箱"。
集装箱将零散、不易搬运的大量物品封装成一个整体，集装箱更重要的意义在于它提供了一种通用的封装货物的
标准，卡车、火车、货轮、桥吊等运输或搬运工具采用此标准，隧道、桥梁等也采用此标准。以集装箱为中心的
标准化设计大大提高了物流体系的运行效率。
传统的软件交付物包括：应用程序、依赖软件安装包、配置说明文档、安装文档、上线文档等非标准化组件。
Docker的标准化交付物称为"镜像"，它包含了应用程序及其所依赖的运行环境，大大简化了应用交付的模式。

2、一次构建，多次交付
类似于集装箱的"一次装箱，多次运输"，Docker镜像可以做到"一次构建，多次交付"。当涉及到应用程序多副本
部署或者应用程序迁移时，更能体现Docker的价值。

3、应用隔离
集装箱可以有效做到货物之间的隔离，使化学物品和食品可以堆砌在一起运输。Docker可以隔离不同应用程序
之间的相互影响，但是比虚拟机开销更小。
总之，容器技术部署速度快，开发、测试更敏捷；提高系统利用率，降低资源成本。
﻿
Docker的度量：
Docker是利用容器来实现的一种轻量级的虚拟技术，从而在保证隔离性的同时达到节省资源的目的。Docker的
可移植性可以让它一次建立，到处运行。Docker的度量可以从以下四个方面进行：
1）隔离性
 Docker采用libcontainer作为默认容器，代替了以前的LXC。libcontainer的隔离性主要是通过内核的命名空
 间来实现 的，有pid、net、ipc、mnt、uts命令空间，将容器的进程、网络、消息、文件系统和主机名进行隔
 离。
2）可度量性
 Docker主要通过cgroups控制组来控制资源的度量和分配。
3）移植性
 Docker利用AUFS来实现对容器的快速更新。
 AUFS是一种支持将不同目录挂载到同一个虚拟文件系统下的文件系统，支持对每个目录的读写权限管理。AUFS具有层
 的概念，每一次修改都是在已有的只写层进行增量修改，修改的内容将形成新的文件层，不影响原有的层。
4）安全性
 安全性可以分为容器内部之间的安全性；容器与托管主机之间的安全性。
 容器内部之间的安全性主要是通过命名空间和cgroups来保证的。
 容器与托管主机之间的安全性主要是通过内核能力机制的控制，可以防止Docker非法入侵托管主机。

Docker容器使用AUFS作为文件系统，有如下优势：
1）节省存储空间
 多个容器可以共享同一个基础镜像存储。
2）快速部署
 如果部署多个来自同一个基础镜像的容器时，可以避免多次复制操作。
3）升级方便
 升级一个基础镜像即可影响到所有基于它的容器。
4）增量修改
 可以在不改变基础镜像的同时修改其目录的文件，所有的更高都发生在最上层的写操作层，增加了基础镜像的可共
 享内 容。

```



## 容器应用场景

```
# 1. 简化配置

这是Docker公司宣传的Docker的主要使用场景。虚拟机的最大好处是能在你的硬件设施上运行各种配置不一样的平台（软件、系统），Docker在降低额外开销的情况下提供了同样的功能。它能让你将运行环境和配置放在代码中然后部署，同一个Docker的配置可以在不同的环境中使用，这样就降低了硬件要求和应用环境之间耦合度。

# 2. 代码流水线（Code Pipeline）管理

前一个场景对于管理代码的流水线起到了很大的帮助。代码从开发者的机器到最终在生产环境上的部署，需要经过很多的中间环境。而每一个中间环境都有自己微小的差别，Docker给应用提供了一个从开发到上线均一致的环境，让代码的流水线变得简单不少。

# 3. 提高开发效率

这就带来了一些额外的好处：Docker能提升开发者的开发效率。如果你想看一个详细一点的例子，可以参考Aater在

DevOpsDays Austin 2014 

大会或者是DockerCon上的演讲。

不同的开发环境中，我们都想把两件事做好。一是我们想让开发环境尽量贴近生产环境，二是我们想快速搭建开发环境。

理想状态中，要达到第一个目标，我们需要将每一个服务都跑在独立的虚拟机中以便监控生产环境中服务的运行状态。然而，我们却不想每次都需要网络连接，每次重新编译的时候远程连接上去特别麻烦。这就是Docker做的特别好的地方，开发环境的机器通常内存比较小，之前使用虚拟的时候，我们经常需要为开发环境的机器加内存，而现在Docker可以轻易的让几十个服务在Docker中跑起来。

# 4. 隔离应用

有很多种原因会让你选择在一个机器上运行不同的应用，比如之前提到的提高开发效率的场景等。

我们经常需要考虑两点，一是因为要降低成本而进行服务器整合，二是将一个整体式的应用拆分成松耦合的单个服务（译者注：微服务架构）。如果你想了解为什么松耦合的应用这么重要，请参考Steve Yege的这篇论文，文中将Google和亚马逊做了比较。

# 5. 整合服务器

正如通过虚拟机来整合多个应用，Docker隔离应用的能力使得Docker可以整合多个服务器以降低成本。由于没有多个操作系统的内存占用，以及能在多个实例之间共享没有使用的内存，Docker可以比虚拟机提供更好的服务器整合解决方案。

# 6. 调试能力

Docker提供了很多的工具，这些工具不一定只是针对容器，但是却适用于容器。它们提供了很多的功能，包括可以为容器设置检查点、设置版本和查看两个容器之间的差别，这些特性可以帮助调试Bug。你可以在《Docker拯救世界》的文章中找到这一点的例证。

# 7. 多租户环境

另外一个Docker有意思的使用场景是在多租户的应用中，它可以避免关键应用的重写。我们一个特别的关于这个场景的例子是为IoT（译者注：物联网）的应用开发一个快速、易用的多租户环境。这种多租户的基本代码非常复杂，很难处理，重新规划这样一个应用不但消耗时间，也浪费金钱。

使用Docker，可以为每一个租户的应用层的多个实例创建隔离的环境，这不仅简单而且成本低廉，当然这一切得益于Docker环境的启动速度和其高效的命令。

# 8. 快速部署

在虚拟机之前，引入新的硬件资源需要消耗几天的时间。虚拟化技术（Virtualization）将这个时间缩短到了分钟级别。而Docker通过为进程仅仅创建一个容器而无需启动一个操作系统，再次将这个过程缩短到了秒级。这正是Google和Facebook都看重的特性。
```

## Docker容器基本概念

```
Docker系统
Docker系统有两个程序：docker服务端和docker客户端
    docker服务端：
        是一个服务进程，管理着所有的容器。

    docker客户端：
        扮演着docker服务端的远程控制器，可以用来控制docker的服务端进程。

Docker三大核心组件：
    Docker 镜像 - Docker  images 
    Docker 仓库 - Docker  registeries
    Docker 容器 - Docker  containers 

docker 仓库：
    用来保存镜像，可以理解为代码控制中的代码仓库。同样的，Docker 仓库也有公有和私有的概念。
公有的 Docker  仓库名字是 Docker Hub。Docker Hub  提供了庞大的镜像集合供使用。这些镜像可以是自己创建，或者在别人的镜像基础上创建。Docker 仓库是 Docker 的分发部分。 

Docker 镜像 
    Docker 镜像是 Docker 容器运行时的只读模板，每一个镜像由一系列的层 (layers) 组成。Docker 使用  UnionFS 来将这些层联合到单独的镜像中。UnionFS  允许独立文件系统中的文件和文件夹(称之为分支)被透明覆盖，形成一个单独连贯的文件系统。正因为有了这些层的存在，Docker  是如此的轻量。当你改变了一个 Docker  镜像，比如升级到某个程序到新的版本，一个新的层会被创建。因此，不用替换整个原先的镜像或者重新建立(在使用虚拟机的时候你可能会这么做)，只是一个新的层被添加或升级了。现在你不用重新发布整个镜像，只需要升级，层使得分发 Docker 镜像变得简单和快速。 

    在 Docker 的术语里，一个只读层被称为镜像，一个镜像是永久不会变的。
    由于 Docker 使用一个统一文件系统，Docker 进程认为整个文件系统是以读写方式挂载的。 但是所有的变更都发生顶层的可写层，而下层的原始的只读镜像文件并未变化。由于镜像不可写，所以镜像是无状态的。
每一个镜像都可能依赖于由一个或多个下层的组成的另一个镜像。下层那个镜像是上层镜像的父镜像。

镜像名字：
    registry/repo:tag
    daocloud.io/library/centos:7

基础镜像：
一个没有任何父镜像的镜像，谓之基础镜像。

镜像ID：
所有镜像都是通过一个 64 位十六进制字符串 （内部是一个 256 bit 的值）来标识的。 为简化使用，前 12 个字符可以组成一个短ID，可以在命令行中使用。短ID还是有一定的碰撞机率，所以服务器总是返回长ID。
    
Docker 容器
    Docker 容器和文件夹很类似，一个Docker容器包含了所有的某个应用运行所需要的环境。每一个 Docker 容器都是从 Docker  镜像创建的。Docker 容器可以运行、开始、停止、移动和删除。每一个 Docker 容器都是独立和安全的应用平台，Docker 容器是  Docker 的运行部分。 
```



## docker安装

### 自带源安装

```
CentOS 7 中 Docker 的安装:
Docker 软件包已经包括在默认的 CentOS-Extras 软件源(联网使用centos7u2自带网络Yum源)里。因此想要安装 docker，只需要运行下面的 yum 命令：       
# yum install docker
    
启动 Docker 服务:
    # service docker start
    # chkconfig docker on

    CentOS 7    
    # systemctl start docker.service
    # systemctl enable docker.service

确定docker服务在运行：
结果会显示服务端和客户端的版本，如果只显示客户端版本说明服务没有启动
[root@docker1 yum]# docker version
Client: Docker Engine - Community
 Version:           19.03.4
 API version:       1.40
 Go version:        go1.12.10
 Git commit:        9013bf583a
 Built:             Fri Oct 18 15:52:22 2019
 OS/Arch:           linux/amd64
 Experimental:      false

Server: Docker Engine - Community
 Engine:
  Version:          19.03.4
  API version:      1.40 (minimum version 1.12)
  Go version:       go1.12.10
  Git commit:       9013bf583a
  Built:            Fri Oct 18 15:50:54 2019
  OS/Arch:          linux/amd64
  Experimental:     false
 containerd:
  Version:          1.2.10
  GitCommit:        b34a5c8af56e510852c35414db4c1f4fa6172339
 runc:
  Version:          1.0.0-rc8+dev
  GitCommit:        3e425f80a8c931f88e6d94a8c831b9d5aa481657
 docker-init:
  Version:          0.18.0
  GitCommit:        fec3683

﻿查看docker基本信息：
    #docker info

校验Docker的安装
[root@master ~]# docker run -it ubuntu bash
Unable to find image 'ubuntu:latest' locally
Trying to pull repository daocloud.io/ubuntu ... 
latest: Pulling from daocloud.io/ubuntu
22ecafbbcc4a: Pull complete 
580435e0a086: Pull complete 
Digest: sha256:80c2902178d79f439b13c5a244f3b1ef67ca890dbbe58d19caa13301ca56a505

如果自动进入下面的容器环境，说明﻿ubuntu镜像运行成功，Docker的安装也没有问题：可以操作容器了
root@50a0449d7729:/# pwd     
/
root@50a0449d7729:/# ls
bin  boot  dev  etc  home  lib  lib64  media  mnt  opt  proc  root  run  sbin  srv  sys  tmp  usr  var

```

### docker版本和官方源安装

```
moby、docker-ce与docker-ee
最早时docker是一个开源项目，主要由docker公司维护。
2017年3月1日起，docker公司将原先的docker项目改名为moby，并创建了docker-ce和docker-ee。

三者关系：
    moby是继承了原先的docker的项目，是社区维护的的开源项目，谁都可以在moby的基础打造自己的容器产品
    docker-ce是docker公司维护的开源项目，是一个基于moby项目的免费的容器产品
    docker-ee是docker公司维护的闭源产品，是docker公司的商业产品。

    moby project由社区维护，docker-ce project是docker公司维护，docker-ee是闭源的。

    要使用免费的docker，从https://github.com/docker/docker-ce上获取。
    要使用收费的docker，从https://www.docker.com/products/docker-enterprise上获取。

docker-ce的发布计划
    v1.13.1之后，发布计划更改为:
    Edge:   月版本，每月发布一次，命名格式为YY.MM，维护到下个月的版本发布
    Stable: 季度版本，每季度发布一次，命名格式为YY.MM，维护4个月

安装：
    docker-ce的release计划跟随moby的release计划，可以使用下面的命令直接安装最新的docker-ce:
    # curl -fsSL https://get.docker.com/ | sh

CentOS
   如果是centos，上面的安装命令会在系统上添加yum源:/etc/yum.repos.d/docker-ce.repo 
   # wget https://download.docker.com/linux/centos/docker-ce.repo
   # mv docker-ce.repo /etc/yum.repos.d
   # yum install -y docker-ce

    或者直接下载rpm安装:

    # wget https://download.docker.com/linux/centos/7/x86_64/stable/Packages/docker-ce-17.09.0.ce-1.el7.centos.x86_64.rpm
    # yum localinstall docker-ce-17.09.0.ce-1.el7.centos.x86_64.rpm
    
注意：
    在说docker的时候尽量说Linux docker
    因为Docker on Mac，以及 Windows Docker（Hyper-V 实现），实际上是基于虚拟化技术实现的，跟我们介绍使用的 Linux 容器完全不同。
```

### 国内源安装新版docker

```
使用aliyun docker yum源安装新版docker
删除已安装的Docker

    # yum remove docker \
                  docker-client \
                  docker-client-latest \
                  docker-common \
                  docker-latest \
                  docker-latest-logrotate \
                  docker-logrotate \
                  docker-selinux \
                  docker-engine-selinux \
                  docker-engine

配置阿里云Docker Yum源
    # yum install -y yum-utils device-mapper-persistent-data lvm2 git
    # yum-config-manager --add-repo http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo

安装指定版本
    查看Docker版本：
    # yum list docker-ce --showduplicates

    安装较旧版本（比如Docker 17.03.2) ：
        需要指定完整的rpm包的包名，并且加上--setopt=obsoletes=0 参数：
        # yum install -y --setopt=obsoletes=0 \
        docker-ce-17.03.2.ce-1.el7.centos.x86_64 \
        docker-ce-selinux-17.03.2.ce-1.el7.centos.noarch

    安装Docker新版本（比如Docker 18.03.0)：
        加上rpm包名的版本号部分或不加都可以：
        # yum install docker-ce-18.03.0.ce  -y
        或者
        # yum install docker-ce -y

启动Docker服务：
    #systemctl enable docker
    #systemctl start docker

查看docker版本状态： 
    # docker -v
    Docker version 1.13.1, build 8633870/1.13.1  
    
    # docker version
    Client:
     Version:           18.09.0
     API version:       1.39
     Go version:        go1.10.4
     Git commit:        4d60db4
     Built:             Wed Nov  7 00:48:22 2018
     OS/Arch:           linux/amd64
     Experimental:      false

    Server: Docker Engine - Community
     Engine:
      Version:          18.09.0
      API version:      1.39 (minimum version 1.12)
      Go version:       go1.10.4
      Git commit:       4d60db4
      Built:            Wed Nov  7 00:19:08 2018
      OS/Arch:          linux/amd64
      Experimental:     false
      
查看docker运行状态：
    # docker info
    Containers: 0
     Running: 0
     Paused: 0
     Stopped: 0
    Images: 0
    Server Version: 18.09.0
    Storage Driver: overlay2
     Backing Filesystem: xfs
     Supports d_type: true
     Native Overlay Diff: true
    Logging Driver: json-file
    Cgroup Driver: cgroupfs
    Plugins:
     Volume: local
     Network: bridge host macvlan null overlay
     Log: awslogs fluentd gcplogs gelf journald json-file local logentries splunk syslog
    Swarm: inactive
    Runtimes: runc
    Default Runtime: runc
    Init Binary: docker-init
    containerd version: c4446665cb9c30056f4998ed953e6d4ff22c7c39
    runc version: 4fc53a81fb7c994640722ac585fa9ca548971871
    init version: fec3683
    Security Options:
     seccomp
      Profile: default
    Kernel Version: 3.10.0-957.el7.x86_64
    Operating System: CentOS Linux 7 (Core)
    OSType: linux
    Architecture: x86_64
    CPUs: 4
    Total Memory: 1.934GiB
    Name: docker
    ID: MF5S:ZX25:SWJ3:XEIG:FFHP:5VXF:F5AL:KQFF:KKXP:XZGY:YGTE:EBQF
    Docker Root Dir: /var/lib/docker
    Debug Mode (client): false
    Debug Mode (server): false
    Registry: https://index.docker.io/v1/
    Labels:
    Experimental: false
    Insecure Registries:
     127.0.0.0/8
    Live Restore Enabled: false
    Product License: Community Engine

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

bonding

报错1：
    docker info的时候报如下错误
    bridge-nf-call-iptables is disabled

解决1：
    追加如下配置,然后重启系统
    # vim /etc/sysctl.conf   
    net.bridge.bridge-nf-call-ip6tables = 1
    net.bridge.bridge-nf-call-iptables = 1
    net.bridge.bridge-nf-call-arptables = 1

问题2：
    虚拟机ping百度也能ping通，但是需要等好几秒才出结果，关键是下载镜像一直报错如下
    # docker pull daocloud.io/library/nginx
    Using default tag: latest
    Error response from daemon: Get https://daocloud.io/v2/: dial tcp: lookup daocloud.io on 192.168.1.2:53: read udp   192.168.1.189:41335->192.168.1.2:53: i/o timeout

解决2：
    我的虚拟机用的网关和dns都是虚拟机自己的.1或者.2，把DNS改成8.8.8.8问题就解决了，ping百度也秒出结果
    # vim /etc/resolv.conf
    nameserver 8.8.8.8

```

### 生产docker的环境配置

```
sudo mkdir -p /etc/docker
sudo tee /etc/docker/daemon.json <<-'EOF'
{
  "registry-mirrors": ["https://pilvpemn.mirror.aliyuncs.com"],
  "exec-opts": ["native.cgroupdriver=systemd"],
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "100m"
  },
  "storage-driver": "overlay2"
}
EOF
sudo systemctl daemon-reload
sudo systemctl restart docker
```



### 登入登出docker hub

```
login     Register or log in to a Docker registry
登录到自己的Docker register，需有Docker Hub的注册账号
      # docker login
      Username: test
      Password: 
      Email: xxxx@foxmail.com
      WARNING: login credentials saved in /root/.docker/config.json
      Login Succeeded

logout    Log out from a Docker registry
退出登录
      # docker logout
      Remove login credentials for https://index.docker.io/v1/

注：推送镜像库到私有源（可注册 docker 官方账户，推送到官方自有账户）
```

### 国内镜像源

```
去查看如何使用aliyun的docker镜像库
去查看如何使用网易蜂巢的docker镜像库

Docker 加速器  
使用 Docker 的时候，需要经常从官方获取镜像，但是由于显而易见的网络原因，拉取镜像的过程非常耗时，严重影响使用 Docker 的体验。因此 DaoCloud 推出了加速器工具解决这个难题，通过智能路由和缓存机制，极大提升了国内网络访问 Docker Hub 的速度，目前已经拥有了广泛的用户群体，并得到了 Docker 官方的大力推荐。
如果您是在国内的网络环境使用 Docker，那么 Docker 加速器一定能帮助到您。    

Docker 加速器对 Docker 的版本有要求吗？    
需要 Docker 1.8 或更高版本才能使用，如果您没有安装 Docker 或者版本较旧，请安装或升级。    

Docker 加速器支持什么系统？    
Linux, MacOS 以及 Windows 平台。    

Docker 加速器是否收费？    
DaoCloud 为了降低国内用户使用 Docker 的门槛，提供永久免费的加速器服务，请放心使用。  

国内比较好的镜像源：网易蜂巢、aliyun和daocloud,下面是daocloud配置方式：
﻿Docker Hub并没有在国内部署服务器或者使用国内的CDN服务，因此在国内特殊的网络环境下，镜像下载十分耗时。
为了克服跨洋网络延迟，能够快速高效地下载Docker镜像，可以采用DaoCloud提供的服务Docker Hub Mirror，速度
快很多
1.注册网站账号
2.然后进入你自己的""制台"，选择"加速器"，点"立即开始"，接入你自有的主机，就看到如下的内容了
   curl -sSL https://get.daocloud.io/daotools/set_mirror.sh | sh -s http://f1361XXX.m.daocloud.io
该脚本可以将 --registry-mirror 加入到你的 Docker 配置文件 /etc/docker/daemon.json 中。适用于 Ubuntu14.04、Debian、CentOS6 、CentOS7、Fedora、Arch Linux、openSUSE Leap 42.1，其他版本可能有细微不同。更多详情请访问文档。
   
    
3.配置完成后从Docker Hub Mirror下载镜像，命令：
    #dao pull ubuntu

注1：第一次使用daocloud是配置了加速器的，可以直接使用dao pull centos拉取经过加速之后的镜像，但是后来发现，不使用加速器也可以直接在daocloud官网上找到想要拉取的镜像地址进行拉取，﻿比如：#docker pull 
daocloud.io/library/tomcat:6.0-jre7
注2：上面配置加速器的方法，官网会更新，最新方法你应该根据官网提示去操作。
===========以下为tigerfive亲测================
使用国内镜像：
进入网站：https://hub.daocloud.io/
注册帐号：tigerfive
进入镜像市场：填写搜索的镜像名称


选择第一个

点击右边快速部署：


写入名称，选择我的主机，按提示继续在主机上进行所有操作

# mkdir /docker
# cd /docker
# curl -L -o /tmp/daomonit.x86_64.rpm https://get.daocloud.io/daomonit/daomonit.x86_64.rpm
# rpm -Uvh /tmp/daomonit.x86_64.rpm
# daomonit -token=36e3dedaa2e6b352f47b26a3fa9b67ffd54f5077 save-config
# service daomonit start

出现如下界面：说明自有主机接入完成（注意：这里我用的主机是我自己笔记本上的一台虚拟机）


接下来我们在镜像市场找到一个centos的镜像:点击右面的拉取按钮,会出现拉取命令如下：
我们按命令执行：
    # docker pull daocloud.io/library/centos:7
    出现如下提示：说明拉取成功
    Trying to pull repository daocloud.io/library/centos ... 
    latest: Pulling from daocloud.io/library/centos

    08d48e6f1cff: Pull complete 
    Digest: sha256:934ff980b04db1b7484595bac0c8e6f838e1917ad3a38f904ece64f70bbca040
    Status: Downloaded newer image for daocloud.io/library/centos:latest

查看一下本地镜像：      
    [root@docker1 docker]# docker images
    REPOSITORY                   TAG                 IMAGE ID            CREATED             SIZE
    daocloud.io/library/centos   latest              0584b3d2cf6d        3 weeks ago         196.5 MB

在拉取回来的本地镜像执行命令：
    万年不变的"你好世界"：    
    # docker run daocloud.io/library/centos:7 /bin/echo "hello world"
        hello world
    
    使用容器中的shell：
   [root@docker1 docker]# docker run -i -t centos:7 /bin/bash  
    Unable to find image 'centos:latest' locally
    Trying to pull repository docker.io/library/centos ...   
    注意上面这样是不行的，因为默认使用的是docker官方默认镜像库的位置，需要按如下命令执行：
    [root@docker1 docker]# docker run -i -t daocloud.io/library/centos:7 /bin/bash
    -i   捕获标准输入输出
    -t   分配一个终端或控制台
    进去之后可以在里面执行其他命令
    [root@336412c1b562 /]# ls
    anaconda-post.log  bin  dev  etc  home  lib  lib64  lost+found  media  mnt  opt  proc  root  run  sbin  srv  sys  tmp  usr  var
    [root@336412c1b562 /]# df -h   #可以看到这里的磁盘分区是镜像本身的磁盘分区
    Filesystem                                                                                           Size  Used Avail Use% Mounted on
    /dev/mapper/docker-253:0-134984824-bc712573ec743c160ea903f6196ff4814056230d6a232eb3d39761d182bc7d1c   10G  240M  9.8G   3% /
    tmpfs                                                                                                497M     0  497M   0% /dev
    tmpfs                                                                                                497M     0  497M   0% /sys/fs/cgroup
    /dev/mapper/centos-root                                                                               38G  2.3G   36G   7% /etc/hosts
    shm                                                                                                   64M     0   64M   0% /dev/shm
    [root@336412c1b562 /]# exit
    exit
    [root@docker1 docker]# df -h   #这是我本地主机系统的磁盘分区
    文件系统                 容量  已用  可用 已用% 挂载点
    /dev/mapper/centos-root   38G  2.3G   36G    7% /
    devtmpfs                 487M     0  487M    0% /dev
    tmpfs                    497M     0  497M    0% /dev/shm
    tmpfs                    497M   20M  478M    4% /run
    tmpfs                    497M     0  497M    0% /sys/fs/cgroup
    /dev/vda1                497M  107M  391M   22% /boot
    tmpfs                    100M     0  100M    0% /run/user/0
    /dev/sr0                 7.3G  7.3G     0  100% /mnt/centos7u2

重新进入容器：执行其他命令试一下，可以看到我们的容器可以做我们熟悉的所有的事情：
1.可以上网
    [root@9990e6c99bbd /]# ping www.baidu.com -c 2
    PING www.a.shifen.com (180.97.33.107) 56(84) bytes of data.
    64 bytes from 180.97.33.107: icmp_seq=1 ttl=52 time=19.8 ms
    64 bytes from 180.97.33.107: icmp_seq=2 ttl=52 time=19.1 ms
2.网络yum源已经配置好
    [root@9990e6c99bbd /]# yum repolist
    Loaded plugins: fastestmirror, ovl
    base                                                                                                                           | 3.6 kB  00:00:00     
    extras                                                                                                                         | 3.4 kB  00:00:00     
    updates                                                                                                                        | 3.4 kB  00:00:00     
    (1/4): base/7/x86_64/group_gz                                                                                                  | 155 kB  00:00:01     
    (2/4): extras/7/x86_64/primary_db                                                                                              | 166 kB  00:00:04     
    (3/4): updates/7/x86_64/primary_db                                                                                             | 9.1 MB  00:00:07     
    (4/4): base/7/x86_64/primary_db                                                                                                | 5.3 MB  00:00:22     
    Determining fastest mirrors
     * base: mirrors.tuna.tsinghua.edu.cn
     * extras: mirrors.tuna.tsinghua.edu.cn
     * updates: mirrors.163.com
    repo id                                                                repo name                                                                status
    base/7/x86_64                                                          CentOS-7 - Base                                                          9007
    extras/7/x86_64                                                        CentOS-7 - Extras                                                         393
    updates/7/x86_64                                                       CentOS-7 - Updates                                                       2560
    repolist: 11960

3.可以安装软件：
    [root@9990e6c99bbd /]# lsof -i:80
    bash: lsof: command not found
    [root@9990e6c99bbd /]# yum install lsof httpd -y
    Loaded plugins: fastestmirror, ovl
    Loading mirror speeds from cached hostfile
     * base: mirrors.tuna.tsinghua.edu.cn
     * extras: mirrors.tuna.tsinghua.edu.cn
     * updates: mirrors.163.com
    Resolving Dependencies
    --> Running transaction  check
    ---> Package lsof.x86_64 0:4.87-4.el7 will be installed
    --> Finished Dependency Resolution

    Dependencies Resolved

    ======================================================================================================================================================
     Package                          Arch                               Version                                   Repository                        Size
    ======================================================================================================================================================
    Installing:
     lsof                             x86_64                             4.87-4.el7                                base                             331 k
```

## 国内源介绍及使用

```
Docker 加速器  
使用 Docker 的时候，需要经常从官方获取镜像，但是由于显而易见的网络原因，拉取镜像的过程非常耗时，严重影响使用 Docker 的体验。因此 DaoCloud 推出了加速器工具解决这个难题，通过智能路由和缓存机制，极大提升了国内网络访问 Docker Hub 的速度，目前已经拥有了广泛的用户群体，并得到了 Docker 官方的大力推荐。
如果您是在国内的网络环境使用 Docker，那么 Docker 加速器一定能帮助到您。    

Docker 加速器对 Docker 的版本有要求吗？    
需要 Docker 1.8 或更高版本才能使用，如果您没有安装 Docker 或者版本较旧，请安装或升级。    

Docker 加速器支持什么系统？    
Linux, MacOS 以及 Windows 平台。    

Docker 加速器是否收费？    
DaoCloud 为了降低国内用户使用 Docker 的门槛，提供永久免费的加速器服务，请放心使用。  

国内比较好的镜像源：网易蜂巢、aliyun和daocloud,下面是daocloud配置方式：
Docker Hub并没有在国内部署服务器或者使用国内的CDN服务，因此在国内特殊的网络环境下，镜像下载十分耗时。
为了克服跨洋网络延迟，能够快速高效地下载Docker镜像，可以采用DaoCloud提供的服务Docker Hub Mirror，速度
快很多
1.注册网站账号
2.然后进入你自己的"控制台"，选择"加速器"，点"立即开始"，接入你自有的主机，就看到如下的内容了
    • 下载并安装相关软件
     #curl -L -o /tmp/daomonit_amd64.deb https://get.daocloud.io/daomonit/daomonit_amd64.debsudo 
     #dpkg -4i /tmp/daomonit_amd64.deb
    • 配置
     #sudo daomonit -token=e16ed16b2972865e19b143695cf08cad850d5570 save-config
    • 启动服务
     #service daomonit start
    
3.配置完成后从Docker Hub Mirror下载镜像，命令：
    #dao pull ubuntu
```

