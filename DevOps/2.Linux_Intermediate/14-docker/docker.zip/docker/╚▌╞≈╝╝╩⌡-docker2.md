## 镜像管理

```
搜索镜像：
    这种方法只能用于官方镜像库
    搜索基于 centos 操作系统的镜像
    # docker search centos

    按星级搜索镜像：        
    查找 star 数至少为 100 的镜像，默认不加 s 选项找出所有相关 ubuntu 镜像：         
    # docker search ubuntu -f stars=100    
      
拉取镜像：
    # docker pull centos

查看本地镜像：  
    # docker image list
    
查看镜像详情：
    # docker image inspect 镜像id
    
删除镜像：
    删除一个或多个，多个之间用空格隔开，可以使用镜像名称或id
    # docker rmi daocloud.io/library/mysql

    强制删除：--force
    如果镜像正在被使用中可以使用--force强制删除    18.07后不支持强制删除
    # docker rmi docker.io/ubuntu:latest --force

    删除所有镜像：
    # docker rmi $(docker images -q)

只查看所有镜像的id:
    # docker images -q 
  
查看镜像制作的过程：
    相当于dockfile
    # docker history daocloud.io/ubuntu
    
    dive docker_image_id/docker_image_name
```

## 容器管理

```
创建新容器但不启动：
# docker create -it daocloud.io/library/centos:5 /bin/bash

创建并运行一个新Docker 容器：
    同一个镜像可以启动多个容器,每次执行run子命令都会运行一个全新的容器
    # docker run -it --restart=always centos:7 /bin/bash
    如果执行成功，说明CentOS 容器已经被启动，并且应该已经得到了 bash 提示符。
    -i   
        捕获标准输入输出
    -t   
        分配一个终端或控制台
    --restart=always   
        容器随docker engine自启动，因为在重启docker的时候默认容器都会被关闭   
        也适用于create选项
         
    --rm
        默认情况下，每个容器在退出时，它的文件系统也会保存下来，这样一方面调试会方便些，因为你可以通过查看日志等方式来确定最终状态。另一方面，也可以保存容器所产生的数据。
        但是当你仅仅需要短暂的运行一个容器，并且这些数据不需要保存，你可能就希望Docker能在容器结束时自动清理其所产生的数据。这个时候就需要--rm参数了。注意：--rm 和 -d不能共用

若要断开与容器的连接，并且关闭容器：
   容器内部执行如下命令
    [root@d33c4e8c51f8 /]#exit

如果只想断开和容器的连接而不关闭容器：
    快捷键：ctrl+p+q

查看容器：
    只查看运行状态的容器：
    #docker ps

    #docker ps -a
    -a  查看所有容器
    
    只查看所有容器id:
    # docker ps -a -q
 
    列出最近一次启动的容器
    # docker ps -l   

查看容器详细信息：
inspect   Return low-level information on a container or image
用于查看容器的配置信息，包含容器名、环境变量、运行命令、主机配置、网络配置和数据卷配置等。

目标：
查找某一个运行中容器的id，然后使用docker inspect命令查看容器的信息。

提示：
可以使用镜像id的前面部分，不需要完整的id。
[root@master ~]# docker inspect d95    //d95是我机器上运行的一个容器ID的前3个字符
[
    {
        "Id": "d95a220a498e352cbfbc098c949fc528dbf5a5c911710b108ea3a9b4aa3a4761",
        "Created": "2017-07-08T03:59:16.18225183Z",
        "Path": "bash",
        "Args": [],
        "State": {
            "Status": "exited",
            "Running": false,
            "Paused": false,
            "Restarting": false,
            "OOMKilled": false,
            "Dead": false,
            "Pid": 0,
容器信息很多，这里只粘贴了一部分

比如：容器里在安装ip或ifconfig命令之前，查看网卡IP显示容器IP地址和端口号，如果输出是空的说明没有配置IP地址（不同的Docker容器可以通过此IP地址互相访问）
# docker inspect --format='{{.NetworkSettings.IPAddress}}'  容器id
列出所有绑定的端口:
# docker inspect --format='{{range $p, $conf := .NetworkSettings.Ports}} {{$p}} -> 
{{(index $conf 0).HostPort}} {{end}}' $INSTANCE_ID

# docker inspect --format='{{range $p, 
$conf := .NetworkSettings.Ports}} {{$p}} -> {{(index $conf 0).HostPort}} {{end}}' 
b220fabf815a
22/tcp -> 20020

找出特殊的端口映射:
比如找出容器里22端口所映射的docker本机的端口：
# docker inspect --format='{{(index (index .NetworkSettings.Ports "22/tcp") 
0).HostPort}}' $INSTANCE_ID
[root@localhost ~]# docker inspect --format='{{(index (index .NetworkSettings.Ports "22/
tcp") 0).HostPort}}' b220fabf815a
20020

http://note.youdao.com/noteshare?id=4ee7884b3d25c16850d78cfdec276add

启动容器：
# docker start  name

关闭容器：
# docker stop  name
# docker kill    name      --强制终止容器

杀死所有running状态的容器
# docker kill $(docker ps  -q)  

stop和kill的区别：
    docker stop命令给容器中的进程发送SIGTERM信号，默认行为是会导致容器退出，当然，容器内程序可以捕获该信号并自行处理，例如可以选择忽略。而docker kill则是给容器的进程发送SIGKILL信号，该信号将会使容器必然退出。 

删除容器：
    # docker rm 容器id或名称
    要删除一个运行中的容器，添加 -f 参数
    
    根据格式删除所有容器：
    # docker rm $(docker ps -qf status=exited)
        
重启容器：
#docker restart name

暂停容器：
pause   --暂停容器内的所有进程，
    通过docker stats可以观察到此时的资源使用情况是固定不变的，通过docker logs -f也观察不到日志的进一步输出。

恢复容器：
unpause  --恢复容器内暂停的进程，与pause参数相对应

# docker start infallible_ramanujan  //这里的名字是状态里面NAMES列列出的名字，这种方式同样会让容器运行在后台

让容器运行在后台：
﻿如果在docker run后面追加-d=true或者-d，那么容器将会运行在后台模式。此时所有I/O数据只能通过网络资源或者共享卷组来进行交互。因为容器不再监听你执行docker run的这个终端命令行窗口。但你可以通过执行
docker attach来重新附着到该容器的回话中。注意，容器运行在后台模式下，是不能使用--rm选项的

#docker run -d IMAGE[:TAG] 命令
#docker logs container_id   #打印该容器的输出

# docker run -it -d --name mytest docker.io/centos:7 /bin/sh -c "while true; do echo hello world; sleep 2; done"
37738fe3d6f9ef26152cb25018df9528a89e7a07355493020e72f147a291cd17

[root@localhost ~]# docker logs mytest
hello world
hello world

docker attach container_id #附加该容器的标准输出到当前命令行
[root@localhost ~]# docker attach mytest
hello world
hello world
.......
此时，ctrl+d等同于exit命令，按ctrl+p+q可以退出到宿主机，而保持container仍然在运行

rename 
    Rename a container
    
stats     
    Display a live stream of container(s) resource usage statistics    
    --动态显示容器的资源消耗情况，包括：CPU、内存、网络I/O   
    
port    
    List port mappings or a specific mapping for the CONTAINER
     --输出容器端口与宿主机端口的映射情况
    # docker port blog
        80/tcp -> 0.0.0.0:80
     容器blog的内部端口80映射到宿主机的80端口，这样可通过宿主机的80端口查看容器blog提供的服务
 
连接容器：    
方法1.attach
# docker attach 容器id   //前提是容器创建时必须指定了交互shell

方法2.exec      
    通过exec命令可以创建两种任务：后台型任务和交互型任务
    交互型任务：
        # docker exec -it  容器id  /bin/bash
        root@68656158eb8e:/# ls     
    
    后台型任务：
        # docker exec 容器id touch /testfile

监控容器的运行：
可以使用logs、top、events、wait这些子命令
    logs:
        使用logs命令查看守护式容器
        可以通过使用docker logs命令来查看容器的运行日志，其中--tail选项可以指定查看最后几条日志，而-t选项则可以对日志条目附加时间戳。使用-f选项可以跟踪日志的输出，直到手动停止。
        # docker logs    App_Container   //不同终端操作
        # docker logs -f App_Container

    top:
        显示一个运行的容器里面的进程信息
        # docker top birdben/ubuntu:v1

    events    
        Get real time events from the server
        实时输出Docker服务器端的事件，包括容器的创建，启动，关闭等。

        # docker start loving_meninsky
        loving_meninsky

        # docker events  //不同终端操作
        2017-07-08T16:39:23.177664994+08:00 network connect  
        df15746d60ffaad2d15db0854a696d6e49fdfcedc7cfd8504a8aac51a43de6d4 
        (container=50a0449d7729f94046baf0fe5a1ce2119742261bb3ce8c3c98f35c80458e3e7a, 
        name=bridge, type=bridge)
        2017-07-08T16:39:23.356162529+08:00 container start 
        50a0449d7729f94046baf0fe5a1ce2119742261bb3ce8c3c98f35c80458e3e7a (image=ubuntu, 
        name=loving_meninsky)

    wait      
        Block until a container stops, then print its exit code   
        --捕捉容器停止时的退出码
        执行此命令后，该命令会"hang"在当前终端，直到容器停止，此时，会打印出容器的退出码
        # docker wait 01d8aa  //不同终端操作
           137

    diff
        查看容器内发生改变的文件，以elated_lovelace容器为例
        root@68656158eb8e:/# touch c.txt

        用diff查看：
        包括文件的创建、删除和文件内容的改变都能看到 
        [root@master ~]# docker diff  容器名称
        A /c.txt

        C对应的文件内容的改变，A对应的均是文件或者目录的创建删除
        [root@docker ~]# docker diff 7287
        A /a.txt
        C /etc
        C /etc/passwd
        A /run
        A /run/secrets  
        
宿主机和容器之间相互COPY文件
    cp的用法如下：
    Usage:    docker cp [OPTIONS] CONTAINER:PATH LOCALPATH
                   docker cp [OPTIONS] LOCALPATH CONTAINER:PATH

    如：容器mysql中/usr/local/bin/存在docker-entrypoint.sh文件，可如下方式copy到宿主机
    #  docker cp mysql:/usr/local/bin/docker-entrypoint.sh   /root

    修改完毕后，将该文件重新copy回容器
    # docker cp /root/docker-entrypoint.sh mysql:/usr/local/bin/      
```

## 容器打包

```
将容器的文件系统打包成tar文件,也就是把正在运行的容器直接导出为tar包的镜像文件

export    
    Export a container's filesystem as a tar archive

有两种方式（elated_lovelace为容器名）：
第一种：
    [root@master ~]# docker export -o elated_lovelace.tar elated_lovelace

第二种：
    [root@master ~]# docker export 容器名称 > 镜像.tar

导入镜像归档文件到其他宿主机：
import    
    Import the contents from a tarball to create a filesystem image
    # docker import elated_lovelace.tar  elated_lovelace:v1    
```

## 镜像迁移

```
保存一台宿主机上的镜像为tar文件，然后可以导入到其他的宿主机上：
save      
    Save an image(s) to a tar archive
    将镜像打包，与下面的load命令相对应
    #docker save -o nginx.tar nginx:tag

load      
    Load an image from a tar archive or STDIN
    与上面的save命令相对应，将上面sava命令打包的镜像通过load命令导入
    #docker load < nginx.tar
    
容器的迁移  
docker export b25f3cb2bf1f  | gzip > mynginx123.tar
zcat mynginx123.tar | docker import  - mynginx123
```

## 镜像、容器深度操作

```shell
# 显示镜像摘要
docker images --digests 

# 过滤镜像
docker images [-f|--filter] "key=value"
支持:
dangling：显示标记为空的镜像，值只有true和false
label：这个是根据标签进行过滤，其中lable的值，是docker在编译的时候配置的或者在Dockerfile中配置的
before：这个是根据时间来进行过滤，其中before的value表示某个镜像构建时间之前的镜像列表
since：跟before正好相反，表示的是在某个镜像构建之后构建的镜像
reference：添加正则进行匹配

# 镜像格式化输出
docker images --format "{{.ID}}\t{{.Repository}}"

.ID	镜像ID
.Repository	镜像仓库
.Tag 镜像标签[版本]
.Digest	镜像hash值
.CreatedSince 创建镜像后的时间
.CreatedAt	创建镜像的时间
.Size 镜像大小

# 容器格式化输出
docker ps --format "{{.ID}}\t{{.Command}}"
.ID	容器ID
.Image	镜像ID
.Command	执行的命令
.CreatedAt	容器创建时间
.RunningFor	运行时长
.Ports	暴露的端口
.Status	容器状态
.Names	容器名称
.Label	分配给容器的所有标签
.Mounts	容器挂载的卷
.Networks	容器所用的网络名称
```



### 脚本示例

```shell
#!/bin/bash

save(){
    if [ ! -d "./images" ]; then
        mkdir images
    fi
    cd images
    docker images --format "{{.ID}} {{.Repository}}:{{.Tag}} {{.Size}}" > images_pull.txt
    while read line
    do
        image_id=`echo $line | awk '{print $1}'`
        image_repository=`echo $line | awk '{print $2}'`
        image_size=`echo $line | awk '{print $3}'`
        docker save -o $image_id.tar $image_id && \
        echo "Image $image_repository saved, size $image_size"
    done < images_pull.txt
}

load(){
    cd images
    while read line
    do
        image_id=`echo $line | awk '{print $1}'`
        image_repository=`echo $line | awk '{print $2}'`
        docker load -i $image_id.tar && \
        echo "Image $image_repository loaded"
    done < images_pull.txt
}
if [ -z "$1" ]; then
    echo "Usage: image_operation.sh [save|load]"
fi

eval $1

```

