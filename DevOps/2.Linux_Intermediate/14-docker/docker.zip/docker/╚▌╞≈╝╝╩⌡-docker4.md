#  **docker资源限制**

在使用 docker 运行容器时，一台主机上可能会运行几百个容器，这些容器虽然互相隔离，但是底层却使用着相同的 CPU、内存和磁盘资源。如果不对容器使用的资源进行限制，那么容器之间会互相影响，小的来说会导致容器资源使用不公平；大的来说，可能会导致主机和集群资源耗尽，服务完全不可用。

 

CPU 和内存的资源限制已经是比较成熟和易用，能够满足大部分用户的需求。磁盘限制也是不错的，虽然现在无法动态地限制容量，但是限制磁盘读写速度也能应对很多场景。

 

至于网络，docker 现在并没有给出网络限制的方案，也不会在可见的未来做这件事情，因为目前网络是通过插件来实现的，和容器本身的功能相对独立，不是很容易实现，扩展性也很差。

 

资源限制一方面可以让我们为容器（应用）设置合理的 CPU、内存等资源，方便管理；另外一方面也能有效地预防恶意的攻击和异常，对容器来说是非常重要的功能。

## **系统压力测试工具stress**

​    stress是一个linux下的压力测试工具，专门为那些想要测试自己的系统，完全高负荷和监督这些设备运行的用户。

## **cpu资源限制**

### **限制CPU Share**

什么是cpu share:

```shell
docker 允许用户为每个容器设置一个数字，代表容器的 CPU share，默认情况下每个容器的 share 是 1024。这个 share 是相对的，本身并不能代表任何确定的意义。当主机上有多个容器运行时，每个容器占用的 CPU 时间比例为它的 share 在总额中的比例。docker 会根据主机上运行的容器和进程动态调整每个容器使用 CPU 的时间比例。
```

例子：

```shell
  如果主机上有两个一直使用 CPU 的容器（为了简化理解，不考虑主机上其他进程），其 CPU share 都是 1024，那么两个容器 CPU 使用率都是 50%；如果把其中一个容器的 share 设置为 512，那么两者 CPU 的使用率分别为 67% 和 33%；如果删除 share 为 1024 的容器，剩下来容器的 CPU 使用率将会是 100%。
```

  好处：

```shell
 能保证 CPU 尽可能处于运行状态，充分利用 CPU 资源，而且保证所有容器的相对公平；
```

   缺点：

```shell
 无法指定容器使用 CPU 的确定值。 
```

设置 CPU share 的参数：

```shell
 -c --cpu-shares，它的值是一个整数
```

我的机器是 4 核 CPU，因此运行一个stress容器,使用 stress 启动 4 个进程来产生计算压力：（无CPU限制）

```shell
[root@yixuan ~]# docker pull progrium/stress
[root@yixuan ~]# yum install -y htop
[root@yixuan ~]# docker run --rm -it progrium/stress --cpu 4
stress: info: [1] dispatching hogs: 4 cpu, 0 io, 0 vm, 0 hdd
stress: dbug: [1] using backoff sleep of 12000us
stress: dbug: [1] --> hogcpu worker 4 [6] forked
stress: dbug: [1] using backoff sleep of 9000us
stress: dbug: [1] --> hogcpu worker 3 [7] forked
stress: dbug: [1] using backoff sleep of 6000us
stress: dbug: [1] --> hogcpu worker 2 [8] forked
stress: dbug: [1] using backoff sleep of 3000us
stress: dbug: [1] --> hogcpu worker 1 [9] forked
```

在另外一个 terminal 使用 htop 查看资源的使用情况：

![1570424556113](https://newrain.gd2.qingstor.com/step1/4b8655810a404017900bd1307fd498b3765a4042.jpg) 

上图中看到，CPU 四个核资源都达到了 100%。

 为了比较，另外启动一个 share 为 512 的容器：

 ```shell
1.先将没有做限制的命令运行起来
[root@yixuan ~]# docker run --rm -it progrium/stress --cpu 4
2.在开启一个终端，运行做了CPU限制的命令
[root@yixuan ~]# docker run --rm -it -c 512 progrium/stress --cpu 4
stress: info: [1] dispatching hogs: 4 cpu, 0 io, 0 vm, 0 hdd
stress: dbug: [1] using backoff sleep of 12000us
stress: dbug: [1] --> hogcpu worker 4 [6] forked
stress: dbug: [1] using backoff sleep of 9000us
stress: dbug: [1] --> hogcpu worker 3 [7] forked
stress: dbug: [1] using backoff sleep of 6000us
stress: dbug: [1] --> hogcpu worker 2 [8] forked
stress: dbug: [1] using backoff sleep of 3000us
stress: dbug: [1] --> hogcpu worker 1 [9] forked
3.在开启一个终端执行htop命令
[root@yixuan ~]# htop
 ```

因为默认情况下，容器的 CPU share 为 1024，所以这两个容器的 CPU 使用率应该大致为 2：1，下面是启动第二个容器之后的监控截图：

![1570425017249](https://newrain.gd2.qingstor.com/step1/4e3a2f6fb579952361697e842fbc888d65e7c387.jpg) 

两个容器分别启动了四个 stress 进程，第一个容器 stress 进程 CPU 使用率都在 60% 左右，第二个容器 stress 进程 CPU 使用率在 30% 左右，比例关系大致为 2：1，符合之前的预期。 

### **限制CPU 核数**

限制容器能使用的 CPU 核数

```shell
-c --cpu-shares 参数只能限制容器使用 CPU 的比例，或者说优先级，无法确定地限制容器使用 CPU 的具体核数；从 1.13 版本之后，docker 提供了 --cpus 参数可以限定容器能使用的 CPU 核数。这个功能可以让我们更精确地设置容器 CPU 使用量，是一种更容易理解也因此更常用的手段.
```

```shell
--cpus 后面跟着一个浮点数，代表容器最多使用的核数，可以精确到小数点二位，也就是说容器最小可以使用 0.01 核 CPU。
```

限制容器只能使用 1.5 核数 CPU：

```shell
[root@yixuan ~]# docker run --rm -it --cpus 1.5 progrium/stress --cpu 3
stress: info: [1] dispatching hogs: 3 cpu, 0 io, 0 vm, 0 hdd
stress: dbug: [1] using backoff sleep of 9000us
stress: dbug: [1] --> hogcpu worker 3 [6] forked
stress: dbug: [1] using backoff sleep of 6000us
stress: dbug: [1] --> hogcpu worker 2 [7] forked
stress: dbug: [1] using backoff sleep of 3000us
stress: dbug: [1] --> hogcpu worker 1 [8] forked
```

在容器里启动三个 stress 来跑 CPU 压力，如果不加限制，这个容器会导致 CPU 的使用率为 300% 左右（也就是说会占用三个核的计算能力）。实际的监控如下图：

![img](https://newrain.gd2.qingstor.com/step1/0288a0f5cf116312904b33fdeb1a9d0b47784e5c.jpg) 

可以看到，每个 stress 进程 CPU 使用率大约在 50%，总共的使用率为 150%，符合 1.5 核的设置。 

如果设置的 --cpus 值大于主机的 CPU 核数，docker 会直接报错：

```shell
[root@yixuan ~]# docker run --rm -it --cpus 8 progrium/stress --cpu 3  #启用三个进程做测试
docker: Error response from daemon: Range of CPUs is from 0.01 to 4.00, as there are only 4 CPUs available.
See 'docker run --help'.
```

如果多个容器都设置了 --cpus ，并且它们之和超过主机的 CPU 核数，并不会导致容器失败或者退出，这些容器之间会竞争使用 CPU，具体分配的 CPU 数量取决于主机运行情况和容器的 CPU share 值。也就是说 --cpus 只能保证在 CPU 资源充足的情况下容器最多能使用的 CPU 数，docker 并不能保证在任何情况下容器都能使用这么多的 CPU（因为这根本是不可能的）。    

### **CPU 绑定**

限制容器运行在某些 CPU 核

**注**：

一般并不推荐在生产中这样使用

docker 允许调度的时候限定容器运行在哪个 CPU 上。

案例：

假如主机上有 4 个核，可以通过 --cpuset 参数让容器只运行在前两个核上：

```shell
[root@yixuan ~]# docker run --rm -it --cpuset-cpus=0,1 progrium/stress --cpu 2 
stress: info: [1] dispatching hogs: 2 cpu, 0 io, 0 vm, 0 hdd
stress: dbug: [1] using backoff sleep of 6000us
stress: dbug: [1] --> hogcpu worker 2 [6] forked
stress: dbug: [1] using backoff sleep of 3000us
stress: dbug: [1] --> hogcpu worker 1 [7] forked 
```

这样，监控中可以看到只有前面两个核 CPU 达到了 100% 使用率。

![img](https://newrain.gd2.qingstor.com/step1/a9871b1e58502ef1380b1259e780748975208c19.jpg) 

## **mem资源限制**

docker 默认没有对容器内存进行限制，容器可以使用主机提供的所有内存。 

不限制内存带来的问题：

```shell
这是非常危险的事情，如果某个容器运行了恶意的内存消耗软件，或者代码有内存泄露，很可能会导致主机内存耗尽，因此导致服务不可用。可以为每个容器设置内存使用的上限，一旦超过这个上限，容器会被杀死，而不是耗尽主机的内存。 
```

限制内存带来的问题：

```shell
限制内存上限虽然能保护主机，但是也可能会伤害到容器里的服务。如果为服务设置的内存上限太小，会导致服务还在正常工作的时候就被 OOM 杀死；如果设置的过大，会因为调度器算法浪费内存。
```

合理做法：

````shell
1. 为应用做内存压力测试，理解正常业务需求下使用的内存情况，然后才能进入生产环境使用
2. 一定要限制容器的内存使用上限，尽量保证主机的资源充足，一旦通过监控发现资源不足，就进行扩容或者对容器进行迁移如果可以（内存资源充足的情况）
3. 尽量不要使用 swap，swap 的使用会导致内存计算复杂，对调度器非常不友好
````

**docker 限制容器内存使用量:**

```shell
docker 启动参数中，和内存限制有关的包括（参数的值一般是内存大小，也就是一个正数，后面跟着内存单位 b、k、m、g，分别对应 bytes、KB、MB、和 GB):

-m --memory：容器能使用的最大内存大小，最小值为 4m
```

如果限制容器的内存使用为 64M，在申请 64M 资源的情况下，容器运行正常（如果主机上内存非常紧张，并不一定能保证这一点）：

 ```shell
[root@yixuan ~]# docker run --rm -it -m 64m progrium/stress --vm 1 --vm-bytes 64M --vm-hang 0
stress: info: [1] dispatching hogs: 0 cpu, 0 io, 1 vm, 0 hdd
stress: dbug: [1] using backoff sleep of 3000us
stress: dbug: [1] --> hogvm worker 1 [6] forked
stress: dbug: [6] allocating 67108864 bytes ...
stress: dbug: [6] touching bytes in strides of 4096 bytes ...
stress: dbug: [6] sleeping forever with allocated memory

容器可以正常运行。
-m 64m：限制你这个容器只能使用64M
--vm-bytes 64M：将内存撑到64兆是不会报错，因为我有64兆内存可用。
hang:就是卡在这里。
--vm：生成几个占用内存的进程
 ```

而如果申请 150M 内存，会发现容器里的进程被 kill 掉了（worker 6 got signal 9，signal 9 就是 kill 信号）

 ```shell
[root@yixuan ~]# docker run --rm -it -m 64m progrium/stress --vm 1 --vm-bytes 150M --vm-hang 0
stress: info: [1] dispatching hogs: 0 cpu, 0 io, 1 vm, 0 hdd
stress: dbug: [1] using backoff sleep of 3000us
stress: dbug: [1] --> hogvm worker 1 [6] forked
stress: dbug: [6] allocating 157286400 bytes ...
stress: dbug: [6] touching bytes in strides of 4096 bytes ...
stress: FAIL: [1] (416) <-- worker 6 got signal 9
stress: WARN: [1] (418) now reaping child worker processes
stress: FAIL: [1] (422) kill error: No such process
stress: FAIL: [1] (452) failed run completed in 1s
 ```

## 限制IO

> 限制bps和iops
> bps是 byte per second ，每秒读写的数量
>
> iops是 io per second ，每秒IO的次数
>
> 注:目前Block I0限额只对direct IO (不使用文件缓存)有效。



```
可以同过下面的参数控制容器的bps和iops；

--device-read-bps:限制读某个设备的bps.
--devce-write-bps:限制写某个设备的bps.
--device-read-iops:限制读某个设备的iops.
--device-write-iops: 限制写某个设备的iops.

限制情况下：
[root@newrain ~]# docker run -it --device-write-bps /dev/sda:30MB ubuntu
root@10845a98036e:/# time dd if=/dev/zero of=test.out bs=1M count=800 oflag=direct
结果如下图1

不限制情况下：
[root@newrain ~]# docker run -it  ubuntu
root@10845a98036e:/# time dd if=/dev/zero of=test.out bs=1M count=800 oflag=direct
结果如下图2
```

图1

![343322cbb71a2f75bf94833be8ab0bc.jpg](https://py-put.gd2.qingstor.com/ff63616ace24c994047ff07ce5cf8aa35630b89f.jpg)

图2

![9ccce7aec3bea24dca0f399819c52ca.jpg](https://py-put.gd2.qingstor.com/078cce03fcec63c9ff8db7589ebef45814aeb05a.jpg)





# **端口转发**

 ![1570429105816](https://newrain.gd2.qingstor.com/step1/4dc03662c6f95853a35c1d352681ee619ebb0b84.jpg)

使用端口转发解决容器端口访问问题

```shell
-p:创建应用容器的时候，一般会做端口映射，这样是为了让外部能够访问这些容器里的应用。可以用多个-p指定多个端口映射关系。
```

mysql应用端口转发：

查看本地地址：

````shell
[root@yixuan ~]# ip a 
...
2: ens33: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc pfifo_fast state UP qlen 1000
    link/ether 00:0c:29:9c:bf:66 brd ff:ff:ff:ff:ff:ff
    inet 192.168.246.141/24 brd 192.168.246.255 scope global dynamic ens33
       valid_lft 5217593sec preferred_lft 5217593sec
    inet6 fe80::a541:d470:4d9a:bc29/64 scope link 
       valid_lft forever preferred_lft forever
````

运行容器：使用-p作端口转发，**把本地3307转发到容器的3306**，其他参数需要查看发布容器的页面提示

````shell
[root@yixuan ~]# docker pull daocloud.io/library/mysql:5.7
[root@yixuan ~]# docker run -d --name mysql1 -p 3307:3306  -e MYSQL_ROOT_PASSWORD=Qf@123! daocloud.io/library/mysql:5.7
a4327dbddf665b4302c549320bff869b8a027c2e1eead363d84ce5d06acf2698

-e MYSQL_ROOT_PASSWORD= 设置环境变量，这里是设置mysql的root用户的密码
````

通过本地IP：192.168.246.141的3307端口访问容器mysql1内的数据库，出现如下提示恭喜你

```shell
1.安装一个mysql客户端
[root@yixuan ~]# yum install -y mysql
2.登录
[root@yixuan ~]# mysql -uroot -p'Qf@123!' -h 192.168.246.141 -P3307
Welcome to the MariaDB monitor.  Commands end with ; or \g.
Your MySQL connection id is 3
Server version: 5.7.26 MySQL Community Server (GPL)

Copyright (c) 2000, 2018, Oracle, MariaDB Corporation Ab and others.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

MySQL [(none)]>
```

```shell
-P（大P）:当使用-P标记时，Docker 会随机映射一个 32768~49900 的端口到内部容器开放的网络端口。如下：
[root@yixuan ~]# docker pull daocloud.io/library/redis
[root@yixuan ~]# docker images
REPOSITORY                   TAG        IMAGE ID            CREATED           SIZE
daocloud.io/library/redis    latest     598a6f110d01        2months ago       118MB
[root@yixuan ~]# docker run --name myredis -P -d daocloud.io/library/redis
ca06a026d84a0605d9a9ce6975389a79f4ab9a9a043a03f088cd909c1fe52e29
[root@yixuan ~]# docker ps 
CONTAINER ID        IMAGE                           COMMAND                  CREATED             STATUS              PORTS                               NAMES
ca06a026d84a        daocloud.io/library/redis       "docker-entrypoint.s…"   22 seconds ago      Up 21 seconds       0.0.0.0:32768->6379/tcp             myredis
```

从上面的结果中可以看出，本地主机的32768端口被映射到了redis容器的6379端口上，也就是说访问本机的32768端口即可访问容器内redis端口。

在别的机器上通过上面映射的端口32768连接这个容器的redis

```shell
[root@docker-server2 ~]# yum install -y redis
[root@docker-server2 ~]# redis-cli -h 192.168.246.141 -p 32768
192.168.246.141:32768> ping
PONG
192.168.246.141:32768>
```

# **容器卷**

```shell
把本地宿主机上面的某一个目录挂载到容器里面的目录去。这两个目录都不用提前存在，会自动创建
```

新卷只能在容器创建过程当中挂载

```shell
[root@yixuan ~]# docker run -it --name testnginx -v /test:/test2 daocloud.io/library/nginx /bin/bash
root@86320e734cd1:/# ls
root@86320e734cd1:/# ctrl+p+q  #退出

测试：
[root@yixuan ~]# cd /test/
[root@yixuan test]# ls
[root@yixuan test]# touch a.txt 
[root@yixuan test]# cd
[root@yixuan ~]# docker exec -it testnginx /bin/bash
root@86320e734cd1:/# cd test2/
root@86320e734cd1:/test2# ls
a.txt

共享文件：
[root@yixuan ~]# mkdir /dir
[root@yixuan ~]# vim /dir/a.txt
123
[root@yixuan ~]# docker run -it --name testnginx2 -v /dir/a.txt:/dir1/a.txt daocloud.io/library/nginx /bin/bash
root@f899be627552:/# cat dir1/a.txt 
123
root@f899be627552:/#
注意：如果是共享文件，修改宿主机上面的文件内容，容器里面的文件不会同步更新，如果在容器里面进行修改文件，本地会同步。
```

共享其他容器的卷（其他容器用同一个卷）：

```shell
[root@yixuan ~]# docker run -it --name testnginx1 --volumes-from testnginx daocloud.io/library/nginx /bin/bash
root@50e6f726335c:/# ls
bin   dev  home  lib64	mnt  proc  run	 srv  test2  usr
boot  etc  lib	 media	opt  root  sbin  sys  tmp    var
root@50e6f726335c:/# cd test2/
root@50e6f726335c:/test2# ls
a.txt
```

实际应用中可以利用多个-v选项把宿主机上的多个目录同时共享给新建容器：

比如：

```shell
# docker run -it -v /abc:/abc -v /def:/def 1ae9
```

# **部署centos7容器应用**

镜像下载：

```shell
[root@yixuan ~]# docker pull daocloud.io/library/centos:7
```

systemd 整合:

```shell
因为 systemd 要求 CAPSYSADMIN 权限，从而得到了读取到宿主机 cgroup 的能力，CentOS7 中已经用 fakesystemd 代替了 systemd 。 但是我们使用systemd，可用参考下面的 Dockerfile：
```

```shell
[root@yixuan ~]# mkdir test
[root@yixuan ~]# cd test/
[root@yixuan test]# vim Dockerfile
FROM daocloud.io/library/centos:7
MAINTAINER "soso"  soso@qq.com
ENV container docker

RUN yum -y swap -- remove fakesystemd -- install systemd systemd-libs
RUN yum -y update; yum clean all; \
(cd /lib/systemd/system/sysinit.target.wants/; for i in *; do [ $i == systemd-tmpfiles-setup.service ] || rm -f $i; done); \
rm -f /lib/systemd/system/multi-user.target.wants/*;\
rm -f /etc/systemd/system/*.wants/*;\
rm -f /lib/systemd/system/local-fs.target.wants/*; \
rm -f /lib/systemd/system/sockets.target.wants/*udev*; \
rm -f /lib/systemd/system/sockets.target.wants/*initctl*; \
rm -f /lib/systemd/system/basic.target.wants/*;\
rm -f /lib/systemd/system/anaconda.target.wants/*;

VOLUME [ "/sys/fs/cgroup" ]

CMD ["/usr/sbin/init"]
```

这个Dockerfile删除fakesystemd 并安装了 systemd。然后再构建基础镜像:

```shell
[root@yixuan test]# docker build -t local/c7-systemd .
```

执行没有问题这就生成一个包含 systemd 的应用容器示例

 ```shell
[root@yixuan test]# docker images
REPOSITORY         TAG                 IMAGE ID            CREATED             SIZE
local/c7-systemd   latest              a153dcaa642e        6 minutes ago       391MB
 ```

为了使用像上面那样包含 systemd 的容器，需要创建一个类似下面的Dockerfile：

```shell
[root@yixuan test]# mkdir http
[root@yixuan test]# cd http/
[root@yixuan http]# vim Dockerfile
FROM local/c7-systemd
RUN yum -y install httpd; yum clean all; systemctl enable httpd.service
EXPOSE 80
CMD ["/usr/sbin/init"]
```

构建镜像:

```shell
[root@yixuan http]# docker build -t local/c7-systemd-httpd .
```

运行包含 systemd 的应用容器:

为了运行一个包含 systemd 的容器，需要使用--privileged选项， 并且挂载主机的 cgroups 文件夹。 下面是运行包含 systemd 的 httpd 容器的示例命令：

 ````shell
[root@yixuan http]# docker run --privileged -tid -v /sys/fs/cgroup:/sys/fs/cgroup:ro -p 80:80 local/c7-systemd-httpd

--privileged:授权提权。让容器内的root用户拥有正真root权限(有些权限是没有的)
 ````

注意：如果不加会运行在前台(没有用-d)，可以用ctrl+p+q放到后台去

测试可用：

```shell
[root@yixuan http]# yum install -y elinks
[root@yixuan http]# elinks --dump http://192.168.246.141  #apache的默认页面
                                 Testing 123..

   This page is used to test the proper operation of the [1]Apache HTTP
   server after it has been installed. If you can read this page it means
   that this site is working properly. This server is powered by [2]CentOS.
```

再来个安装openssh-server的例子：

```shell
[root@yixuan http]# cd ..
[root@yixuan test]# mkdir ssh
[root@yixuan test]# cd ssh/
[root@yixuan ssh]# vim Dockerfile
FROM local/c7-systemd
RUN yum -y install openssh-server; yum clean all; systemctl enable sshd.service
RUN echo 1 | passwd --stdin root
EXPOSE 22
CMD ["/usr/sbin/init"]
[root@yixuan ssh]# docker build --rm -t local/c7-systemd-sshd .
[root@yixuan ssh]# docker run --privileged -tid -v /sys/fs/cgroup:/sys/fs/cgroup:ro -p 2222:22 local/c7-systemd-sshd
[root@yixuan ssh]# ssh 192.168.246.141 -p 2222
[root@ce1af52a6f6c ~]# 
```

# docker数据存储位置

```shell
查看存储路径
[root@yixuan ~]# docker info | grep Root
 Docker Root Dir: /var/lib/docker
 
修改默认存储位置：
在dockerd的启动命令后面追加--data-root参数指定新的位置
[root@yixuan ~]# vim  /usr/lib/systemd/system/docker.service
ExecStart=/usr/bin/dockerd -H fd:// --containerd=/run/containerd/containerd.sock --data-root=/data

[root@yixuan ~]# systemctl daemon-reload 
[root@yixuan ~]# systemctl restart docker

查看是否生效：
[root@yixuan ~]# docker info | grep Root
 Docker Root Dir: /data
 
 [root@yixuan ~]# cd /data/
[root@yixuan data]# ls
builder  buildkit  containers  image  network  overlay2  plugins  runtimes  swarm  tmp  trust  volumes
```

# docker网络

## **容器网络分类**

注：

面试用，用了编排之后就没有用了

 查看当前网络：

```shell
[root@yixuan ~]# docker network list
NETWORK ID          NAME                DRIVER              SCOPE
9b902ee3eafb        bridge              bridge              local
140a9ff4bb94        host                host                local
d1210426b3b0        none                null                local
```

**docker安装后，默认会创建三种网络类型，bridge、host和none**

1、bridge:网络桥接

```shell
默认情况下启动、创建容器都是用该模式，所以每次docker容器重启时会按照顺序获取对应ip地址。
```

2、none：无指定网络

```shell
启动容器时，可以通过--network=none,docker容器不会分配局域网ip 
```

3、host：主机网络

```shell
 docker容器和主机共用一个ip地址。
 使用host网络创建容器：
[root@yixuan ~]# docker run -it --name testnginx2 --net host 98ebf73ab
[root@yixuan ~]# netstat -lntp | grep 80
tcp6       0      0 :::80                   :::*                    LISTEN      3237/docker-proxy

浏览器访问宿主ip地址
```

4、固定ip:

  创建固定Ip的容器：

```shell
4.1、创建自定义网络类型，并且指定网段
[root@yixuan ~]# docker network create --subnet=192.168.0.0/16 staticnet
4efd309244c6ad70eda2d047a818a3aec5b162f5ca29fb6024c09a5efbf15854
通过docker network ls可以查看到网络类型中多了一个staticnet:
[root@yixuan ~]# docker network ls
NETWORK ID          NAME                DRIVER              SCOPE
9b902ee3eafb        bridge              bridge              local
140a9ff4bb94        host                host                local
d1210426b3b0        none                null                local
4efd309244c6        staticnet           bridge              local
```

```shell
 4.2、使用新的网络类型创建并启动容器
 [root@yixuan ~]# docker run -itd --name userserver --net staticnet --ip 192.168.0.2 daocloud.io/library/centos:7
 通过docker inspect可以查看容器ip为192.168.0.2:
 [root@yixuan ~]# docker inspect userserver | grep -i ipaddress
            "SecondaryIPAddresses": null,
            "IPAddress": "",
                    "IPAddress": "192.168.0.2",

关闭容器并重启，发现容器ip并未发生改变
```
