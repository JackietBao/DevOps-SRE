## Ansible 自动化部署 Cluster集群

- 1.部署LVS集群
- 2.部署Proxy集群
- 3.部署Web集群
- 4.部署MySQL、Redis、NFS
- 5.部署xxxxx

