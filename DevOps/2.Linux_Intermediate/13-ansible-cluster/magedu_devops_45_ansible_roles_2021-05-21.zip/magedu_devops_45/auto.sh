
pwd=1
for i in 91 92 31 41 51 7 8 5 6 4 3
do


/usr/bin/expect <<EOF
set timeout 30
	spawn ssh-copy-id root@172.16.1.$i
	expect {
		"yes/no" { send "yes\n"; exp_continue }
		"password:" { send "${pwd}\n"; exp_continue } 
	}
	expect eof
EOF
done
