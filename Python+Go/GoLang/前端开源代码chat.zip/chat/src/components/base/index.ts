import TitleBar from './titleBar.vue'

export { TitleBar }
