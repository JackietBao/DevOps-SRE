import type {Router} from 'vue-router'
import {useAuthStore, useAuthStoreWithout} from '@/store/modules/auth'
import {ss} from '@/utils/storage'
import {fetchInviteCodeAPI} from '@/api/user'

export function setupPageGuard(router: Router) {
    router.beforeEach(async (to, from, next) => {

        const {inVitecode,} = to.query
        inVitecode && ss.set('invitedBy', inVitecode as string)

        if (inVitecode) {
            await fetchInviteCodeAPI({code: inVitecode})
            router.replace({path: to.path, query: {}})
        }

        window.$loadingBar?.start()
        const authStore = useAuthStoreWithout()
	  		const authLoginStore = useAuthStore()



        if (!authStore.userInfo.username) {
            try {
                authStore.token && await authStore.getUserInfo()

                let domain = `${window.location.protocol}//${window.location.hostname}`
                if (window.location.port)
                    domain += `:${window.location.port}`

								if (!authLoginStore.isLogin) {
									authLoginStore.checkAuth()
								}

                console.log(to.path);

                if (to.path === '/midjourney')
                    next({path: "/midjourney/text-to-image"})

                if (authStore.isGenuine === 0) {
                    await authStore.getGoMaxAiAuth(domain);
                    if (authStore.isGenuine === 1) {
                        next({path: "/unlawful"})
                    } else {
                        if (to.path === '/unlawful' && authStore.isGenuine === 2) {
                            next({path: '/'})
                        } else {

                            if (authStore.globalConfigLoading) {
                                await authStore.getglobalConfig(domain)
                                if (authStore.globalConfig.clientHomePath) {
                                    next({path: authStore.globalConfig.clientHomePath})
                                } else {
                                    next()
                                }
                            }
                        }
                    }
                }

                if (to.path === '/500')
                    next({path: '/'})

                else
                    next()
            } catch (error) {
                if (to.path === '/500')
                    next({path: '/'})
                else
                    next()
            }
        } else {
            const clientMenuList = authStore.globalConfig?.clientMenuList;

            const openMenuList = clientMenuList ? JSON.parse(clientMenuList) : []
            if (openMenuList.length && !openMenuList.includes(to.name) && ['Chat', 'Draw', 'Midjourney'].includes(to.name)) {

                if (authStore.globalConfig.clientHomePath && authStore.globalConfig.clientHomePath !== '')
                    next({path: authStore.globalConfig.clientHomePath})
                else next()
            }

            if (to.path === '/midjourney')
                next({path: "/midjourney/text-to-image"})

            if (to.path === '/mj')
                next({path: "/mj/text-to-image"})

            next()
        }
    })

    router.afterEach((to: any) => {
        window.$loadingBar?.finish()
    })
}
